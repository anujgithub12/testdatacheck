({
	createChart : function(component, scannedMap, exportMap, keyList) {
		if(!$A.util.isEmpty(scannedMap)){
            var scannedData = [];
	        var exportedData = [];
	        var x_Label = [];
            var groupBy = component.get("v.groupBy");
           // var maxValue = 0;
            var label1 = 'Scanned Cards';
            var label2 = 'SalesForce Exports';
            console.log('component.get("v.reportType")',component.get("v.reportType"));
            for(var key in keyList) {
                if (component.get("v.reportType") == 'User') {
                    scannedData.push(scannedMap[keyList[key]]+exportMap[keyList[key]]);
                    label1 = 'Users';
                } else {
                    scannedData.push(scannedMap[keyList[key]]);
                    exportedData.push(exportMap[keyList[key]]); 
                    if (component.get("v.reportType") == 'Email') 
                            label1 = 'Signature Captured';
                }
                    
            }
            /*Object.keys(scannedMap)
            .forEach(function eachKey(key) { 
                var i = 0;
                if(groupBy != "Monthly"){

                    Object.keys(scannedMap[key])
                    .forEach(function eachKey(innerkey) { 
                        //var scanCount = 0;
                       // var expCount = 0;
                        if (component.get("v.reportType") == 'User') {
                            //scanCount = scannedMap[key][innerkey] + exportMap[key][innerkey];
                            scannedData.push(scannedMap[key][innerkey] + exportMap[key][innerkey]);
                            label1 = 'Users';

                        }else {
                            //scanCount = scannedMap[key][innerkey];
                            //expCount = exportMap[key][innerkey];
                            scannedData.push(scannedMap[key][innerkey]);
                            exportedData.push(exportMap[key][innerkey]);
                            if (component.get("v.reportType") == 'Email') 
                                label1 = 'Saved Signature';
                        }
                        
                        if(i != 0){
                            x_Label.push('');
                        }
                        else{
                            x_Label.push(key);
                        }
                        i++;
                        
                    });
                }
                
                else {
                    var scanCount = 0;
                    var expCount = 0;
                    Object.keys(scannedMap[key])
                    .forEach(function eachKey(innerkey) { 
                        scanCount += scannedMap[key][innerkey];
                        expCount += exportMap[key][innerkey];
                    });
                   
                    if (component.get("v.reportType") == 'User') {
                        //console.log("maxValue",maxValue);

                        scannedData.push(scanCount+expCount);
                        label1 = 'Users';
                        //maxValue = scanCount+expCount+2;
                    }else {
                        scannedData.push(scanCount);
                        exportedData.push(expCount);
                        if (component.get("v.reportType") == 'Email') 
                            label1 = 'Saved Signature';
                    }
                    x_Label.push(key);
                }
                
            });*/
            //console.log("maxValue",maxValue);
            //component.set("v.maxY_value", maxValue);
            var linedataMyFirst = {
                label: label1,
                data: scannedData,
                fill: false,
                borderColor: '#51eaea',
                pointBorderColor:'#ffffff',
                pointBackgroundColor: '#30d6d6',
                backgroundColor: "#51eaea73",
                pointBorderWidth:'2',
                pointRadius: '5'
            };
            var linedataMySecond = {
                label: label2,
                data: exportedData,
                fill: false,
                borderColor: '#1589ee',
                pointBorderColor:'#ffffff',
                backgroundColor: "#6699ff",
				pointBackgroundColor: '#6699ff',
                pointBorderWidth: '2',
                pointRadius: '5' 
            };
            var linedatasets;
            if (component.get("v.reportType") == 'User') 
                linedatasets = [linedataMyFirst];     
            else
                linedatasets = [linedataMyFirst,linedataMySecond];     
            var linelabelsArray = keyList;
            var chartTitle =[];
            this.createChartData(component,linedatasets,null,linelabelsArray,chartTitle,'v.jsondataline', '','top', true);
        }
	},
    createChartData : function(component,datasets,colorArray,labelsArray,title,setattribute, y_title, legendPosition, usePointStyle) {
        var dataObj=this.createObject(datasets,labelsArray,colorArray,title, y_title, legendPosition, usePointStyle);
		this.createGraph(component, dataObj);
	},
    createObject : function(datasets,labelsArray,colorArray, title, y_title, legendPosition, usePointStyle){
        var dataObj = new Object();
        dataObj['dataset'] = datasets;
        dataObj['labels'] = labelsArray;
        dataObj['colors'] = colorArray;
        dataObj['title'] = title;
        dataObj['y_title'] = y_title;
        dataObj['legendPosition'] = legendPosition;
        dataObj['usePointStyle'] = usePointStyle;
        return dataObj;
    },
    createGraph : function(component,dataObj) {
		var data={
            labels: dataObj.labels,
            datasets: dataObj.dataset
        };
        console.log("=========================ooooooooo",data);
        var ctx = component.find("chart").getElement();
        var chart = new Chart(ctx, {
            type: 'line',
            responsive: true,
            maintainAspectRatio: false,
            data: data,
            options: 
            {
                animation:
                {
                    animateRotate : dataObj.animate,
                },
                title: 
                {
                    display: dataObj.displayTitle,
                    text: dataObj.title
                },
                
                elements: {
                    line: {
                        tension: 0, 
                        borderDashOffset:2
                    },
                },
                
                scales: {
                    xAxes: [{
                        gridLines: {
                            color:"rgba(0, 0, 0, 0)",
                        }
                    }],
                    
                    yAxes: [{
                        gridLines: {
                            borderDash: [2, 4],
                            color: "#5a5757",
                            
                        },
                        
                        /*ticks: {
                            max: component.get("v.maxY_value"), 
                        },*/
                    }]
                },
                legend: {
                    position: dataObj.legendPosition,
                    labels: {
                        verticalAlign: 'right',
                        usePointStyle: dataObj.usePointStyle,
                    }
                },
                /*tooltips: {
                    callbacks: {
                        label: function(tooltipItem, data) {
                            var label =  'Tests';

                            
                            return label;
                        }
                    }
                }*/
            }  
        });
	}
})