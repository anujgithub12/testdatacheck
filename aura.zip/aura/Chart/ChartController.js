({
	init : function(component, event, helper) {
		console.log(component.get('v.jsondata'));
		var jsondataString = component.get('v.jsondata');
		if(!$A.util.isEmpty(jsondataString)){
			var jsondataObj = JSON.parse(jsondataString);
			if(!$A.util.isEmpty(jsondataObj.mapKeyList) ){
				helper.createChart(component, jsondataObj.weekScannMap, jsondataObj.weekExportMap, jsondataObj.mapKeyList);
			}
		}
    }
})