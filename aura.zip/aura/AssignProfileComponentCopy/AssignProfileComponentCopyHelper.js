({
	doInit: function (component, event, helper) {
		var typeOptions = [];
		typeOptions.push({ label: 'Users', value: 'Users' });
		typeOptions.push({ label: 'Permission Sets', value: 'Permission Set' });
		typeOptions.push({ label: 'User Profile', value: 'User Profiles' });
		typeOptions.push({ label: 'Roles', value: 'Roles' });

		component.set("v.typeOptions", typeOptions);

		var action = component.get("c.retrieveDetail");
		action.setParams({ parentSBCRoleId: component.get("v.parentSBCRoleId") });
		action.setCallback(this, function (result) {
			console.log('Assign Comp INIT callback response state---- ', result.getState());
            if (result.getState() === 'ERROR') {
                if(component.get("v.isLightning")) {
                    helper.showErrorToast(component, event, result.getError(), 'Error Message','error');
                } else {
                    component.set("v.textMessage",  result.getError());
                    component.set("v.isToastMessageForVf", true);
                    component.set("v.isErrorType", true);
                    component.set("v.isInfoType", false);
                    component.set("v.isSuccessType", false);
                }
            } else if (result.getState() === 'SUCCESS') {
                var originalList = result.getReturnValue();
                console.log('Data retrieved on load ----- ', originalList);
                if (originalList.length > 0){
                    component.set("v.selectedType", originalList[0].devastegic1__Type__c);
                    component.set("v.primarySelectedType", originalList[0].devastegic1__Type__c);
                }
                component.set("v.selectedSObjectWrapperList", originalList);
                component.set("v.selectedTempWrapperList", originalList);
                component.set("v.sObjectWrapperOriginalList", originalList);
                
                component.set("v.initialAssignedRecords", originalList.length);
            } else {
                if(component.get("v.isLightning")) {
                    helper.showErrorToast(component, event, 'Something went wrong!', 'Error Message', 'error');
                } else {
                    component.set("v.textMessage", 'Something went wrong!');
                    component.set("v.isToastMessageForVf", true);
                    component.set("v.isErrorType", true);
                    component.set("v.isInfoType", false);
                    component.set("v.isSuccessType", false);
                }
            }
        });
		$A.enqueueAction(action);
	},
	showErrorToast: function (component, event, errors, toastTitle, toastType) {
		let toastParams = {
			title: toastTitle,
			message: "Unknown error", // Default error message
			type: toastType
		};
		console.log(typeof errors);
		// Pass the error message if any
		if (errors && Array.isArray(errors) && errors.length > 0) {
			toastParams.message = errors[0].message;
		}
		else if (typeof errors === 'string')
			toastParams.message = errors ; 
		// Fire error toast
		let toastEvent = $A.get("e.force:showToast");
		toastEvent.setParams(toastParams);
		toastEvent.fire();
	},
	setListValues: function (component, leftList, rightList) {
		component.set("v.sObjectWrapperList", leftList);
		component.set("v.sObjectWrapperTempList", leftList);
		component.set("v.selectedSObjectWrapperList", rightList);
		component.set("v.selectedTempWrapperList", rightList);
	},
	searchTextHelper: function (component, event, helper, searchTextParam, tempList, showList, availableSearch) {

		var searchText = component.get(searchTextParam);
		var wrapperRecordsList = component.get(tempList);
		var records = [];
		if (availableSearch){
			if (searchText === '' || searchText === null){
				component.set(showList, records);
				
                if(component.get("v.isLightning")) {
                   helper.showErrorToast(component, event, 'No record found.', 'Information', 'info');
                } else {
                    component.set("v.textMessage", 'No record found.');
                    component.set("v.isToastMessageForVf", true);
                    component.set("v.isInfoType", true);
                    component.set("v.isErrorType", false);
                    component.set("v.isSuccessType", false);
                }
			}
			else{
				var recordWithId = [];
				var recordWithoutId = [];
				var selectedRecordsList = component.get("v.selectedSObjectWrapperList");
				for (var i = 0; i < selectedRecordsList.length ; i++){
					if (selectedRecordsList[i].Id != undefined)
						recordWithId.push(selectedRecordsList[i]);
					else
						recordWithoutId.push(selectedRecordsList[i]);
				}
				var stringifieldRecordsWithId = JSON.stringify(recordWithId);
				var stringifieldRecordsWithoutId = JSON.stringify(recordWithoutId);
				var selectedType = component.get("v.selectedType");
				var action = component.get("c.searchAvailableController");
				action.setParams({
					parentSBCRoleId: component.get("v.parentSBCRoleId"),
					searchTextString: searchText,
					selectedTypeString: selectedType,
					insertedRecords: stringifieldRecordsWithId,
					notInsertedRecords: stringifieldRecordsWithoutId	
				});
				action.setCallback(this, function (result) {
					console.log('___________________________________________'+result.getState() );
					console.log('___________________________________________'+result.getReturnValue().length );
					
					
					if (result.getState() === 'ERROR') {
						if(component.get("v.isLightning")) {
                        	helper.showErrorToast(component, event, result.getError(), 'Error Message', 'error');
                        } else {
                            component.set("v.textMessage", result.getError());
                            component.set("v.isToastMessageForVf", true);
                            component.set("v.isErrorType", true);
                            component.set("v.isInfoType", false);
                            component.set("v.isSuccessType", false);
                        }
                    } else if (result.getState() === 'SUCCESS') {
						component.set(showList, result.getReturnValue());
                        if (result.getReturnValue().length === 0) {
                            if(component.get("v.isLightning")) {
                                helper.showErrorToast(component, event, 'No record found.', 'Information', 'info');
                            } else {
                                component.set("v.textMessage", 'No record found.');
                                component.set("v.isToastMessageForVf", true);
                                component.set("v.isInfoType", true);
                                component.set("v.isErrorType", false);
                                component.set("v.isSuccessType", false);
                            }    
                        }
                    } else {
                        if(component.get("v.isLightning")) {
                            helper.showErrorToast(component, event, 'Something went wrong!', 'Error Message', 'error');
                        } else {
                            component.set("v.textMessage", 'Something went wrong!');
                            component.set("v.isToastMessageForVf", true);
                            component.set("v.isErrorType", true);
                            component.set("v.isInfoType", false);
                            component.set("v.isSuccessType", false);
                        }
                    }
                });
				$A.enqueueAction(action);
			}
		} 
		else{
			if (searchText != '') {
				for (var i = 0, l = wrapperRecordsList.length; i < l; i++) {
					var obj = wrapperRecordsList[i];
					if (obj.Name.toLowerCase().startsWith(searchText.toLowerCase()))
						records.push(obj);
				}
                component.set(showList, records);
                if (records.length === 0) {
                    if(component.get("v.isLightning")) {
                        helper.showErrorToast(component, event, 'No record found.', 'Information', 'info');
                    } else {
                        component.set("v.textMessage", 'No record found.');
                        component.set("v.isToastMessageForVf", true);
                        component.set("v.isInfoType", true);
                        component.set("v.isErrorType", false);
                        component.set("v.isSuccessType", false);
                    }
                }
            }
            else
				component.set(showList, component.get(tempList));	
		}

	},
	resetListValues: function (component, event, helper) {

		var emptyList = [];
		component.set("v.selectedSearchText", '');
		component.set("v.availableSearchText", '');
		component.set("v.sObjectWrapperList", emptyList);
		component.set("v.sObjectWrapperTempList", emptyList);
		if (component.get("v.selectedType") === component.get("v.primarySelectedType")){
			component.set("v.selectedSObjectWrapperList", component.get("v.sObjectWrapperOriginalList")); 
			component.set("v.selectedTempWrapperList", component.get("v.sObjectWrapperOriginalList")); 
		}
		else{
			component.set("v.selectedSObjectWrapperList", emptyList);
			component.set("v.selectedTempWrapperList", emptyList); 
		}

	},
	showSelectedRecords: function (component, event, helper) {

		var selected = component.find("availableOption").get("v.value");
		var selectedRecordIdList = selected.split(';');
		var alreadySelectedRecords = component.get("v.selectedTempWrapperList");
		var availableRecordsList = component.get("v.sObjectWrapperList");
		var emptyList = [];
		var refreshedList = [];
		for (var i = 0; i < alreadySelectedRecords.length ; i++){
			refreshedList.push(alreadySelectedRecords[i]) ; 
		}
		for (var i = 0; i < availableRecordsList.length; i++) {
			if (selectedRecordIdList.includes(availableRecordsList[i].devastegic1__Related_Id__c)) {
				refreshedList.push(availableRecordsList[i]);
			}
		}
		helper.setListValues(component, emptyList, refreshedList);
		component.set("v.selectedSearchText", '');
		component.set("v.availableSearchText", '');
		console.log('refreshedList--- ', refreshedList);
		if(refreshedList.length > 0) {
			helper.checkAssignSaveDisable(component, helper);
		}
	},
	deSelectRecords: function (component, event, helper) {
		var selected = component.find("selectedOptions").get("v.value");
		var selectedRecordIdList = selected.split(';');
		var alreadySelectedRecords = [];
		var availableRecordsList = component.get("v.selectedTempWrapperList");
		var refreshedList = [];
		for (var i = 0; i < availableRecordsList.length; i++) {
			if (!selectedRecordIdList.includes(availableRecordsList[i].devastegic1__Related_Id__c)) 
				refreshedList.push(availableRecordsList[i]);
		}
		helper.setListValues(component, alreadySelectedRecords, refreshedList);
		component.set("v.selectedSearchText", '');
		component.set("v.availableSearchText", '');
		if(selected) {
			helper.checkAssignSaveDisable(component, helper);
		}
	},
	hidePopupHelper: function (component, event, helper) {
		document.getElementsByTagName("BODY")[0].style.overflow = "visible";
		component.set("v.visibilityControllingVar", 'hide');
	},
	saveDataHelper: function (component, event, helper) {
		var recordWithId = [];
		var recordWithoutId = [];
		var selectedRecordsList = component.get("v.selectedSObjectWrapperList");
		for (var i = 0; i < selectedRecordsList.length; i++) {
			if (selectedRecordsList[i].Id != undefined)
				recordWithId.push(selectedRecordsList[i]);
			else
				recordWithoutId.push(selectedRecordsList[i]);
		}
		var stringifieldRecordsWithId = JSON.stringify(recordWithId);
		var stringifieldRecordsWithoutId = JSON.stringify(recordWithoutId);
		var selectedType = component.get("v.selectedType");
		var action = component.get("c.saveDataClassMethod");
		action.setParams({
			parentSBCRoleId: component.get("v.parentSBCRoleId"),
			changedType: selectedType,
			insertedRecords: stringifieldRecordsWithId,
			notInsertedRecords: stringifieldRecordsWithoutId
		});
		action.setCallback(this, function (result) {
			if (result.getState() === 'ERROR') {
                if(component.get("v.isLightning")) {
                    helper.showErrorToast(component, event, result.getError(), 'Error Message', 'error');
                } else {
                    component.set("v.textMessage", result.getError());
                    component.set("v.isToastMessageForVf", true);
                    component.set("v.isErrorType", true);
                    component.set("v.isInfoType", false);
                    component.set("v.isSuccessType", false);
                }
            } else if (result.getState() === 'SUCCESS') {
				component.set("v.visibilityControllingVar", 'hide');
				component.set("v.parentComponentRefreshVar", 'refresh');
				document.getElementsByTagName("BODY")[0].style.overflow = "visible";
            } else {
                if(component.get("v.isLightning")) {
                    helper.showErrorToast(component, event, 'Something went wrong!', 'Error Message', 'error');
                } else {
                    component.set("v.textMessage", 'Something went wrong!');
                    component.set("v.isToastMessageForVf", true);
                    component.set("v.isErrorType", true);
                    component.set("v.isInfoType", false);
                    component.set("v.isSuccessType", false);
                }
            }
		});
		$A.enqueueAction(action);
	},
	addAvailableSearchListeners: function (clickedComponent, helper, component) {
		console.log('Hi Item--- ', clickedComponent);//childNodes
		//before Summer 18
		//console.log('Hi span--- ', clickedComponent.elements[0].children[1].children[1]); //component.elements.children[1].children[1]       

		//After summer 18
		//Attaching event listener on lighting:input (search icon parent span)
		/*
		clickedComponent.elements[0].children[0].children[1].children[1].children[0].addEventListener("click", $A.getCallback(function () {
			console.log('Hi onclick event addded----', helper);
			helper.searchTextHelper(component, event, helper, 'v.availableSearchText', 'v.sObjectWrapperTempList', 'v.sObjectWrapperList',true);
		}));
		*/
	},
	addSelectedSearchListeners: function (clickedComponent, helper, component) {
		console.log('Hi Selected search---- ', component);
		/*
		clickedComponent.elements[0].children[0].children[1].children[1].children[0].addEventListener("click", $A.getCallback(function () {
			console.log('Hi onclick event addded----', helper);
			helper.searchTextHelper(component, event, helper, 'v.selectedSearchText', 'v.selectedTempWrapperList', 'v.selectedSObjectWrapperList',false);
		}));
		*/
	},
	checkAssignSaveDisable : function(component, helper) {
		console.log('Check Save enabled or disabled======');
		//selectedSObjectWrapperList
		var allSelectedItems = component.get("v.selectedSObjectWrapperList");
		var noNewChangeFlag = false;
		if(allSelectedItems.length == 0) {
			if(component.get("v.initialAssignedRecords") != 0) {
				$A.util.removeClass(document.getElementById("assignSaveButtonId"), 'disableAssignSaveButtonClass');
			}else {
				$A.util.addClass(document.getElementById("assignSaveButtonId"), 'disableAssignSaveButtonClass');
			}
			
		}else {
			for(var i=0; i < allSelectedItems.length; i++) {
				if(! allSelectedItems[i].Id) {
					console.log('Hi Id ==== ', allSelectedItems[i].Id);
					noNewChangeFlag = true;
					$A.util.removeClass(document.getElementById("assignSaveButtonId"), 'disableAssignSaveButtonClass');
				}
			}
			
			if(!noNewChangeFlag && allSelectedItems.length < component.get("v.initialAssignedRecords")) {
				noNewChangeFlag = true;
			}
			
			if(! noNewChangeFlag) {
				$A.util.addClass(document.getElementById("assignSaveButtonId"), 'disableAssignSaveButtonClass');
			}else {
				$A.util.removeClass(document.getElementById("assignSaveButtonId"), 'disableAssignSaveButtonClass');
			}		
		}
	}
})