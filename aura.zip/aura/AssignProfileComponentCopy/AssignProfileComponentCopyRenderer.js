({
	// Your renderer method overrides go here
	afterRender: function (component, helper) {
		var afterRend = this.superAfterRender();
		var cmp = component.find("availableObjectInputId");
		helper.addAvailableSearchListeners(cmp, helper, component);
		var cmp1 = component.find("selectedObjectInputId");
		helper.addSelectedSearchListeners(cmp1, helper, component);
		return afterRend;
	},
})