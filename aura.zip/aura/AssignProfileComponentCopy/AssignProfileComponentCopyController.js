({
	doInit: function (component, event, helper) {
		document.getElementsByTagName("BODY")[0].style.overflow = "hidden";
		helper.doInit(component, event, helper);
	}, 
	searchAvailable: function (component, event, helper) {
		console.log('-------------searchAvailable----------');
		helper.searchTextHelper(component, event, helper, 'v.availableSearchText', 'v.sObjectWrapperTempList', 'v.sObjectWrapperList', 'true');
	},

	searchSelected: function (component, event, helper) {
		console.log('==========searchSelected=========');
		helper.searchTextHelper(component, event, helper, 'v.selectedSearchText', 'v.selectedTempWrapperList', 'v.selectedSObjectWrapperList','false');
	},
	resetListValues: function (component, event, helper) {
		helper.resetListValues(component, event, helper);
	},
	showSelectedRecords: function (component, event, helper) {
		helper.showSelectedRecords(component, event, helper);
	},
	deSelectRecords: function (component, event, helper) {
		helper.deSelectRecords(component, event, helper);
	},
	hidePopup: function (component, event, helper) {
		helper.hidePopupHelper(component, event, helper);
	},
	saveData: function (component, event, helper) {
		helper.saveDataHelper(component, event, helper);
	},
	checkIconClick: function (component, event, helper) {
		console.log(event);
		console.log('source--- ', event.getSource());
	},
	checkKeyEventOnAvailableSearch: function (component, event, helper) {
		var x = event.which || event.keyCode;
		//Enter key must search
		if (x == 13) {
			console.log('Enter key pressed ', component.get("v.availableSearchText"));
			//if(component.get("v.availableSearchText")) {
			helper.searchTextHelper(component, event, helper, 'v.availableSearchText', 'v.sObjectWrapperTempList', 'v.sObjectWrapperList',true);
			//}
		}
	},
	checkKeyEventOnSelectedSearch: function (component, event, helper) {
		var x = event.which || event.keyCode;
		//Enter key must search
		if (x == 13) {
			console.log('Enter key selected pressed ', component.get("v.selectedSearchText"));
			//if(component.get("v.selectedSearchText")) {
			helper.searchTextHelper(component, event, helper, 'v.selectedSearchText', 'v.selectedTempWrapperList', 'v.selectedSObjectWrapperList',false);
			//}

		}
	},

})