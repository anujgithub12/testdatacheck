({
    closeToastMessage : function(component, event, helper) {
       component.set("v.isToastMessageForVf", false);
    }
})