({
    handleOnClick : function(component, event, helper) {
       console.log(document.getElementsByClassName(component.get("v.uniqueClass"))[0]);
        var isClassExist = document.getElementsByClassName(component.get("v.uniqueClass"))[0].classList.contains('slds-hide'); 
       
        if(isClassExist) {
            document.getElementsByClassName(component.get("v.uniqueClass"))[0].classList.remove("slds-hide");
        }
        else {
            document.getElementsByClassName(component.get("v.uniqueClass"))[0].classList.add("slds-hide");
        }
    },
    handleMouseLeave : function(component, event, helper) {
        document.getElementsByClassName(component.get("v.uniqueClass"))[0].classList.add("slds-hide");
        //$A.util.addClass(component.find("divHelp"), 'slds-hide');
    },
    handleMouseEnter : function(component, event, helper) {
        document.getElementsByClassName(component.get("v.uniqueClass"))[0].classList.remove("slds-hide");
        // $A.util.removeClass(component.find("divHelp"), 'slds-hide');
    }
})