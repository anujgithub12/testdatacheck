({
	doinit : function(cmp, event, helper) {
		var object = cmp.get("v.object");
        var field = cmp.get("v.field");
        cmp.set("v.valee", object[field]);
	}
})