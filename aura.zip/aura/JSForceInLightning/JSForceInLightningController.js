({
    doInit : function(component, event, helper) {
    	component.set('v.iframeLoadingSpinner', true); 
    	var lightningComponentRef =  component;
    	var lightingCompHelper = helper;
        
        
    	var action = component.get("c.getHostName");
        action.setCallback(this, function(response){
                var state = response.getState();
                if( state === "SUCCESS" ) {
                   var hostUrl = response.getReturnValue();
                   component.set("v.vfHost", hostUrl);  
                }
       });
       $A.enqueueAction(action);
        
        
        window.addEventListener("message", $A.getCallback(function(postEvent) {
            console.log('postEvent.data---- ', JSON.stringify(postEvent.data));    
            if (postEvent.data.key !== true) {
                // Not the expected values: Reject the message!
                return;
            }
            if((!(postEvent.origin).includes('visual.force.com') && !(postEvent.origin).includes('visualforce.com')) || !(postEvent.origin).includes('https:')) { 
            	return;
            }
            
            
            // Handle the message
            console.log('----Let us see posted data-----', postEvent.data.value);
            lightningComponentRef.set('v.showSpinner', postEvent.data.value === "showSpinner" ? true : false);
            if(postEvent.data.message && postEvent.data.toastType ) {
            	console.log('Toast data is posted successfully---- 1');
            	console.log('Toast Message --> ' + postEvent.data.message + '  ## Toast Type --> '+ postEvent.data.toastType);
            	//fire toast event, handled in ScanBizCardsHomeScreenComp
            	lightingCompHelper.fireToastEvent(lightningComponentRef, event, postEvent.data.message, postEvent.data.toastType);
            }
            
            if(postEvent.data.workCompleted) {
            	lightningComponentRef.set("v.loadRecordTypePercentage", postEvent.data.workCompleted);
            }
        }));	    
	    
    	/*
        window.addEventListener("message", function(event) {
            console.log('event.data---- ', event.data);
            if (event.data.key !== true) {
                // Not the expected values: Reject the message!
                return;
            }
            
            // Handle the message
            console.log('----Let us see posted data-----', event.data.value);
            component.set('v.showSpinner', event.data.value === "showSpinner" ? true : false);
            if(event.data.message && event.data.toastType ) {
            	console.log('Toast data is posted successfully---- 1');
            	//fire toast event, handled in ScanBizCardsHomeScreenComp
            	helper.fireToastEvent(component, event, event.data.message, event.data.toastType);
            }
            
            if(event.data.workCompleted) {
            	component.set("v.loadRecordTypePercentage", event.data.workCompleted);
            }
        }, false);
        */
    },
    showLoadRecordType : function(component, event, helper) {
    	console.log('This time spinner will hide==== Load Record Type will be shown----');
    	component.set('v.iframeLoadingSpinner', false); 
    },
    handleLoadRecordTypeAppEvent : function(component, event, helper) {
    	console.log('App event is fired and in its handler------ All good now');
    	console.log('VF Frame comp----- ', component.find("vfFrame"), 'VF Frame comp element ---- ', component.find("vfFrame").getElement());
    	window.setTimeout( $A.getCallback(function() {
    		 if (component.isValid()) {
	    		if(component.find("vfFrame") && component.find("vfFrame").getElement() && component.find("vfFrame").getElement().contentWindow) {
		    		console.log(' AFTER VF Frame comp element ---- ', component.find("vfFrame").getElement(), ' Content window --- ', component.find("vfFrame").getElement().contentWindow);
		    		var vfWindow = component.find("vfFrame").getElement().contentWindow;
		    		vfWindow.postMessage({lightningCompToVFKey:true}, component.get("v.vfHost"));    	
		    	}
	    	}    	
    	}), 5000);
    	
    	
    }
})