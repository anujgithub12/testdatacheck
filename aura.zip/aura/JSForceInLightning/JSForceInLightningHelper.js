({
	fireToastEvent : function(component, event, toastMessage, toastType) {
		console.log('Is component only null ===== ', component , '=== also Event---- ', component.getEvent("tostMessageEvent"), ' ===toastMessage ==', toastMessage, ' ==== toastType == ', toastType);
		var compEvent = component.getEvent("tostMessageEvent");
		if(compEvent) {
			console.log('CompEvent---', compEvent);
			compEvent.setParams({"toastMessage" : toastMessage });
			compEvent.setParams({"toastType" : toastType });
			compEvent.fire();
			if(toastMessage === 'Record types successfully loaded!') {
				component.set("v.preloaded", true);
			}
		}
				
	}
})