({ 
    sortBy: function(component, field) {
        
        var sortAsc = component.get("v.sortAsc"),
            sortField = component.get("v.sortField"),
            records = component.get("v.allRecords");
        
        sortAsc = sortField != field || !sortAsc;
        records.sort(function(a,b){
            var t1 = a[field].toLowerCase() == b[field].toLowerCase(),
                t2 = (!a[field] && b[field].toLowerCase()) || (a[field].toLowerCase() < b[field].toLowerCase());  
            return t1? 0: (sortAsc?-1:1)*(t2?1:-1);
        });
        component.set("v.sortAsc", sortAsc);
        component.set("v.sortField", field);
        component.set("v.allRecords", records);
        this.renderPage(component,'v.allRecords','v.pageNumber','v.recordsPerPage','v.currentList','v.maxPage','v.pageNoList');
    }, 
    renderPage: function(component,allRecordVar,pageNumberVar,recordsPerPageVar,currentListVar,maxPageVar,pageNoListVar) {
        var records = component.get(allRecordVar),
            pageNumber = component.get(pageNumberVar),
            recordsPerPage = component.get(recordsPerPageVar),
            pageRecords = records.slice((pageNumber-1)*recordsPerPage, pageNumber*recordsPerPage);
        component.set(currentListVar, pageRecords);
        component.set(maxPageVar, Math.floor((records.length+parseInt(recordsPerPage)-1)/parseInt(recordsPerPage)));
        var maxPage = component.get(maxPageVar);
        var pageNoList = [];
        for(var i = 1; i<= maxPage ; i++){
            pageNoList.push(i);
        }
        component.set(pageNoListVar,pageNoList);
    }, 
    renderPageOnRecordsPerPageChange : function(component){
        var records = component.get("v.allRecords"),
            recordsPerPage = component.get("v.recordsPerPage"),
            pageRecords = records.slice(0,recordsPerPage);
        component.set("v.pageNumber", 1);
        component.set("v.currentList", pageRecords);
        component.set("v.maxPage", Math.floor((records.length+parseInt(recordsPerPage)-1)/parseInt(recordsPerPage)));
        var maxPage = component.get("v.maxPage");
        var pageNoList = [];
        for(var i = 1; i<= maxPage ; i++){
            pageNoList.push(i);
        }
        component.set("v.pageNoList",pageNoList);
    },
    assignProfileScreenOpen : function(component, event, helper, dataIndexId, searchStr) {
        
        component.set("v.selectedUserName", dataIndexId.split('-')[0]);
        component.set("v.selectedUserId", dataIndexId.split('-')[1]);
        component.set("v.spinner", true);
        component.set("v.isOpenPopup", true);
        var action = component.get("c.getSettingProfileData");
        action.setParams({
            'searchProfileKey'	: 	component.get("v.searchKey"),
            'selUserId' 	  	:  	component.get("v.selectedUserId")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(component.isValid() && state === "SUCCESS") {
                var record = response.getReturnValue();
                component.set("v.showPopupDataAssign", record);
                if(!$A.util.isEmpty(component.get("v.searchKey"))) {
                    if(record.length == 0) {
                        var message = "No records found.";
                        
                        if(component.get("v.isLightning")) {
                            helper.notifyInfo(message, helper);
                        } else {
                            component.set("v.textMessage", message);
                            component.set("v.isToastMessageForVf", true);
                            component.set("v.isInfoType", true);
                            component.set("v.isErrorType", false);
                            component.set("v.isSuccessType", false);
                        }
                    }
                }
            }
            if(state=="ERROR") {
                var errors = response.getError();
                var message = '';
                if(errors) {
                    if(errors[0] && errors[0].message) {
                        message = errors[0].message;
                    }
                } else {
                    message= "Unknown Error";
                }
                if(component.get("v.isLightning")) {
                    helper.notifyError(message, helper);
                } else {
                    component.set("v.textMessage", message);
                    component.set("v.isToastMessageForVf", true);
                    component.set("v.isErrorType", true);
                    component.set("v.isInfoType", false);
                    component.set("v.isSuccessType", false);
                }
            }
            component.set("v.spinner", false);
            $A.util.addClass(document.getElementById("disableAssignRolesSaveButtonId"), 'disableAssignRolesSaveButtonClass');
            
        });
        $A.enqueueAction(action);
    },
    onCheck: function(component, event, helper) {
        
        var checked = event.getSource().get("v.value");
        var comboId = event.getSource().get("v.text");
        console.log(checked);console.log(comboId);
        if(checked) {
            component.set("v.selectedProfileId", comboId.split('-')[0]);
            console.log(comboId.split('-')[1]);
            
            if(!$A.util.isEmpty(comboId.split('-')[1]) && !$A.util.isUndefined(comboId.split('-')[1])) {
                component.set("v.selectedAssignmentId", comboId.split('-')[1]);
            } else {
                component.set("v.selectedAssignmentId", '');
            }
            //disableAssignRolesSaveButtonId 
            $A.util.removeClass(document.getElementById("disableAssignRolesSaveButtonId"), 'disableAssignRolesSaveButtonClass');
        }
    },
    saveModalData : function(component, event, helper) {
        component.set("v.spinner", true);
        var action = component.get("c.saveProfileData");
        
        action.setParams({
            'selUserName'	 	:	component.get("v.selectedUserName"),
            'selUserId'		 	:  	component.get("v.selectedUserId"),
            'selProfileId'		: 	component.get("v.selectedProfileId"),
            'selAssignmentId' 	: 	component.get("v.selectedAssignmentId")
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state == "SUCCESS") {
                var result = response.getReturnValue();
                console.log('Let us see the result ==== ', result);   
                if(result.isSuccess) {
                    component.set("v.isOpenPopup", false);
                    console.log('Hi Success======');
                    if(component.get("v.isLightning")) {    
                        helper.notifySuccess(result.message, helper);
                    } else {
                        component.set("v.textMessage", result.message);
                        component.set("v.isToastMessageForVf", true);
                        component.set("v.isSuccessType", true);
                        component.set("v.isInfoType", false);
                        component.set("v.isErrorType", false);
                    }
                } else {
                	console.log('Hi error----');
                    if(component.get("v.isLightning")) {
                    	console.log('==== MESSAGE----- ', result.message);
                        helper.notifyError(result.message, helper);
                    } else {
                        component.set("v.textMessage", result.message);
                        component.set("v.isToastMessageForVf", true);
                        component.set("v.isErrorType", true);
                        component.set("v.isSuccessType", false);
                        component.set("v.isInfoType", false);
                    }
                }
            }
            if(state=="ERROR") {
            	console.log('Hi Exception ====----');
                var errors = response.getError();
                var message = '';
                if(errors) {
                    if(errors[0] && errors[0].message) {
                        message = errors[0].message;
                    }
                } else {
                    message= "Unknown Error";
                }
                if(component.get("v.isLightning")) {
                    helper.notifyError(message, helper);
                } else {
                    component.set("v.textMessage", message);
                    component.set("v.isToastMessageForVf", true);
                    component.set("v.isErrorType", true);
                    component.set("v.isInfoType", false);
                    component.set("v.isSuccessType", false);
                }
            }
            component.set("v.spinner", false);
        });
        $A.enqueueAction(action);
    },
    removeLicenseScreenOpen : function(component, event, helper) {
        var userIdVal = event.target.getAttribute('data-index');
        component.set("v.selectedUserIdToBeRemoved", userIdVal);
        var userName = event.target.getAttribute('data-user-name');
        component.set("v.userNameToDelete", userName);
        component.set("v.isOpenRemoveScreen", true);
        console.log("Durgesh id----", userIdVal+"----user name-----",userName);
    },
    
    removeLicense : function(component, event, helper) {
        component.set("v.spinner", true);
		var action = component.get("c.removeUserLicense");
        action.setParams({
            'selUserId'	: 	component.get("v.selectedUserIdToBeRemoved")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state == "SUCCESS") {
                var result = response.getReturnValue();
                component.set("v.isOpenRemoveScreen", false);
                
              	if(result.isSuccess) {
                    if(component.get("v.isLightning")) {
                        helper.notifySuccess(result.message, helper);
                    } else {
                        component.set("v.textMessage", result.message);
                        component.set("v.isToastMessageForVf", true);
                        component.set("v.isSuccessType", true);
                        component.set("v.isInfoType", false);
                        component.set("v.isErrorType", false);
                    }
                    //need to update licensed user list which comes on load
                    var actionForUpdateLicensedList = component.get("c.getUsersData");
                    actionForUpdateLicensedList.setCallback(this, function(response) {
		            var state = response.getState();
			            if(state == "SUCCESS") {
				            var records = response.getReturnValue();
				            if(records && records.length && records.length > 0) {
				            	component.set("v.allRecords", records);
				            	component.set("v.maxPage", Math.floor((records.length+9)/10));
				            	var maxPage = component.get("v.maxPage");
				            	component.set("v.pageNumber",1);
				            	helper.sortBy(component, 'name');
				            }
				        }
						if(state == "ERROR") {
			                var errors = response.getError();
			                if(errors && errors[0] && errors[0].message) {
			                    if(component.get("v.isLightning")) {
			                        helper.notifyError(errors[0].message, helper);
			                    } else {
			                        component.set("v.textMessage", errors[0].message);
			                        component.set("v.isToastMessageForVf", true);
			                        component.set("v.isErrorType", true);
			                        component.set("v.isInfoType", false);
			                        component.set("v.isSuccessType", false);
			                    }  
			                }
			            }
                    });
                    $A.enqueueAction(actionForUpdateLicensedList);
                }
                else {
                    if(component.get("v.isLightning")) {
                        helper.notifyError(result.message, helper);
                    } else {
                        component.set("v.textMessage", result.message);
                        component.set("v.isToastMessageForVf", true);
                        component.set("v.isErrorType", true);
                        component.set("v.isInfoType", false);
                        component.set("v.isSuccessType", false);
                    }
                }
            }
            if(state=="ERROR") {
               	var errors = response.getError();
                var message = '';
                if(errors) {
                    if(errors[0] && errors[0].message) {
                        message = errors[0].message;
                    }
                } else {
                    message= "Unknown Error";
                }
                if(component.get("v.isLightning")) {
                    helper.notifyError(message, helper);
                } else {
                    component.set("v.textMessage", message);
                    component.set("v.isToastMessageForVf", true);
                    component.set("v.isErrorType", true);
                    component.set("v.isInfoType", false);
                    component.set("v.isSuccessType", false);
                }
            }
           component.set("v.spinner", false);
        });
        $A.enqueueAction(action);
    },
    openAddUserScreen : function(component, event, helper) {
         
        component.set("v.isOpenAddUserScreen", true);
        //component.set("v.spinner", true);
        var action = component.get("c.getUnlicensedUserData");
        action.setParams({
            'searchKeyAvail' : component.get("v.searchKeyAvailable")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log("state---", state);
            if(state == "SUCCESS") {
                var result = response.getReturnValue();
                var a = [];
                if(result.unLicensedUsers.length > 0) {
                    for(var i=0; i< result.unLicensedUsers.length; i++) {
                        a.push({
                            'value' : result.unLicensedUsers[i].Id+'#'+result.unLicensedUsers[i].Name.toLowerCase(),
                            'label' : result.unLicensedUsers[i].Name
                        });
                    }
                }
                if(result.licensedUsers.length > 0) {
                    var alreadySelectedVar = [];
                    var initialLicenseData = []
                    for(var i=0; i< result.licensedUsers.length; i++) {
                        a.push({
                            'value' : result.licensedUsers[i].Id+'#'+result.licensedUsers[i].Name.toLowerCase(),
                            'label' : result.licensedUsers[i].Name
                        });
                        alreadySelectedVar.push(result.licensedUsers[i].Id+'#'+result.licensedUsers[i].Name.toLowerCase());
                        initialLicenseData.push(result.licensedUsers[i].Id);
                    }
                    component.set("v.defaultOptions", alreadySelectedVar);
                    component.set("v.initialLicensedUsers", initialLicenseData);
                    
                }
                component.set("v.allUnlicensedUserData", a);
                if(! $A.util.isEmpty(component.get("v.searchKeyAvailable"))) {
                   var selectedOptionsVar = component.get("v.defaultOptionsBeforeSearch");
                    for(var i=0; i< selectedOptionsVar.length; i++) {
                        a.push({
                            'value' : selectedOptionsVar[i],
                            'label' : selectedOptionsVar[i].split("#")[1].replace(/\b[a-z]/g,function(f){return f.toUpperCase();})
                        });
                    }
                    console.log("value of b after pushing---", a);
                    component.set("v.allUnlicensedUserData", a); 
                    
                    component.set("v.defaultOptions", component.get("v.defaultOptionsBeforeSearch"));
                }
                console.log('length of result-----', result.length);
                if(result && result.unLicensedUsers.length == 0) {
                    var message = "No records found.";
                    
                    if(component.get("v.isLightning")) {
                        helper.notifyInfo(message, helper);
                    } else {
                        component.set("v.textMessage", message);
                        component.set("v.isToastMessageForVf", true);
                        component.set("v.isInfoType", true);
                        component.set("v.isErrorType", false);
                        component.set("v.isSuccessType", false);
                    }
                }
            }
            if(state=="ERROR") {
               
               	var errors = response.getError();
                var message = '';
                if(errors) {
                    if(errors[0] && errors[0].message) {
                        message = errors[0].message;
                    }
                } else {
                    message= "Unknown Error";
                }
                if(component.get("v.isLightning")) {
                    helper.notifyError(message, helper);
                } else {
                    component.set("v.textMessage", message);
                    component.set("v.isToastMessageForVf", true);
                    component.set("v.isErrorType", true);
                    component.set("v.isInfoType", false);
                    component.set("v.isSuccessType", false);
                }
            }
            // component.set("v.spinner", false);
        });
        $A.enqueueAction(action);
    },
    openRemoveUserScreen : function(component, event, helper) {
        component.set("v.isopenRemoveUserScreen", true);
        var action =  component.get("c.getUsersData");
        console.log('hi------------'+component.get("v.searchKey"));
        action.setParams({
            'searchKeyVal' : component.get("v.searchKeyusers")  
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state == "SUCCESS") {
                var result = response.getReturnValue();
                component.set("v.usersAllDataToBeRemoved", result);
                if($A.util.isUndefinedOrNull(result)) {
				   if(result.length == 0) {
				        var message = "No records found.";
				    if(component.get("v.isLightning")) {
				        helper.notifyInfo(message, helper);
				    } else {
				        component.set("v.textMessage", message);
				        component.set("v.isToastMessageForVf", true);
				        component.set("v.isInfoType", true);
				        component.set("v.isErrorType", false);
				        component.set("v.isSuccessType", false);
				        }
				    }
                }
			}
            if(state=="ERROR") {
               	var errors = response.getError();
                var message = '';
                if(errors) {
                    if(errors[0] && errors[0].message) {
                        message = errors[0].message;
                    }
                } else {
                    message= "Unknown Error";
                }
                if(component.get("v.isLightning")) {
                    helper.notifyError(message, helper);
                } else {
                    component.set("v.textMessage", message);
                    component.set("v.isToastMessageForVf", true);
                    component.set("v.isErrorType", true);
                    component.set("v.isInfoType", false);
                    component.set("v.isSuccessType", false);
                }
            }
            //Disable the remove user button
            $A.util.addClass(document.getElementById("disableRemoveUserButtonId"), 'disableRemoveUserButtonClass');
        });
        $A.enqueueAction(action);
    },
    onCheckUserToBeRemoved : function(component, event, helper) {
        var a = [];
        var checkedResult = component.find("checkbox");
        var atleastOneUserSelected = false;
        for(var i=0; i< checkedResult.length; i++) {
            if(checkedResult[i].get("v.value")) {
                a.push(checkedResult[i].get("v.text"));
                atleastOneUserSelected = true;
            }
         }
         if(atleastOneUserSelected) {
        	 //Enable the button
        	 $A.util.removeClass(document.getElementById("disableRemoveUserButtonId"), 'disableRemoveUserButtonClass');
         }else {
        	 //Disable the button 
        	 $A.util.addClass(document.getElementById("disableRemoveUserButtonId"), 'disableRemoveUserButtonClass');
         }
      	component.set("v.allCheckedUserIdToBeRemoved",a);
    },
    saveRemoveUserData : function(component, event, helper) {
        component.set("v.spinner", true);
        var action =  component.get("c.removeMultiUsersFromPckgLicensed");
        action.setParams({
           'usersIdToBeRemoved' : component.get("v.allCheckedUserIdToBeRemoved") 
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state == "SUCCESS") {
                var result = response.getReturnValue();
               
                if(component.get("v.isLightning")) {
                    helper.notifySuccess(result.message, helper);
                } else {
                    component.set("v.textMessage", result.message);
                    component.set("v.isToastMessageForVf", true);
                    component.set("v.isSuccessType", true);
                    component.set("v.isInfoType", false);
                    component.set("v.isErrorType", false);
                }
                component.set("v.isopenRemoveUserScreen", false);
                
                //need to update licensed user list which comes on load
                var actionForUpdateLicensedListNew = component.get("c.getUsersData");
                actionForUpdateLicensedListNew.setCallback(this, function(response) {
		            var state = response.getState();
		            if(state == "SUCCESS") {
			            var records = response.getReturnValue();
			            if(records && records.length && records.length > 0) {
			            	component.set("v.allRecords", records);
			            	component.set("v.maxPage", Math.floor((records.length+9)/10));
			            	var maxPage = component.get("v.maxPage");
			            	component.set("v.pageNumber",1);
			            	helper.sortBy(component, 'name');
			            }
			        }
					 if(state == "ERROR") {
			            var errors = response.getError();
			            if(errors && errors[0] && errors[0].message) {
			                if(component.get("v.isLightning")) {
			                    helper.notifyError(errors[0].message, helper);
			                } else {
			                    component.set("v.textMessage", errors[0].message);
			                    component.set("v.isToastMessageForVf", true);
			                    component.set("v.isErrorType", true);
			                    component.set("v.isInfoType", false);
			                    component.set("v.isSuccessType", false);
			                }  
			            }
			        }
                });
                $A.enqueueAction(actionForUpdateLicensedListNew);
            }
            if(state=="ERROR") {
               	var errors = response.getError();
                var message = '';
                if(errors) {
                    if(errors[0] && errors[0].message) {
                        message = errors[0].message;
                    }
                } else {
                    message= "Unknown Error";
                }
                if(component.get("v.isLightning")) {
                    helper.notifyError(message, helper);
                } else {
                    component.set("v.textMessage", message);
                    component.set("v.isToastMessageForVf", true);
                    component.set("v.isErrorType", true);
                    component.set("v.isInfoType", false);
                    component.set("v.isSuccessType", false);
                }
            }
            component.set("v.spinner", false);
        });
        $A.enqueueAction(action);
    },
    getSelectedUnlicensedUsers : function(component, event, helper) {
        console.log('Hi selectedd --- ' , event.getParam("value"));
    	component.set("v.defaultOptionsBeforeSearch",  event.getParam("value"));
    	console.log('---event.getParam("value")---- ', event.getParam("value"));
    	
    	//Check everytime if initial data have some extra data
		var initialDataVar = component.get("v.initialLicensedUsers"); 
		if(event.getParam("value").length > 0 && initialDataVar.length == 0) {
			//This means - Initially no users selected and now atleast one new user added to right side
			//Just Enable the "Save button" without any check
			$A.util.removeClass(document.getElementById("disableAddUserSaveButtonId"), 'disableAddUserSaveButtonClass');
		}else if(event.getParam("value").length == 0) {
			//This means - No users selected to right side
			//Just Disable the "Save button" anyway
			$A.util.addClass(document.getElementById("disableAddUserSaveButtonId"), 'disableAddUserSaveButtonClass');
		}else if(event.getParam("value").length > 0 && initialDataVar.length > 0) {
			//This is the case where we need to check if any new user being added to right side
			var allSelectedLicensedUsersList = event.getParam("value");
			var flagNoNew = true;
			for(var selectedIndex=0; selectedIndex < allSelectedLicensedUsersList.length; selectedIndex++) {
				var selectedLicensedUserId = allSelectedLicensedUsersList[selectedIndex].split("#")[0];
				if(! initialDataVar.includes(selectedLicensedUserId)) {
					//Atleast one new user added
					flagNoNew = false;
					break;
				}
			}
			if(flagNoNew) {
				//Let the button disable
				$A.util.addClass(document.getElementById("disableAddUserSaveButtonId"), 'disableAddUserSaveButtonClass');
			}else {
				//Enable the button
				$A.util.removeClass(document.getElementById("disableAddUserSaveButtonId"), 'disableAddUserSaveButtonClass');
			}
		}else {
			//Let the button disable
			$A.util.addClass(document.getElementById("disableAddUserSaveButtonId"), 'disableAddUserSaveButtonClass');
		}
    	 
    },
    saveUnlicensedUserData  : function(component, event, helper) {
        component.set("v.spinner", true);
        var action = component.get("c.saveUnlicenseUserDataByModal");
        action.setParams({
            'selectedAllUsersId' : component.get("v.defaultOptions")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state == "SUCCESS") {
                var result = response.getReturnValue();
                console.log('result 577 --> '+JSON.stringify(result));
                 component.set("v.isOpenAddUserScreen", false);
                
            	if(component.get("v.isLightning")) {
                    helper.notifySuccess(result.message, helper);
                } else {
                   //if(!$A.util.isUndefinedOrNull(result.length)) {
                        component.set("v.textMessage", result.message);
                        component.set("v.isToastMessageForVf", true);
                        component.set("v.isSuccessType", true);
                        component.set("v.isInfoType", false);
                        component.set("v.isErrorType", false);
                   // } 
                }
            }
            if(state=="ERROR") {
               	var errors = response.getError();
                var message = '';
                if(errors) {
                    if(errors[0] && errors[0].message) {
                        message = errors[0].message;
                    }
                } else {
                    message= "Unknown Error";
                }
                if(component.get("v.isLightning")) {
                    helper.notifyError(message, helper);
                } else {
                    component.set("v.textMessage", message);
                    component.set("v.isToastMessageForVf", true);
                    component.set("v.isErrorType", true);
                    component.set("v.isInfoType", false);
                    component.set("v.isSuccessType", false);
                }
            }
            component.set("v.spinner", false);
        });
        $A.enqueueAction(action);
    },
    notifySuccess : function(message, helper){
        helper.showEventToast(message, 'success', 'dismissible');
    },
    notifyError : function(message, helper){
        helper.showEventToast(message, 'error', 'dismissible');
    },
    notifyInfo : function(message, helper) {
        helper.showEventToast(message, 'info', 'dismissible')
    },
    showEventToast : function(message, type, mode) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            mode: mode != '' ? mode : 'sticky',
            message: message,
            type: type != '' ? type : 'success',
        });
        toastEvent.fire();
    }
})