({
	doInit: function(component, event, helper) {
        
        var optionsList = [];
        optionsList.push(10);
        optionsList.push(25);
        optionsList.push(50); 
        optionsList.push(100);
        component.set("v.recordsPerPage",10);
        component.set("v.recordsPerPageList",optionsList);
        component.set("v.searchKeyusers", '');
        var action = component.get("c.getUsersData");
        action.setCallback(this, function(response) {
        	var state = response.getState();
            if(state == "SUCCESS") {
            	var records = response.getReturnValue();
	            if(records.length) {
	            	component.set("v.allRecords", records);
	            	component.set("v.maxPage", Math.floor((records.length+9)/10));
	            	var maxPage = component.get("v.maxPage");
	            	component.set("v.pageNumber",1);
	            	helper.sortBy(component, 'name');
	            }
	        }
            if(state == "ERROR") {
                var errors = response.getError();
                if(errors && errors[0] && errors[0].message) {
                    if(component.get("v.isLightning")) {
                        helper.notifyError(errors[0].message, helper);
                    } else {
                        component.set("v.textMessage", errors[0].message);
                        component.set("v.isToastMessageForVf", true);
                        component.set("v.isErrorType", true);
                        component.set("v.isInfoType", false);
                        component.set("v.isSuccessType", false);
                    }  
                }
            }
         });
        $A.enqueueAction(action);
	},
    sortByName: function(component, event, helper) {
        helper.sortBy(component, "name");
    },  
    renderPage: function(component, event, helper) {
        helper.renderPage(component,'v.allRecords','v.pageNumber','v.recordsPerPage','v.currentList','v.maxPage','v.pageNoList');
	},
    renderPageOnRecordsPerPageChange: function(component, event, helper){
        helper.renderPageOnRecordsPerPageChange(component);
    },
    assignProfileScreenOpen: function(component, event, helper) {
        document.getElementsByTagName("BODY")[0].style.overflow = "hidden"; 
        component.set("v.searchKey", "");
        component.set("v.dataIndexId", event.target.getAttribute('data-index'));
        var dataIndexId = component.get("v.dataIndexId");
        helper.assignProfileScreenOpen(component, event, helper, dataIndexId, '');
    },
    closeModal: function(component, event, helper) {
        document.getElementsByTagName("BODY")[0].style.overflow = "visible"; 
        component.set("v.isOpenPopup", false);
    },
    saveModalData : function(component, event, helper) {
        document.getElementsByTagName("BODY")[0].style.overflow = "visible"; 
       	helper.saveModalData(component, event, helper);
    },
    autoSearch : function(component, event, helper) {
        var searchStr = component.get("v.searchKey");
        var dataIndexId = component.get("v.dataIndexId");
        helper.assignProfileScreenOpen(component, event, helper, dataIndexId, searchStr);
	},
    onCheck : function(component, event, helper) {
        helper.onCheck(component, event, helper);
    },
    removeLicenseScreenOpen : function(component, event, helper) {
        document.getElementsByTagName("BODY")[0].style.overflow = "hidden"; 
    	helper.removeLicenseScreenOpen(component, event, helper);  
    },
    closeLicenseModal :  function(component, event, helper) {
        document.getElementsByTagName("BODY")[0].style.overflow = "visible"; 
    	component.set("v.isOpenRemoveScreen", false);  
    },
    removeLicense : function(component, event, helper) {
        document.getElementsByTagName("BODY")[0].style.overflow = "visible"; 
    	helper.removeLicense(component, event, helper);  
    },
    openAddUserScreen : function(component, event, helper) {
        console.log("hello, i am in open add user screen");
        component.set("v.defaultOptions", []);
        component.set("v.defaultOptionsBeforeSearch", []);
        document.getElementsByTagName("BODY")[0].style.overflow = "hidden"; 
        component.set("v.searchKeyAvailable","");
        component.set("v.searchKeySelected","");
        helper.openAddUserScreen(component, event, helper);
    },
    closeAddUserScreen : function(component, event, helper) {
        document.getElementsByTagName("BODY")[0].style.overflow = "visible"; 
      	component.set("v.isOpenAddUserScreen", false);  
    },
    autoSearchDualList : function(component, event, helper) {
      	helper.openAddUserScreen(component, event, helper);
    },
    getSelectedUnlicensedUsers : function(component, event, helper) {
      	helper.getSelectedUnlicensedUsers(component, event, helper);
    },
    saveUnlicensedUserData : function(component, event, helper) {
        document.getElementsByTagName("BODY")[0].style.overflow = "visible"; 
    	helper.saveUnlicensedUserData(component, event, helper);
    },
    autoSearchUsers : function(component, event, helper) {
      	helper.openRemoveUserScreen(component, event, helper);
    },
    openRemoveUserScreen : function(component, event, helper) {
        document.getElementsByTagName("BODY")[0].style.overflow = "hidden"; 
    	component.set("v.searchKeyusers","");
    	helper.openRemoveUserScreen(component, event, helper);
    },
    closeRemoveUserScreen : function(component, event, helper) {
        document.getElementsByTagName("BODY")[0].style.overflow = "visible"; 
    	component.set("v.isopenRemoveUserScreen", false); 
    },
    onCheckUserToBeRemoved : function(component, event, helper) {
    	helper.onCheckUserToBeRemoved(component, event, helper);
    },
    saveRemoveUserData : function(component, event, helper) {
        document.getElementsByTagName("BODY")[0].style.overflow = "visible"; 
    	helper.saveRemoveUserData(component, event, helper);
    },
    autoSearchDualList1 :  function(component, event, helper) {
       
		var selOptName = component.get("v.defaultOptionsBeforeSearch");
		//console.log('---'); 
        var selList = [];
        for(var i=0; i<selOptName.length; i++)  {
            var dArray = selOptName[i].split('#');
          	if(dArray[1].startsWith(component.get("v.searchKeySelected").toLowerCase())) {
                selList.push(selOptName[i]);
            }
        }
        component.set("v.defaultOptions", selList);
        if(selList.length == 0) {
            var message = "No records found.";
            $A.util.addClass(document.getElementById("disableAddUserSaveButtonId"), 'disableAddUserSaveButtonClass');
            
            if(component.get("v.isLightning")) {
                helper.notifyInfo(message, helper);
            } else {
                component.set("v.textMessage", message);
                component.set("v.isToastMessageForVf", true);
                component.set("v.isInfoType", true);
                component.set("v.isErrorType", false);
                component.set("v.isSuccessType", false);
            }
        }else {
        	$A.util.removeClass(document.getElementById("disableAddUserSaveButtonId"), 'disableAddUserSaveButtonClass');
        }
    }
})