({
    getAllData : function(component) {
        var spinner = component.find("spinner");
        var action = component.get("c.retriveData");
        action.setParams({
            'userList' : component.get('v.userList'),
            'startDate':component.get('v.startDate'),
            'endDate':component.get('v.endDate'),
            'sortby':component.get('v.sortby'),
            'sortDirection':component.get('v.sortDirection')
        });
        action.setCallback(this,function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                var mydatafull = response.getReturnValue();
                for(var k in mydatafull){
                   var DateText = mydatafull[k].Last_Logged_In == null ? '' : moment(mydatafull[k].Last_Logged_In, "YYYY-MM-DD").fromNow();
                   var DateNumber = mydatafull[k].Last_Logged_In == null ? '' : mydatafull[k].Last_Logged_In;
                   mydatafull[k].Last_Logged_In = {"DateNumber" : DateNumber,"DateText" : DateText};
                }
                component.set('v.mydatafull',mydatafull);
                var pageSize = component.get('v.pageSize');
                var noofrecords = mydatafull.length;
                var noofpages = Math.ceil(noofrecords/component.get("v.pageSize"));
                
                var pagesLi = [];
                for(var index=1; index <= noofpages; index++) {
                	pagesLi.push(index);
                }
                component.set("v.noofpages", noofpages);
                component.set('v.pagenoLi',pagesLi);
                component.set('v.noofrecords',noofrecords);
                this.helperChange(component);
                $A.util.addClass(spinner, "slds-hide");
            }
        });
        $A.enqueueAction(action);
    },
	helperChange : function(component) {
        component.set('v.disableLast',false);
        component.set('v.disableFirst',false);
        var pageno = component.get("v.pageno");
        var noofpages = component.get("v.noofpages");
        if(pageno>=noofpages) {
            pageno=noofpages;
            component.set('v.disableLast',true);
        }
        if(pageno<=1) {
            pageno=1;
            component.set('v.disableFirst',true);

        }
        component.set("v.pageno", pageno);
        var pageSize = component.get("v.pageSize");
        var fulst = component.get("v.mydatafull");
        var lst = [];
        var j=0;
        var start = (pageno-1)*pageSize;
        var end = pageno*pageSize;
        var noofrecords = component.get("v.noofrecords");
        if(end>noofrecords) {
            end = noofrecords;
        }
        for(var i=start; i<end; i++) {
            
            lst[j] = fulst[i];
            j++;
        }
        component.set("v.mydata", lst);
	},
})