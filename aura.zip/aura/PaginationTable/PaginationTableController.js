({
    getFilterData : function(component,event,helper) {
        var params = event.getParam('arguments');
        if (params) {
            var userList = params.userList;
            component.set('v.userList',userList);
            component.set('v.startDate',params.startDate);
            component.set('v.endDate',params.endDate);
            helper.getAllData(component);   
        }
        
    },
	handelInfo : function(component, event, helper) {
        var columnsArray = [];
        var columnName = {"label":'Name',"value":"Name","helpText":""};
        columnsArray.push(columnName);
        var columnCardExport = {"label":'Cards Exported',"value":"Cards_Exported","helpText":"Count of scanned cards exported to SalesForce."};
        columnsArray.push(columnCardExport);
        var columnCapture = {"label":'Captures Exported',"value":"Captures_Exported","helpText":"Count of email capture signatures exported to SalesForce."};
        columnsArray.push(columnCapture);
        var columnTotal = {"label":'Total',"value":"Total","helpText":"Sum of Cards Exported & Capture Exported."};
        columnsArray.push(columnTotal);
        var columnLastLog = {"label":'Last Logged In',"value":"Last_Logged_In","helpText":""};
        columnsArray.push(columnLastLog);
        var columns = ['Name','Cards_Exported','Captures_Exported','Total','Last_Logged_In'];
        component.set('v.mycolumns',columnsArray);
        helper.getAllData(component);
        var labelPageNo = component.find('ChangePageNoId');
        console.log(labelPageNo);
		
	},
    first : function(component,event,helper) {
        component.set("v.pageno", 1);
        helper.helperChange(component);
    },
    
    next : function(component, event, helper) {
        var pageno = component.get("v.pageno");
        pageno++;
        component.set("v.pageno", pageno);
        helper.helperChange(component);
    },
    
    previous : function(component, event, helper) {
       var pageno = component.get("v.pageno");
        pageno--;
        component.set("v.pageno", pageno);
        helper.helperChange(component);
    },
    
    last : function(component,event,helper) {
        var last = component.get("v.noofpages");
        component.set("v.pageno", last);
        helper.helperChange(component);
    },
    
    changePageNo : function(component, event, helper) {
        helper.helperChange(component);
        
    },
    handelSort : function(component, event, helper) {
        var spinner = component.find("spinner");
        $A.util.toggleClass(spinner, "slds-hide");
        var drec = component.get("v.sortDirection");
        var value =  event.target.getAttribute("data-value");
        var val;
        if(drec == 'ASC'){
            component.set("v.sortDirection","DESC");
        }else {
            component.set("v.sortDirection","ASC");
        }
        component.set("v.sortby",value);
        helper.getAllData(component);  
    },
    
    handelPageSize : function(component, event, helper) {
        
        var noofpages = Math.ceil(component.get('v.noofrecords')/component.get("v.pageSize"));
        var pagesLi = [];
        for(var index=1; index <= noofpages; index++) {
        	pagesLi.push(index);
        }
        component.set("v.pageno", 1);
        component.set('v.pagenoLi',pagesLi);
        component.set("v.noofpages", noofpages);
        
        helper.helperChange(component);
    }
})