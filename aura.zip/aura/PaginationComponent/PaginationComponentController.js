({ 
	prevPage: function(component, event, helper) {
        component.set("v.currentPageNumber", Math.max(parseInt(component.get("v.currentPageNumber"))-1, 1));
    },
    nextPage: function(component, event, helper) {
    	console.log('Let us see the issue Next Page---- ', typeof component.get("v.currentPageNumber"));  
        component.set("v.currentPageNumber", Math.min(parseInt(component.get("v.currentPageNumber"))+1, component.get("v.maxPageNumber")));
    },
    forcefullyChange : function(component, event, helper) {
        //component.set("v.currentPageNumber", Math.min(parseInt(component.get("v.currentPageNumber"))+1, component.get("v.maxPageNumber")));
        //console.log('Let us see the issue UPDATED---- ', typeof component.get("v.currentPageNumber"));
        component.set("v.currentPageNumber", parseInt(component.get("v.currentPageNumber")));  
    } 
})