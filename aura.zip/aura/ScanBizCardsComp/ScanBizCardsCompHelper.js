({
	processInit : function(component, event, helper) {
		var action = component.get("c.processInit");
		action.setCallback(this, function(response) {
			var state = response.getState();
			if(component.isValid() && state === "SUCCESS") {
				console.log('---All done--- Init---');
				var tracker = component.get("v.trackSpinnerCounter");
				if(component.get("v.isAddInit")) {
					tracker--;
					component.set("v.trackSpinnerCounter", tracker)
				}
			}
		});
		$A.enqueueAction(action);
	}, 
	restoreToDefault : function(component, event, helper) {
		console.log(component.get("v.rId"));
		var optionsList = [];
		optionsList.push(10);
		optionsList.push(25);
		optionsList.push(50); 
		optionsList.push(100);
		component.set("v.recordsPerPage",10);
		component.set("v.recordsPerPageList",optionsList);

		component.set("v.isSelectedTab", 'General Settings');
		component.set("v.isObjType", "General");
		component.set("v.isStandardOrCustom", false);
		component.set("v.isSetting", false);
		component.set("v.isRecordType", false);
		
        //this code was moved from below- to show tabs
        helper.getAllTabs(component, event, helper);
		
        //Fill field related data
		helper.selectedItemHelper(component, event, helper, "Account Custom Fields");
		helper.selectedItemHelper(component, event, helper, "Account Standard Fields");
		
		/* Person  Account */
		helper.selectedItemHelper(component, event, helper, "PersonAccount Custom Fields");
		helper.selectedItemHelper(component, event, helper, "PersonAccount Standard Fields");
		/* Person Account */
		
		helper.selectedItemHelper(component, event, helper, "Contact Custom Fields");
		helper.selectedItemHelper(component, event, helper, "Contact Standard Fields");
		helper.selectedItemHelper(component, event, helper, "Lead Custom Fields");
		helper.selectedItemHelper(component, event, helper, "Lead Standard Fields");

		//Fill object related setting
		helper.retrieveSettingDataHelper(component, event, helper, "Account Account Settings");
		helper.retrieveSettingDataHelper(component, event, helper, "Contact Contact Settings");
		helper.retrieveSettingDataHelper(component, event, helper, "Lead Lead Settings");

		//Fill record type info
		helper.retrieveRecordTypesHelper(component, event, helper, "Account Record Types");
		helper.retrieveRecordTypesHelper(component, event, helper, "Contact Record Types");
		helper.retrieveRecordTypesHelper(component, event, helper, "Lead Record Types"); 
		helper.retrieveRecordTypesHelper(component, event, helper, "PersonAccount Record Types");  

		//Fill general setting data
		helper.generalSettingList(component, event, helper);

		//Fill Org Data related data
		helper.accountListHelper(component, event, helper);
		helper.campaignListHelper(component, event, helper);
		helper.leadOwnerListHelper(component, event, helper);
		
		//Code Added by Chetan (May 22, 2019)
		//Fill Account Record Type object
		helper.fetchAccountRecordTypesForDropDown(component, event, helper);
		//helper.getAllTabs(component, event, helper); moved this function above to show tabs, due to issues this section was not showing
		
		helper.processInit(component, event, helper); 
		helper.getFieldTypeOptions(component, event, helper);

		//For sorting on load calling
		//helper.sortByAccName(component,"Name");
		//helper.sortByCampName(component, "Name");
		//helper.sortByLeadOwnersName(component, "Name");

		//Object initialisation
		var mapOfDescriptionWithObject = {}; //or can use new map();

	mapOfDescriptionWithObject['General Settings'] 					= 'General Settings covers basic settings available in the app. They are mostly set as Yes/No options with the exception of selecting Object type (Leads/Contacts). All of these settings have Help text to assist users.';
        
        mapOfDescriptionWithObject['Account Settings'] 				= 'Account Settings covers basic settings available for Accounts.';
        mapOfDescriptionWithObject['Account Standard Fields'] 		= 'Account Standard fields are the default fields supplied by Salesforce for the Account object. Few settings are automatically set by ScanBizCards, for these fields we will auto populate data after scanning business card without any manual user input. Wherever you don’t see this, you’ll have to manually provide a value, or supply a default value if you want to include it in the export.';
        mapOfDescriptionWithObject['Account Custom Fields'] 		= 'Account Custom fields are by default turned off for export. The only exception is if they are MANDATORY, in which case they will be turned on and prompt for a value automatically. They will NEVER automatically provide a value from a scan and will require you to map them to standard field if you wish to provide scanned info.';
        mapOfDescriptionWithObject['Account Record Types'] 			= 'This page will show all Account record types available in your SalesForce instance. You will be able to determine which record types to include AND if one is set to default.';
        
        mapOfDescriptionWithObject['Contact Settings'] 				= 'Contact Settings covers the basic settings available for Contacts.';
        mapOfDescriptionWithObject['Contact Standard Fields'] 		= 'Contact Standard fields are the default fields supplied by Salesforce for the Contact object. Few settings are automatically set by ScanBizCards, for these fields we will auto populate data after scanning business card without any manual user input. Wherever you don’t see this, you’ll have to manually provide a value, or supply a default value if you want to include it in the export.';
        
        mapOfDescriptionWithObject['Contact Custom Fields'] 		= 'Contact Custom fields are by default turned off for export. The only exception is if they are MANDATORY, in which case they will be turned on and prompt for a value automatically. They will NEVER automatically provide a value from a scan and will require you to map them to standard field if you wish to provide scanned info.';
        mapOfDescriptionWithObject['Contact Record Types'] 			= 'This page will show all Contact record types available in your SalesForce instance. You’ll be able to determine which record types to include AND if one is set to default.';
        
        mapOfDescriptionWithObject['Lead Settings'] 				= 'Lead Settings covers basic settings available for Leads.';
        mapOfDescriptionWithObject['Lead Standard Fields'] 			= 'Lead Standard fields are the default fields supplied by Salesforce for each Lead. Few settings are automatically set by ScanBizCards, for these fields we will auto populate data after scanning business card without any manual user input.';
        mapOfDescriptionWithObject['Lead Custom Fields'] 			= 'Lead Custom fields are by default turned off for export. The only exception is if they are required, in which case they will be turned on and prompt for a value automatically. Note, however, that they will not be automatically populated by any data scanned on the business card, although it is possible to configure it this way using the “Map from scanned field” property.';
        mapOfDescriptionWithObject['Lead Record Types'] 			= 'This page will show all lead record types available in your SalesForce instance. You’ll be able to determine which record types to include AND if one is set to default.';
        
        mapOfDescriptionWithObject['Accounts']  					= 'This section displays all Accounts available in your Salesforce instance. The Accounts will display their name, and geographic location (City/State, if available). You will have the ability to turn off specific Accounts that you do not wish your users to be able to assign Contacts to during exports. (Note that this has no effect on Lead exports — and this will NOT give users access to accounts that they would otherwise not have access to).';
        mapOfDescriptionWithObject['Campaigns'] 					= 'This section will display all the campaigns available in your salesforce instance. It allows you to control to which campaigns, if any, end users will be able to assign to a Lead or Contact during an export. In addition to this functionality, you can customize “Description” text which displays alongside the campaign during an export.';
        mapOfDescriptionWithObject['Lead Owners'] 					= 'This section allows you to control which Users or Queues, if any, the end user will be able to specify as the Owner of the Lead during an export.';
        
        var custs = [];
		for(var key in mapOfDescriptionWithObject) {
			custs.push({
				value : mapOfDescriptionWithObject[key],
				key   : key
			});
		}
		component.set("v.mapOfDescWithObj", custs);
		
		//No problem if called before other callback functions
		//component.set("v.selectedTreeItem", "General Settings General Settings");	
		//component.set("v.openSection", "General Settings");		
	},
	sortByAccName: function(component, field) {

		var sortAsc = component.get("v.sortAscAcc");
		var sortField = component.get("v.sortField");

		//SAL-147 - Filter and sort will give pagination the all list which is a bug so filtered accounts must be used
		//var allRecords = component.get("v.listOfAccount");
		var allRecords = component.get("v.currentFilteredList");

		sortAsc = sortField != field || !sortAsc;
		allRecords.sort(function(a,b){
			var t1 = a[field].toLowerCase() == b[field].toLowerCase(),
			t2 = (!a[field] && b[field].toLowerCase()) || (a[field].toLowerCase() < b[field].toLowerCase());
			return t1? 0: (sortAsc?-1:1)*(t2?1:-1);
		});
		component.set("v.sortAscAcc", sortAsc);
		component.set("v.sortField", field);
		if(component.get("v.isSelectedTab") == 'Accounts') {
			//SAL-147
			//component.set("v.listOfAccount", allRecords);
			//this.renderPage(component,'v.listOfAccount','v.pageNumber','v.recordsPerPage','v.currentList','v.maxPage','v.pageNoList');
			component.set("v.currentFilteredList", allRecords);
			this.renderPage(component, 'v.currentFilteredList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
		}
	}, 
	sortInitialAccountName: function(component, field, isSortAsc) {
		var sortAsc = isSortAsc;
		var allRecords = component.get("v.listOfAccount");
		console.log('All listOfAccount filter before---- ', allRecords);
		//console.log('Initially before sorting 321654---- ', allRecords);  
		allRecords.sort(function(a,b){
			var t1 = a[field].toLowerCase() == b[field].toLowerCase(),
			t2 = (!a[field] && b[field].toLowerCase()) || (a[field].toLowerCase() < b[field].toLowerCase());
			return t1? 0: (sortAsc?-1:1)*(t2?1:-1);
		});

		component.set("v.listOfAccount", allRecords);      
		console.log('All listOfAccount filter after---- ', allRecords);
	},	
	sortByCampName: function(component, field) {
		var sortAsc = component.get("v.sortAscCamp");
		var sortField = component.get("v.sortField");

		//SAL-147 - Filter and sort will give pagination the all list which is a bug so filtered accounts must be used
		//var allRecords = component.get("v.currentFilteredList");
		var allRecords = component.get("v.currentFilteredCampList");

		sortAsc = sortField != field || !sortAsc;
		allRecords.sort(function(a,b){
			var t1 = a[field].toLowerCase() == b[field].toLowerCase(),
			t2 = (!a[field] && b[field].toLowerCase()) || (a[field].toLowerCase() < b[field].toLowerCase());
			return t1? 0: (sortAsc?-1:1)*(t2?1:-1);
		});
		component.set("v.sortAscCamp", sortAsc);
		component.set("v.sortField", field);
		if(component.get("v.isSelectedTab") == 'Campaigns') {
			//SAL-147
			//component.set("v.currentFilteredList", allRecords);
			//this.renderPage(component, 'v.currentFilteredList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
			component.set("v.currentFilteredCampList", allRecords);
			this.renderPage(component, 'v.currentFilteredCampList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
		}
	}, 
	sortInitialCampaignName: function(component, field, isSortAsc) {
		var sortAsc = isSortAsc;
		var allRecords = component.get("v.listOfCampaign");
		console.log('All listOfCampaign filter before---- ', allRecords);
		//console.log('Initially before sorting 321654---- ', allRecords);  
		allRecords.sort(function(a,b){
			var t1 = a[field].toLowerCase() == b[field].toLowerCase(),
			t2 = (!a[field] && b[field].toLowerCase()) || (a[field].toLowerCase() < b[field].toLowerCase());
			return t1? 0: (sortAsc?-1:1)*(t2?1:-1);
		});

		component.set("v.listOfCampaign", allRecords);      
		console.log('All listOfCampaign filter after---- ', allRecords);
	},	
	sortByLeadOwnersName: function(component, field) {
		
		var sortAsc = component.get("v.sortAscLeadOwner");
		var sortField = component.get("v.sortField");
		//SAL-147
		//var allRecords = component.get("v.listOfLeadOwners");
		
		var allRecords = component.get("v.currentFilteredLeadOwnerList");
		console.log('Initially before sorting---- ', allRecords);  
		sortAsc = sortField != field || !sortAsc;
		allRecords.sort(function(a,b){
			var t1 = a[field].toLowerCase() == b[field].toLowerCase(),
			t2 = (!a[field] && b[field].toLowerCase()) || (a[field].toLowerCase() < b[field].toLowerCase());
			return t1? 0: (sortAsc?-1:1)*(t2?1:-1);
		});
		component.set("v.sortAscLeadOwner", sortAsc);
		component.set("v.sortField", field);

		component.set("v.currentFilteredLeadOwnerList", allRecords);      
		console.log('After  sorting---- ', allRecords);
		if(component.get("v.isSelectedTab") == 'Lead Owners') {
			//SAL-147
			//component.set("v.listOfLeadOwners", allRecords);
			//this.renderPage(component,'v.listOfLeadOwners','v.pageNumber','v.recordsPerPage','v.currentList','v.maxPage','v.pageNoList');

			this.renderPage(component, 'v.currentFilteredLeadOwnerList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
		}
	},
	sortInitialLeadOwnersName: function(component, field, isSortAsc) {
		var sortAsc = isSortAsc;
		var allRecords = component.get("v.listOfLeadOwners");
		console.log('All lead filter before---- ', allRecords);
		//console.log('Initially before sorting 321654---- ', allRecords);  
		allRecords.sort(function(a,b){
			var t1 = a[field].toLowerCase() == b[field].toLowerCase(),
			t2 = (!a[field] && b[field].toLowerCase()) || (a[field].toLowerCase() < b[field].toLowerCase());
			return t1? 0: (sortAsc?-1:1)*(t2?1:-1);
		});

		component.set("v.listOfLeadOwners", allRecords);      
		console.log('All lead filter after---- ', allRecords);
	},    
	fetchFieldDataHelper : function(component, event, helper, sItem, attributeName) {
		component.set("v.spinner", true);
		var action = component.get("c.fetchObjectData");
		 var profileIdToFetchData = component.get("v.isRestoreToDefault") ? null : (component.get("v.childDraftId") ? component.get("v.childDraftId") : component.get("v.rId"));
		action.setParams({
			'objType': sItem,
			'recordId' : profileIdToFetchData
		});
		action.setCallback(this, function(response) {
			var state = response.getState();
			if(component.isValid() && state === "SUCCESS") {
				var result = response.getReturnValue();
				component.set(attributeName, result); //"v.objDataWrapper"

				var tracker = component.get("v.trackSpinnerCounter");
				if(component.get("v.isAddInit")) {
					tracker--;
					component.set("v.trackSpinnerCounter", tracker)
				}
				
				if(attributeName === 'v.personAccountCustomFieldWrapper') {
					console.log('Person Account Custom Fields --- ', result);
				}else if(attributeName === 'v.personAccountStandardFieldWrapper') {
					console.log('Person Account Standard Fields --- ', result);
				}
			}
			else if (state === "ERROR") {
				var errors = response.getError();
				if (errors) {
					if (errors[0] && errors[0].message) {

						if(component.get("v.isLightning")) {
							helper.notifyError(errors[0].message, helper);
						} else {
							component.set("v.textMessage", errors[0].message);
							component.set("v.isToastMessageForVf", true);
							component.set("v.isErrorType", true);
							component.set("v.isInfoType", false);
							component.set("v.isSuccessType", false);
							
							//Calling Auto Close Toast Message method
							helper.autoRemoveToastMessage(component, event, helper);
						}
					}
				} else {
					var message = "Unknown error";

					if(component.get("v.isLightning")) {
						helper.notifyError(message, helper);
					} else {
						component.set("v.textMessage", message);
						component.set("v.isToastMessageForVf", true);
						component.set("v.isErrorType", true);
						component.set("v.isInfoType", false);
						component.set("v.isSuccessType", false);
						
						//Calling Auto Close Toast Message method
						helper.autoRemoveToastMessage(component, event, helper);
					}
				}
			}
			window.scrollTo(0, 0);
			component.set("v.spinner", false);
		});
		$A.enqueueAction(action);//$A represents Aura
	},  

	selectedItemHelper : function(component, event, helper, sItem) {
		console.log('In helper-----');
		console.log(sItem);
		if(sItem.includes('Standard') || sItem.includes('Custom')) {
			var attributeName;
			if(sItem.includes('Standard') && sItem.includes('Account') && !sItem.includes('PersonAccount')) {
				attributeName = "v.accountStandardFieldWrapper";
			}else if(sItem.includes('Custom') && sItem.includes('Account') && !sItem.includes('PersonAccount')) {
				attributeName = "v.accountCustomFieldWrapper";
			}else if(sItem.includes('Standard') && sItem.includes('Contact')) {
				attributeName = "v.contactStandardFieldWrapper";
			}else if(sItem.includes('Custom') && sItem.includes('Contact')) {
				attributeName = "v.contactCustomFieldWrapper";
			}else if(sItem.includes('Standard') && sItem.includes('Lead')) {
				attributeName = "v.leadStandardFieldWrapper";
			}else if(sItem.includes('Custom') && sItem.includes('Lead')) {
				attributeName = "v.leadCustomFieldWrapper";
			}else if(sItem.includes('Standard') && sItem.includes('PersonAccount')) {
				attributeName = "v.personAccountStandardFieldWrapper";
			}else if(sItem.includes('Custom') && sItem.includes('PersonAccount')) {
				attributeName = "v.personAccountCustomFieldWrapper";
			}
			helper.fetchFieldDataHelper(component, event, helper, sItem, attributeName); 
			//helper.getFieldTypeOptions(component, event, helper);
		}      	
	},

	getFieldTypeOptions : function(component, event, helper) {
		var action = component.get("c.getScannedFieldType");
		action.setCallback(this, function(response) {
			var state = response.getState();
			if(component.isValid() && state === "SUCCESS") {
				var result = response.getReturnValue();
				component.set("v.fieldTypeOptions", result);

				var tracker = component.get("v.trackSpinnerCounter");
				if(component.get("v.isAddInit")) {
					tracker--;
					component.set("v.trackSpinnerCounter", tracker)
				}
			}
			else if (state === "ERROR") {
				var errors = response.getError();
				if (errors) {
					if (errors[0] && errors[0].message) {

						if(component.get("v.isLightning")) {
							helper.notifyError(errors[0].message, helper);
						} else {
							component.set("v.textMessage", errors[0].message);
							component.set("v.isToastMessageForVf", true);
							component.set("v.isErrorType", true);
							component.set("v.isInfoType", false);
							component.set("v.isSuccessType", false);
							
							//Calling Auto Close Toast Message method
							helper.autoRemoveToastMessage(component, event, helper);
						}
					}
				} else {
					var message = "Unknown error";
					if(component.get("v.isLightning")) {
						helper.notifyError(message, helper);
					} else {
						component.set("v.textMessage", message);
						component.set("v.isToastMessageForVf", true);
						component.set("v.isErrorType", true);
						component.set("v.isInfoType", false);
						component.set("v.isSuccessType", false);
						
						//Calling Auto Close Toast Message method
						helper.autoRemoveToastMessage(component, event, helper);
					}
				}
			}
			window.scrollTo(0, 0);
		});
		$A.enqueueAction(action);//$A represents Aura
	},

	retrieveSettingDataHelper : function(component, event, helper, sItem) {
		console.log('In retrieveSettingDataHelper-----');
		console.log(sItem);
		var attributeName;
		if(sItem.includes('Account')) {
			attributeName = "v.accountSettingWrapper";
		}else if(sItem.includes('Contact')) {
			attributeName = "v.contactSettingWrapper";
		}else if(sItem.includes('Lead')) {
			attributeName = "v.leadSettingWrapper";
		}
		helper.retrieveSettingData(component, event, helper, sItem, attributeName);      	
	},

	retrieveSettingData : function(component, event, helper, sItem, attributeName) {
		component.set("v.spinner", true);
        var action = component.get("c.loadSettingById");
        var profileIdToFetchData = component.get("v.isRestoreToDefault") ? null : (component.get("v.childDraftId") ? component.get("v.childDraftId") : component.get("v.rId")); 
		action.setParams({
			'objType': sItem,
			'recordId' : profileIdToFetchData
		});
		action.setCallback(this, function(response) {
			var state = response.getState();
			if(component.isValid() && state === "SUCCESS") {
				var result = response.getReturnValue();
				component.set(attributeName, result);
				var tracker = component.get("v.trackSpinnerCounter");
				if(component.get("v.isAddInit")) {
					tracker--;
					component.set("v.trackSpinnerCounter", tracker)
				}
				
				if(attributeName === 'v.accountSettingWrapper') {
					if(result.length == 4) {
						component.set("v.isPersonAccountAllowed", result[2]["isValue"]);
						console.log('----isPersonAccountAllowed------ ', result[2]["isValue"]);   
					}
				}
			}
			else if (state === "ERROR") {
				var errors = response.getError();
				if (errors) {
					if (errors[0] && errors[0].message) {
						if(component.get("v.isLightning")) {
							helper.notifyError(errors[0].message, helper);
						} else {
							component.set("v.textMessage", errors[0].message);
							component.set("v.isToastMessageForVf", true);
							component.set("v.isErrorType", true);
							component.set("v.isInfoType", false);
							component.set("v.isSuccessType", false);
							
							//Calling Auto Close Toast Message method
							helper.autoRemoveToastMessage(component, event, helper);
						}
					}
				} else {
					var message = "Unknown error";
					if(component.get("v.isLightning")) {
						helper.notifyError(message, helper);
					} else {
						component.set("v.textMessage", message);
						component.set("v.isToastMessageForVf", true);
						component.set("v.isErrorType", true);
						component.set("v.isInfoType", false);
						component.set("v.isSuccessType", false);
						
						//Calling Auto Close Toast Message method
						helper.autoRemoveToastMessage(component, event, helper);
					}
				}
			}
			window.scrollTo(0, 0);
			component.set("v.spinner", false);
		});
		$A.enqueueAction(action);//$A represents Aura
	},

	retrieveRecordTypesHelper : function(component, event, helper, sItem) {
		console.log('retrieveRecordTypesHelper-----');
		var attributeName;
		//var objectNameVar;
		if(sItem.includes('Account') && !sItem.includes('PersonAccount')) {
			attributeName = "v.accountRecordTypeWrapper";
		}else if(sItem.includes('Contact')) {
			attributeName = "v.contactRecordTypeWrapper";
		}else if(sItem.includes('Lead')) {
			attributeName = "v.leadRecordTypeWrapper";
		}else if(sItem.includes('PersonAccount')) {
			attributeName = "v.personAccountRecordTypeWrapper";
		}   

		helper.retrieveRecordTypes(component, event, helper, sItem, attributeName);     
	},

	retrieveRecordTypes : function(component, event, helper, sItem, attributeName) {
        var action = component.get("c.fetchRecordTypes");
        var profileIdToFetchData = component.get("v.isRestoreToDefault") ? null : (component.get("v.childDraftId") ? component.get("v.childDraftId") : component.get("v.rId"));
		console.log('Object type we send For Loading record Type--------%%%%%%%%% ', sItem);
		action.setParams({
			'objType': sItem,
			'recordId' : profileIdToFetchData
		});
		action.setCallback(this, function(response) {
			var state = response.getState();
			if(component.isValid() && state === "SUCCESS") {
				console.log(response.getReturnValue());
				var result = response.getReturnValue();
				console.log('Record Type Fetch Result');
				console.log(result);
				component.set(attributeName, result);
				var tracker = component.get("v.trackSpinnerCounter");
				if(component.get("v.isAddInit")) {
					tracker--;
					component.set("v.trackSpinnerCounter", tracker)
				}
			}
			else if (state === "ERROR") {
				var errors = response.getError();
				if (errors) {
					if (errors[0] && errors[0].message) {
						if(component.get("v.isLightning")) {
							helper.notifyError(errors[0].message, helper);
						} else {
							component.set("v.textMessage", errors[0].message);
							component.set("v.isToastMessageForVf", true);
							component.set("v.isErrorType", true);
							component.set("v.isInfoType", false);
							component.set("v.isSuccessType", false);
							
							//Calling Auto Close Toast Message method
							helper.autoRemoveToastMessage(component, event, helper);
						}
					}
				} else {
					var message = "Unknown error";
					if(component.get("v.isLightning")) {
						helper.notifyError(message, helper);
					} else {
						component.set("v.textMessage", message);
						component.set("v.isToastMessageForVf", true);
						component.set("v.isErrorType", true);
						component.set("v.isInfoType", false);
						component.set("v.isSuccessType", false);
						
						//Calling Auto Close Toast Message method
						helper.autoRemoveToastMessage(component, event, helper);
					}
				}
			}
			window.scrollTo(0, 0);
			//component.set("v.spinner", false);
		});
		$A.enqueueAction(action);//$A represents Aura   
	},

	accountListHelper : function(component, event, helper) {
		var searchingValName = component.get("v.searchKeyName");
		var searchingValState = component.get("v.searchKeyState");
		var selectedRecordTypes = component.get("v.selectedRecordType");
		//var action = component.get("c.buildAccountList");
		var action = component.get("c.buildAccountUpdatedList"); //moreRecordsExistAccount moreRecordsAfterFilterExistAccount
		var profileIdToFetchData = component.get("v.isRestoreToDefault") ? null : (component.get("v.childDraftId") ? component.get("v.childDraftId") : component.get("v.rId"));
		action.setParams({
			'searchKeyName'  			: searchingValName,
			'searchKeyState' 			: searchingValState,
			'recordId'       			: profileIdToFetchData,
			'listSelectedRecordTypeIds'	: selectedRecordTypes
		});
		action.setCallback(this, function(response) {
			var state = response.getState();
			if(component.isValid() && state === "SUCCESS") {
				var result = response.getReturnValue();
				console.log('List of Accounts Test@@@@@@@@@@@@');
				console.log(result.accountList);
				component.set("v.listOfAccount", result.accountList);
				component.set("v.moreRecordsExistAccount", result.moreRecordsExist);
				component.set("v.moreRecordsAfterFilterExistAccount", result.moreRecordsAfterFilterExist);
				helper.sortInitialAccountName(component, "Name", true);
				
				//Initialy set filtered list to ALL
				component.set("v.currentFilteredList", result.accountList);
				helper.sortByAccName(component, "Name");
				var tracker = component.get("v.trackSpinnerCounter");
				if(component.get("v.isAddInit")) {
					tracker--;
					component.set("v.trackSpinnerCounter", tracker)
				} 
			}
			else if (state === "ERROR") {
				var errors = response.getError();
				if (errors) {
					if (errors[0] && errors[0].message) {
						if(component.get("v.isLightning")) {
							helper.notifyError(errors[0].message, helper);
						} else {
							component.set("v.textMessage", errors[0].message);
							component.set("v.isToastMessageForVf", true);
							component.set("v.isErrorType", true);
							component.set("v.isInfoType", false);
							component.set("v.isSuccessType", false);
							
							//Calling Auto Close Toast Message method
							helper.autoRemoveToastMessage(component, event, helper);
						}
					}
				} else {
					var message = "Unknown error";
					if(component.get("v.isLightning")) {
						helper.notifyError(message, helper);
					} else {
						component.set("v.textMessage", message);
						component.set("v.isToastMessageForVf", true);
						component.set("v.isErrorType", true);
						component.set("v.isInfoType", false);
						component.set("v.isSuccessType", false);
						
						//Calling Auto Close Toast Message method
						helper.autoRemoveToastMessage(component, event, helper);
					}
				}
			}
			window.scrollTo(0, 0);
			//component.set("v.spinner", false);
		});
		$A.enqueueAction(action);
	},

	accountList : function(component, event, helper) {
		var delayTimer = component.get("v.timeoutReferenceAccount");
		if(delayTimer) {
			window.clearTimeout(delayTimer);
		}

		delayTimer = window.setTimeout(
				$A.getCallback(function() {
				if (component.isValid()) {
					var searchingValName = component.get("v.searchKeyName");
                var searchingValState = component.get("v.searchKeyState");
                var selectedRecordTypes = component.get("v.selectedRecordType");
                var profileIdToFetchData = component.get("v.isRestoreToDefault") ? null : (component.get("v.childDraftId") ? component.get("v.childDraftId") : component.get("v.rId"));
					//var action = component.get("c.buildAccountList");
					var action = component.get("c.buildAccountUpdatedList");
					action.setParams({
						'searchKeyName'  			: searchingValName,
						'searchKeyState' 			: searchingValState,
						'recordId'       			: profileIdToFetchData,
						'listSelectedRecordTypeIds'	: selectedRecordTypes
					});
					action.setCallback(this, function(response) {
						var state = response.getState();
						if(component.isValid() && state === "SUCCESS") {
							var result = response.getReturnValue();
							console.log('Resulit 1 - @@@@'+result);
							console.log('List of Accounts Test#####');
							console.log(result.accountList);
							//component.set("v.listOfAccount", result);  //sortByAccName //sortInitialAccountName
							component.set("v.listOfAccount", result.accountList);
							component.set("v.moreRecordsExistAccount", result.moreRecordsExist);
							component.set("v.moreRecordsAfterFilterExistAccount", result.moreRecordsAfterFilterExist);   
							
							if(component.get("v.sortAscAcc")) {  
								helper.sortInitialAccountName(component, "Name", false);
							}else {
								helper.sortInitialAccountName(component, "Name", true);  
							}
							
							//Initialy set filtered list to ALL
							//component.set("v.currentFilteredList", result);
							component.set("v.currentFilteredList", result.accountList);

							component.set("v.maxPage", Math.floor((result.accountList.length+9)/10));
							var maxPage = component.get("v.maxPage");
							component.set("v.pageNumber",1);

							//For sorting -
							//After filtering the data is being sorted in ascending order
							//1. Check if he sorting item is in ASC then no issue
							//2. If the icon is in DESC then make sure to sort item in descending order and align the items
							/*
							if(! component.get("v.sortAscAcc")) {
								helper.sortByAccName(component, "Name");
								helper.sortByAccName(component, "Name");
							}  
						 	*/
						 	if(component.get("v.sortAscAcc")) {
								component.set("v.sortAscAcc", false);
								helper.sortByAccName(component, "Name");
							}else {
								helper.sortByAccName(component, "Name");  
								helper.sortByAccName(component, "Name");     
							}
              

							//helper.renderPage(component, 'v.listOfAccount', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
							helper.renderPage(component, 'v.currentFilteredList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
							//component.set("v.listOfAccount", result);

							if(result.accountList.length == 0) {
								var message = 'There is no such record starts with ';

								if(searchingValName != '' && searchingValState == '') {
									message += searchingValName;
								}  
								else if(searchingValState != '' && searchingValName == '') {
									message += searchingValState;
								} else if(selectedRecordTypes != null && selectedRecordTypes.length > 0)
									message = 'There is no such record available with selected Record Type';

								if(component.get("v.isLightning")) {
									helper.notifyInfo(message, helper);
								} else {
									component.set("v.textMessage", message);
									component.set("v.isToastMessageForVf", true);
									component.set("v.isInfoType", true);
									component.set("v.isErrorType", false);
									component.set("v.isSuccessType", false);
									
									//Calling Auto Close Toast Message method
									helper.autoRemoveToastMessage(component, event, helper);
								}
							}
						}
						else if (state === "ERROR") {
							var errors = response.getError();
							if (errors) {
								if (errors[0] && errors[0].message) {
									if(component.get("v.isLightning")) {
										helper.notifyError(errors[0].message, helper);
									} else {
										component.set("v.textMessage", errors[0].message);
										component.set("v.isToastMessageForVf", true);
										component.set("v.isErrorType", true);
										component.set("v.isInfoType", false);
										component.set("v.isSuccessType", false);
										
										//Calling Auto Close Toast Message method
										helper.autoRemoveToastMessage(component, event, helper);
									}
								}
							} else {
								var message = "Unknown error";
								if(component.get("v.isLightning")) {
									helper.notifyError(message, helper);
								} else {
									component.set("v.textMessage", message);
									component.set("v.isToastMessageForVf", true);
									component.set("v.isErrorType", true);
									component.set("v.isInfoType", false);
									component.set("v.isSuccessType", false);
									
									//Calling Auto Close Toast Message method
									helper.autoRemoveToastMessage(component, event, helper);
								}
							}
						}
						component.set("v.spinner", false);
						window.scrollTo(0,0);
					});
					$A.enqueueAction(action);
				}
				}), 1000
		);

		component.set("v.timeoutReferenceAccount", delayTimer);
	},

	campaignList : function(component, event, helper) {
		var delayTimer = component.get("v.timeoutReferenceCampaign");
		if(delayTimer) {
			window.clearTimeout(delayTimer);
		}

		delayTimer = window.setTimeout(
				$A.getCallback(function() {
				if (component.isValid()) {
					var searchingValName = component.get("v.searchKeyNameCampaign");	//component.get("v.searchKeyName");
                var searchingValState = component.get("v.searchDescriptionCampaign");			//component.get("v.searchKeyState");
                var profileIdToFetchData = component.get("v.isRestoreToDefault") ? null : (component.get("v.childDraftId") ? component.get("v.childDraftId") : component.get("v.rId"));
					//var action = component.get("c.buildCampaignList");
					var action = component.get("c.buildCampaignUpdatedList");
					action.setParams({
						'searchKeyName'  : searchingValName,
						'searchKeyState' : searchingValState,
						'recordId'       : profileIdToFetchData
					});
					action.setCallback(this, function(response) {
						var state = response.getState();
						if(component.isValid() && state === "SUCCESS") {
							var result = response.getReturnValue();
							console.log('Resulit 2 - @@@@'+result);
							component.set("v.listOfCampaign", result.campaignList);
							component.set("v.moreRecordsExistCampaign", result.moreRecordsExist);  
							component.set("v.moreRecordsAfterFilterExistCampaign", result.moreRecordsAfterFilterExist);
							if(component.get("v.sortAscCamp")) {  
								helper.sortInitialCampaignName(component, "Name", false);
							}else {
								helper.sortInitialCampaignName(component, "Name", true);  
							}
							
							//Initialy set filtered list to ALL
							component.set("v.currentFilteredCampList", result.campaignList);

							component.set("v.maxPage", Math.floor((result.campaignList.length+9)/10));
							var maxPage = component.get("v.maxPage");
							component.set("v.pageNumber",1);

							//For sorting -
							//After filtering the data is being sorted in ascending order
							//1. Check if he sorting item is in ASC then no issue
							//2. If the icon is in DESC then make sure to sort item in descending order and align the items
							/*
							if(! component.get("v.sortAscCamp")) {
								helper.sortByCampName(component, "Name");
								helper.sortByCampName(component, "Name");
							} 
							*/
							if(component.get("v.sortAscCamp")) {
								component.set("v.sortAscCamp", false);
								helper.sortByCampName(component, "Name");
							}else {
								helper.sortByCampName(component, "Name");  
								helper.sortByCampName(component, "Name");     
							}

							helper.renderPage(component, 'v.currentFilteredCampList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');               
							//helper.renderPage(component, 'v.listOfCampaign', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
							//component.set("v.listOfCampaign", result);

							if(result.campaignList.length == 0) {
								var message = 'There is no such record starts with ';

								if(searchingValName != '' && searchingValState == '') {
									message += searchingValName;
								}  
								else if(searchingValState != '' && searchingValName == '') {
									message += searchingValState;
								}

								if(component.get("v.isLightning")) {
									helper.notifyInfo(message, helper);
								} else {
									component.set("v.textMessage", message);
									component.set("v.isToastMessageForVf", true);
									component.set("v.isInfoType", true);
									component.set("v.isErrorType", false);
									component.set("v.isSuccessType", false);
									
									//Calling Auto Close Toast Message method
									helper.autoRemoveToastMessage(component, event, helper);
								}
							}
						}
						else if (state === "ERROR") {
							var errors = response.getError();
							if (errors) {
								if (errors[0] && errors[0].message) {
									if(component.get("v.isLightning")) {
										helper.notifyError(errors[0].message, helper);
									} else {
										component.set("v.textMessage", errors[0].message);
										component.set("v.isToastMessageForVf", true);
										component.set("v.isErrorType", true);
										component.set("v.isInfoType", false);
										component.set("v.isSuccessType", false);
										
										//Calling Auto Close Toast Message method
										helper.autoRemoveToastMessage(component, event, helper);
									}
								}
							} else {
								var message = "Unknown error";
								if(component.get("v.isLightning")) {
									helper.notifyError(message, helper);
								} else {
									component.set("v.textMessage", message);
									component.set("v.isToastMessageForVf", true);
									component.set("v.isErrorType", true);
									component.set("v.isInfoType", false);
									component.set("v.isSuccessType", false);
									
									//Calling Auto Close Toast Message method
									helper.autoRemoveToastMessage(component, event, helper);
								}
							}
						}
						component.set("v.spinner", false);
						window.scrollTo(0,0);
					});
					$A.enqueueAction(action);
					}
				}), 1000
		);

		component.set("v.timeoutReferenceCampaign", delayTimer);
	},

	campaignListHelper : function(component, event, helper) {
		var searchingValName = component.get("v.searchKeyName");
		var searchingValState = component.get("v.searchKeyState");
		//var action = component.get("c.buildCampaignList"); 
		var action = component.get("c.buildCampaignUpdatedList");
        var profileIdToFetchData = component.get("v.isRestoreToDefault") ? null : (component.get("v.childDraftId") ? component.get("v.childDraftId") : component.get("v.rId"));
        action.setParams({
			'searchKeyName'  : searchingValName,
			'searchKeyState' : searchingValState,
			'recordId'       : profileIdToFetchData
		});
		action.setCallback(this, function(response) {
			var state = response.getState();
			if(component.isValid() && state === "SUCCESS") {
				var result = response.getReturnValue();
				console.log('Resulit 3 - @@@@'+result);
				//pagination starts
				component.set("v.listOfCampaign", result.campaignList);
				component.set("v.moreRecordsExistCampaign", result.moreRecordsExist);  
				component.set("v.moreRecordsAfterFilterExistCampaign", result.moreRecordsAfterFilterExist);
				helper.sortInitialCampaignName(component, "Name", true);
				
				//Initialy set filtered list to ALL
				component.set("v.currentFilteredCampList", result.campaignList);
				helper.sortByCampName(component, "Name");
				var tracker = component.get("v.trackSpinnerCounter");
				if(component.get("v.isAddInit")) {
					tracker--;
					component.set("v.trackSpinnerCounter", tracker)
				}					
			}
			else if (state === "ERROR") {
				var errors = response.getError();
				if (errors) {
					if (errors[0] && errors[0].message) {
						if(component.get("v.isLightning")) {
							helper.notifyError(errors[0].message, helper);
						} else {
							component.set("v.textMessage", errors[0].message);
							component.set("v.isToastMessageForVf", true);
							component.set("v.isErrorType", true);
							component.set("v.isInfoType", false);
							component.set("v.isSuccessType", false);
							
							//Calling Auto Close Toast Message method
							helper.autoRemoveToastMessage(component, event, helper);
						}
					}
				} else {
					var message = "Unknown error";
					if(component.get("v.isLightning")) {
						helper.notifyError(message, helper);
					} else {
						component.set("v.textMessage", message);
						component.set("v.isToastMessageForVf", true);
						component.set("v.isErrorType", true);
						component.set("v.isInfoType", false);
						component.set("v.isSuccessType", false);
						
						//Calling Auto Close Toast Message method
						helper.autoRemoveToastMessage(component, event, helper);
					}
				}
			}
			window.scrollTo(0,0);
		});
		$A.enqueueAction(action);
	},    

	leadOwnerList : function(component, event, helper) {
		var delayTimer = component.get("v.timeoutReferenceLead");
		if(delayTimer) {
			window.clearTimeout(delayTimer);
		}

		delayTimer = window.setTimeout(
				$A.getCallback(function() {
				if (component.isValid()) {
					var searchingValName = component.get("v.searchKeyNameLeadOwner");			
					var searchingValState = component.get("v.searchEmailKeyLeadOwner");			
					//var action = component.get("c.buildLeadOwnerList");   
					var action = component.get("c.buildLeadOwnerUpdatedList");
                var profileIdToFetchData = component.get("v.isRestoreToDefault") ? null : (component.get("v.childDraftId") ? component.get("v.childDraftId") : component.get("v.rId"));
                action.setParams({
						'searchKeyName'  : searchingValName,
						'searchKeyState' : searchingValState,
						'recordId'       : profileIdToFetchData
					});
					action.setCallback(this, function(response) {
						var state = response.getState();
						if(component.isValid() && state === "SUCCESS") {
							var result = response.getReturnValue();
							console.log('Resulit 4 - @@@@'+result);
							
							console.log('Resulit 4 - @@@@',result);
							
							console.log('Resulit 4 - @@@@',result.leadOwnerList);
							//component.set("v.listOfLeadOwners", result); 
							component.set("v.listOfLeadOwners", result.leadOwnerList);  
							component.set("v.moreRecordsExistLeadOwner", result.moreRecordsExist);  
							component.set("v.moreRecordsAfterFilterExistLeadOwner", result.moreRecordsAfterFilterExist);
							//For sorting -
							//After filtering the data is being sorted in ascending order
							//1. Check if he sorting item is in ASC then no issue
							//2. If the icon is in DESC then make sure to sort item in descending order and align the items
							if(component.get("v.sortAscLeadOwner")) {  
								helper.sortInitialLeadOwnersName(component, "Name", false);
							}else {
								helper.sortInitialLeadOwnersName(component, "Name", true);  
							}

							//Initialy set filtered list to ALL
							component.set("v.currentFilteredLeadOwnerList", result.leadOwnerList);

							component.set("v.maxPage", Math.floor((result.leadOwnerList.length+9)/10));   
							var maxPage = component.get("v.maxPage");
							component.set("v.pageNumber",1);

							//For sorting -
							//After filtering the data is being sorted in ascending order
							//1. Check if he sorting item is in ASC then no issue
							//2. If the icon is in DESC then make sure to sort item in descending order and align the items
							console.log('Hi sorting --- ' + component.get("v.sortAscLeadOwner"));
							if(component.get("v.sortAscLeadOwner")) {
								component.set("v.sortAscLeadOwner", false);
								helper.sortByLeadOwnersName(component, "Name");
							}else {
								helper.sortByLeadOwnersName(component, "Name");  
								helper.sortByLeadOwnersName(component, "Name");     
							}  

							helper.renderPage(component, 'v.currentFilteredLeadOwnerList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');                
							//helper.renderPage(component, 'v.listOfLeadOwners', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
							//component.set("v.listOfLeadOwners", result);

							if(result.leadOwnerList.length == 0) {
								var message = 'There is no such record starts with ';

								if(searchingValName != '' && searchingValState == '') {
									message += searchingValName;
								}  
								else if(searchingValState != '' && searchingValName == '') {
									message += searchingValState;
								}

								if(component.get("v.isLightning")) {
									helper.notifyInfo(message, helper);
								} else {
									component.set("v.textMessage", message);
									component.set("v.isToastMessageForVf", true);
									component.set("v.isInfoType", true);
									component.set("v.isErrorType", false);
									component.set("v.isSuccessType", false);
									
									//Calling Auto Close Toast Message method
									helper.autoRemoveToastMessage(component, event, helper);
								}
							}
						}
						else if (state === "ERROR") {
							var errors = response.getError();
							if (errors) {
								if (errors[0] && errors[0].message) {
									if(component.get("v.isLightning")) {
										helper.notifyError(errors[0].message, helper);
									} else {
										component.set("v.textMessage", errors[0].message);
										component.set("v.isToastMessageForVf", true);
										component.set("v.isErrorType", true);
										component.set("v.isInfoType", false);
										component.set("v.isSuccessType", false);
										
										//Calling Auto Close Toast Message method
										helper.autoRemoveToastMessage(component, event, helper);
									}
								}
							} else {
								var message = "Unknown error";
								if(component.get("v.isLightning")) {
									helper.notifyError(message, helper);
								} else {
									component.set("v.textMessage", message);
									component.set("v.isToastMessageForVf", true);
									component.set("v.isErrorType", true);
									component.set("v.isInfoType", false);
									component.set("v.isSuccessType", false);
									
									//Calling Auto Close Toast Message method
									helper.autoRemoveToastMessage(component, event, helper);
								}
							}
						}
						component.set("v.spinner", false);
						window.scrollTo(0,0);
					});
					$A.enqueueAction(action);
					}
				}), 1000
		);

		component.set("v.timeoutReferenceLead", delayTimer);
	},
	leadOwnerListHelper : function(component, event, helper) {
		var searchingValName = component.get("v.searchKeyName");
		var searchingValState = component.get("v.searchKeyState");
		//var action = component.get("c.buildLeadOwnerList");
		var action = component.get("c.buildLeadOwnerUpdatedList");
        var profileIdToFetchData = component.get("v.isRestoreToDefault") ? null : (component.get("v.childDraftId") ? component.get("v.childDraftId") : component.get("v.rId"));
        action.setParams({
			'searchKeyName'  : searchingValName,
			'searchKeyState' : searchingValState,
			'recordId'       : profileIdToFetchData
		});
		action.setCallback(this, function(response) {
			var state = response.getState();
			if(component.isValid() && state === "SUCCESS") {
				var result = response.getReturnValue();
				console.log('Resulit 5 - @@@@'+result);
				//pagination starts
				//component.set("v.listOfLeadOwners", result);
				component.set("v.listOfLeadOwners", result.leadOwnerList);  
				component.set("v.moreRecordsExistLeadOwner", result.moreRecordsExist);  
				component.set("v.moreRecordsAfterFilterExistLeadOwner", result.moreRecordsAfterFilterExist);
				
				helper.sortInitialLeadOwnersName(component, "Name", true);  
				console.log('let us see the records Returned --- Lead Owner--- ', result);

				//Initialy set filtered list to ALL
				component.set("v.currentFilteredLeadOwnerList", result.leadOwnerList);
				helper.sortByLeadOwnersName(component, "Name");  
				var tracker = component.get("v.trackSpinnerCounter");
				if(component.get("v.isAddInit")) {
					tracker--;
					component.set("v.trackSpinnerCounter", tracker)
				}
			}
			else if (state === "ERROR") {
				var errors = response.getError();
				if (errors) {
					if (errors[0] && errors[0].message) {
						if(component.get("v.isLightning")) {
							helper.notifyError(errors[0].message, helper);
						} else {
							component.set("v.textMessage", errors[0].message);
							component.set("v.isToastMessageForVf", true);
							component.set("v.isErrorType", true);
							component.set("v.isInfoType", false);
							component.set("v.isSuccessType", false);
							
							//Calling Auto Close Toast Message method
							helper.autoRemoveToastMessage(component, event, helper);
						}
					}
				} else {
					var message = "Unknown error";
					if(component.get("v.isLightning")) {
						helper.notifyError(message, helper);
					} else {
						component.set("v.textMessage", message);
						component.set("v.isToastMessageForVf", true);
						component.set("v.isErrorType", true);
						component.set("v.isInfoType", false);
						component.set("v.isSuccessType", false);
						
						//Calling Auto Close Toast Message method
						helper.autoRemoveToastMessage(component, event, helper);
					}
				}
			}
			window.scrollTo(0,0);
		});
		$A.enqueueAction(action);
	},

	generalSettingList : function(component, event, helper) {
		component.set("v.spinner", true);
		var action = component.get("c.loadGeneralSettings");
        var profileIdToFetchData = component.get("v.isRestoreToDefault") ? null : (component.get("v.childDraftId") ? component.get("v.childDraftId") : component.get("v.rId"));
        action.setParams({
			'recordId' : profileIdToFetchData
		});

		action.setCallback(this, function(response) {
			var state = response.getState();
			if(component.isValid() && state === "SUCCESS") {
				var result = response.getReturnValue();
				console.log('Resulit 6 - @@@@'+result);
				component.set("v.listOfGeneralSettings", result);
				var tracker = component.get("v.trackSpinnerCounter");
				if(component.get("v.isAddInit")) {
					tracker--;
					component.set("v.trackSpinnerCounter", tracker)
				}
			}
			else if (state === "ERROR") {
				var errors = response.getError();
				if (errors) {
					if (errors[0] && errors[0].message) {
						if(component.get("v.isLightning")) {
							helper.notifyError(errors[0].message, helper);
						} else {
							component.set("v.textMessage", errors[0].message);
							component.set("v.isToastMessageForVf", true);
							component.set("v.isErrorType", true);
							component.set("v.isInfoType", false);
							component.set("v.isSuccessType", false);
							
							//Calling Auto Close Toast Message method
							helper.autoRemoveToastMessage(component, event, helper);
						}
					}
				} else {
					var message = "Unknown error";
					if(component.get("v.isLightning")) {
						helper.notifyError(message, helper);
					} else {
						component.set("v.textMessage", message);
						component.set("v.isToastMessageForVf", true);
						component.set("v.isErrorType", true);
						component.set("v.isInfoType", false);
						component.set("v.isSuccessType", false);
						
						//Calling Auto Close Toast Message method
						helper.autoRemoveToastMessage(component, event, helper);
					}
				}
			}
			component.set("v.spinner", false);
			window.scrollTo(0,0);
		});
		$A.enqueueAction(action);
	},

	getAllTabs :  function(component, event, helper) {
		console.log('Inside the GET ALL TABS===========');
		var action = component.get("c.getMapAccordingToSearch");
		action.setParams({
			'searchTabItem' : component.get("v.globalSearchTab")
		});
		action.setCallback(this, function(response) {
			console.log('state - @@@@-----');
            var state = response.getState();
			console.log('state - @@@@'+state);
            
            if(component.isValid() && state === "SUCCESS") {

				var result = response.getReturnValue();
				console.log('Resulit 7 - @@@@'+result);
                console.log(result);
				var tabVal = [];
				for(var key in result){
					tabVal.push({
						value :  result[key], 
						key   :  key
					});
				}
				component.set("v.listOfAllTabs", tabVal);
				if(tabVal[0].key != undefined) {
					console.log('Inside the GET ALL TABS=======$A.getCallback12345====' + tabVal[0].key);
					component.set("v.openSection", '');
					window.setTimeout(
							$A.getCallback(function() {
								if (component.isValid()) {
									console.log('At the end -=======');
									component.set("v.openSection", tabVal[0].key);
									component.set("v.selectedTreeItem", "General Settings General Settings");
								}
							}), 10
					);
					/*setTimeout($A.getCallback(
							() => component.set("v.openSection", tabVal[0].key)							
					));*/
				}
				var tracker = component.get("v.trackSpinnerCounter");
				if(component.get("v.isAddInit")) {
					tracker--;
					component.set("v.trackSpinnerCounter", tracker)
				}
			}
			else if (state === "ERROR") {
				var errors = response.getError();
				if (errors) {
					if (errors[0] && errors[0].message) {
						if(component.get("v.isLightning")) {
							helper.notifyError(errors[0].message, helper);
						} else {
							component.set("v.textMessage", errors[0].message);
							component.set("v.isToastMessageForVf", true);
							component.set("v.isErrorType", true);
							component.set("v.isInfoType", false);
							component.set("v.isSuccessType", false);
							
							//Calling Auto Close Toast Message method
							helper.autoRemoveToastMessage(component, event, helper);
						}
					}
				} else {
					var message = "Unknown error";
					if(component.get("v.isLightning")) {
						helper.notifyError(message, helper);
					} else {
						component.set("v.textMessage", message);
						component.set("v.isToastMessageForVf", true);
						component.set("v.isErrorType", true);
						component.set("v.isInfoType", false);
						component.set("v.isSuccessType", false);
						
						//Calling Auto Close Toast Message method
						helper.autoRemoveToastMessage(component, event, helper);
					}
				}
			}
			component.set("v.spinner", false);
			window.scrollTo(0,0);
		});
		$A.enqueueAction(action);
	},

	renderPage: function(component, allRecordVar, pageNumberVar, recordsPerPageVar, currentListVar, maxPageVar, pageNoListVar) {    
		var records = component.get(allRecordVar),
		pageNumber = component.get(pageNumberVar),
		recordsPerPage = component.get(recordsPerPageVar),
		pageRecords = records.slice((pageNumber-1)*recordsPerPage, pageNumber*recordsPerPage);
		component.set(currentListVar, pageRecords);
		component.set(maxPageVar, Math.floor((records.length+parseInt(recordsPerPage)-1)/parseInt(recordsPerPage)));
		//component.set("v.pageNumber", component.get("v.pageNumber"));  
		console.log('Floor value max page333111---- ', Math.floor((records.length+parseInt(recordsPerPage)-1)/parseInt(recordsPerPage)));    
		var maxPage = component.get(maxPageVar);
		var pageNoList = [];
		for(var i = 1; i<= maxPage ; i++){
			pageNoList.push(i);
		}
		component.set(pageNoListVar,pageNoList);
	},
	renderPageOnRecordsPerPageChange : function(component){
		var tabSel = component.get("v.isSelectedTab");
		if(tabSel != undefined) {
			var records;
			if(tabSel == 'Accounts'){
				//records = component.get("v.listOfAccount");  
				records = component.get("v.currentFilteredList");
			}else if(tabSel == 'Campaigns'){
				//records = component.get("v.listOfCampaign");
				records = component.get("v.currentFilteredCampList");
			}else if(tabSel == 'Lead Owners'){
				//records = component.get("v.listOfLeadOwners");
				records = component.get("v.currentFilteredLeadOwnerList");
			}
			var recordsPerPage = component.get("v.recordsPerPage"),
			pageRecords = records.slice(0,recordsPerPage);

			component.set("v.pageNumber", 1);
			component.set("v.currentList", pageRecords);
			component.set("v.maxPage", Math.floor((records.length+parseInt(recordsPerPage)-1)/parseInt(recordsPerPage)));
			var maxPage = component.get("v.maxPage");
			var pageNoList = [];
			for(var i = 1; i<= maxPage ; i++){
				pageNoList.push(i);
			}
			component.set("v.pageNoList",pageNoList);
		}
	},
	queryJobStatus : function(component, event, helper, jobId) {
		var action2 = component.get("c.checkJobStatus");
		action2.setParams({
			"apexJobId" : jobId
		});
		action2.setCallback(this, function(response) {
			var state = response.getState();
			if(component.isValid() && state === "SUCCESS") {
				var statusOfJob = response.getReturnValue();
				if(statusOfJob == 'completed') {
					alert('Account refresh completed.');
					helper.accountList(component, event);
				} 
				if(statusOfJob == 'Failed') {
					alert('Account refresh failed.');
				} 
				if(statusOfJob == 'Aborted') {
					alert('Account refresh was aborted.');
				} else {
					window.setTimeout(
							$A.getCallback(function() {
								if (component.isValid()) {
									helper.queryJobStatus(component, event, helper, jobId);
								}
							}), 5000
					);
				} 
			}
			else if (state === "ERROR") {
				var errors = response.getError();
				if (errors) {
					if (errors[0] && errors[0].message) {
						if(component.get("v.isLightning")) {
							helper.notifyError(errors[0].message, helper);
						} else {
							component.set("v.textMessage", errors[0].message);
							component.set("v.isToastMessageForVf", true);
							component.set("v.isErrorType", true);
							component.set("v.isInfoType", false);
							component.set("v.isSuccessType", false);
							
							//Calling Auto Close Toast Message method
							helper.autoRemoveToastMessage(component, event, helper);
						}
					}
				} else {
					var message = "Unknown error";
					if(component.get("v.isLightning")) {
						helper.notifyError(message, helper);
					} else {
						component.set("v.textMessage", message);
						component.set("v.isToastMessageForVf", true);
						component.set("v.isErrorType", true);
						component.set("v.isInfoType", false);
						component.set("v.isSuccessType", false);
						
						//Calling Auto Close Toast Message method
						helper.autoRemoveToastMessage(component, event, helper);
					}
				}
			}
			window.scrollTo(0, 0);
		});
		$A.enqueueAction(action2);    
	},

	refreshAccounts : function(component, event, helper) {
		var  message = 'Account refresh has been initiated. This process can take several seconds to several minutes depending on the number of Accounts in your organization as well as available server resources. You do not need to stay on this page for the job to complete. If you close this page, you can check the status of the job in Setup->Monitoring->Apex Jobs';        
		//helper.notifySuccess(message, helper);
		event.getSource().disabled = true;
		var action = component.get("c.refreshAccounts");

		action.setParams({
			'generalSettingJSON' : JSON.stringify(component.get("v.listOfGeneralSettings"))
		});
		action.setCallback(this, function(response) {
			var state = response.getState();
			if(component.isValid() && state === "SUCCESS") {
				var jobId = response.getReturnValue();

				if(component.get("v.isLightning")) {
					helper.notifySuccess(message, helper);
				} else {
					component.set("v.textMessage", message);
					component.set("v.isToastMessageForVf", true);
					component.set("v.isSuccessType", true);
					component.set("v.isInfoType", false);
					component.set("v.isErrorType", false);
					
					//Calling Auto Close Toast Message method
					helper.autoRemoveToastMessage(component, event, helper);
				}

				this.queryJobStatus(component, event, this, jobId);

			}
			else if (state === "ERROR") {
				var errors = response.getError();
				if (errors) {
					if (errors[0] && errors[0].message) {
						if(component.get("v.isLightning")) {
							helper.notifyError(errors[0].message, helper);
						} else {
							component.set("v.textMessage", errors[0].message);
							component.set("v.isToastMessageForVf", true);
							component.set("v.isErrorType", true);
							component.set("v.isInfoType", false);
							component.set("v.isSuccessType", false);
							
							//Calling Auto Close Toast Message method
							helper.autoRemoveToastMessage(component, event, helper);
						}
					}
				} else {
					var message = "Unknown error";
					if(component.get("v.isLightning")) {
						helper.notifyError(message, helper);
					} else {
						component.set("v.textMessage", message);
						component.set("v.isToastMessageForVf", true);
						component.set("v.isErrorType", true);
						component.set("v.isInfoType", false);
						component.set("v.isSuccessType", false);
						
						//Calling Auto Close Toast Message method
						helper.autoRemoveToastMessage(component, event, helper);
					}
				}
			}
			component.set("v.spinner", false);
			window.scrollTo(0,0);
		});
		$A.enqueueAction(action);
	},
	processSaveSuccessCallback: function(component, event, helper, result) {
		console.log('processSaveSuccessCallback===1');
		component.set("v.isEditCompOpen", false);
		console.log('processSaveSuccessCallback===2', component.get("v.isEditCompOpen"));
		//Until Iframe do not  load show the spinner
		component.set("v.iframeLoadingSpinner", true);
		
		if(component.get("v.isLightning")) {
			var successMessageToShow = result.message;
			console.log('processSaveSuccessCallback===3 -- save as draft val', !component.get("v.isSaveAsDraft"), ' --child val-- ', component.get("v.childDraftId"), ' --prof name--', component.get("v.profileName").toLowerCase());
			if(!component.get("v.isSaveAsDraft") && component.get("v.childDraftId") && component.get("v.profileName").toLowerCase() === 'Default'.toLowerCase() ) {
				//helper.notifySuccess('For Default profile to publish from draft version, we need to load the record types again. Please do not close the tab until process completes.', helper);
				successMessageToShow+='. For Default profile to publish from draft version, we need to load the record types again. ' +
									  'Please do not close the tab until process completes.';
				helper.notifySuccess(successMessageToShow, helper);
				helper.fireAutoLoadRecordTypeEvent(component, event, helper, component.get("v.isSaveAsDraft"), component.get("v.childDraftId"), component.get("v.profileName"));
			}else {
				/*
				successMessageToShow = ;
				helper.notifySuccess(result.message, helper);
				 */	
				helper.notifySuccess(successMessageToShow, helper);
			}
			
		}else {
			var successMessageToShow = result.message;
			if(!component.get("v.isSaveAsDraft") && component.get("v.childDraftId") && component.get("v.profileName").toLowerCase() === 'Default'.toLowerCase() ) {
				/*
				successMessageToShow+='\n' + 'For Default profile to publish from draft version, we need to load the record types again.' + '\n' +
									  'Please do not close the tab until process completes.';
				*/
				successMessageToShow+='. For Default profile to publish from draft version, we need to load the record types again. ' +
									  'Please do not close the tab until process completes.';
				component.set("v.textMessage", successMessageToShow);
				component.set("v.isToastMessageForVf", true);
				component.set("v.isSuccessType", true);
				component.set("v.isInfoType", false);
				component.set("v.isErrorType", false);
				
				//Calling Auto Close Toast Message method
				helper.autoRemoveToastMessage(component, event, helper);
				
				helper.fireAutoLoadRecordTypeEvent(component, event, helper, component.get("v.isSaveAsDraft"), component.get("v.childDraftId"), component.get("v.profileName"));
			}else {
				component.set("v.textMessage", successMessageToShow);
				component.set("v.isToastMessageForVf", true);
				component.set("v.isSuccessType", true);
				component.set("v.isInfoType", false);
				component.set("v.isErrorType", false);
				
				//Calling Auto Close Toast Message method
				helper.autoRemoveToastMessage(component, event, helper);
			}
		}
		window.scrollTo(0, 0);
		
		//console.log('state is ' + state);
		component.set("v.spinner", false);
			
		
		
	},
	saveChildProfileAsPublished: function(component, event, helper) {
		var actionVar = component.get("c.saveChildProfileAsPublished");
		actionVar.setParams({
			"recordId" : component.get("v.rId"),
			"childDraftId" : component.get("v.childDraftId")
		});
		actionVar.setCallback(this, function(response) {
			var state = response.getState();
			if(component.isValid() && state === "SUCCESS") {
				var result = response.getReturnValue();
					//helper.notifySuccess(result.message, helper);
				if(result.isSuccess == true) { 
					console.log('Hi SAVE AS DRAFT -----> Publish SUCCESS:::::');
					helper.processSaveSuccessCallback(component, event, helper, result);
				}else {
					console.log('Save as draft----> publish ERROR:::::');
					//handle Error here
					if(component.get("v.isLightning")) {
						helper.notifyError(result.message, helper);
					} else {
						component.set("v.textMessage", result.message);
						component.set("v.isToastMessageForVf", true);
						component.set("v.isErrorType", true);
						component.set("v.isInfoType", false);
						component.set("v.isSuccessType", false);
						
						//Calling Auto Close Toast Message method
						helper.autoRemoveToastMessage(component, event, helper);
					}
					window.scrollTo(0, 0);
					console.log('state is In Save as draft-----> Publish' + state);
					component.set("v.spinner", false);
				}
			}else if (state === "ERROR") {
				console.log('Next transaction ERROR======');
				var errors = response.getError();
				var issueMessage = "Unknown error";
				if (errors) {
					if (errors[0] && errors[0].message) {
						issueMessage = errors[0].message;
					}
				}
				if(component.get("v.isLightning")) {
					helper.notifyError(issueMessage, helper);
				} else {
					component.set("v.textMessage", issueMessage);
					component.set("v.isToastMessageForVf", true);
					component.set("v.isErrorType", true);
					component.set("v.isInfoType", false);
					component.set("v.isSuccessType", false);
					
					//Calling Auto Close Toast Message method
					helper.autoRemoveToastMessage(component, event, helper);
				}
				window.scrollTo(0, 0);
				console.log('state is ' + state);
				component.set("v.spinner", false);
			}
		});
		$A.enqueueAction(actionVar);		
	},
	publishData: function(component, event, helper) {
		//console.log('');

		if(!component.find("profileNameId").get("v.value") || !(component.find("profileNameId").get("v.value").trim())) {
			component.set("v.isRequiredProfileName", true);

			if(component.get("v.isLightning")) {
				helper.notifyError('Profile Name is required', helper);
			} else {
				component.set("v.textMessage", 'Profile Name is required');
				component.set("v.isToastMessageForVf", true);
				component.set("v.isErrorType", true);
				component.set("v.isInfoType", false);
				component.set("v.isSuccessType", false);
				
				//Calling Auto Close Toast Message method
				helper.autoRemoveToastMessage(component, event, helper);
			}
			component.set("v.spinner", false);
			window.scrollTo(0, 0);
			return;
		}
		
		if(!component.get("v.rId") && component.get("v.profileName") == 'Default') {
			component.set("v.isRequiredProfileName", true);
			if(component.get("v.isLightning")) {
				helper.notifyError('Default cannot be specified as new profile name.', helper);
			} else {
				component.set("v.textMessage", 'Default cannot be specified as new profile name.');
				component.set("v.isToastMessageForVf", true);
				component.set("v.isErrorType", true);
				component.set("v.isInfoType", false);
				component.set("v.isSuccessType", false);
				
				//Calling Auto Close Toast Message method
				helper.autoRemoveToastMessage(component, event, helper);
			}
			component.set("v.spinner", false);
			window.scrollTo(0, 0);
			return;
    	}

		var action = component.get("c.saveDataBase");

		var allFieldsWrapper = [];
		if(component.get("v.isPersonAccountAllowed")) {
			allFieldsWrapper = allFieldsWrapper.concat(component.get("v.personAccountStandardFieldWrapper"), component.get("v.personAccountCustomFieldWrapper"));
		}else {
			allFieldsWrapper = allFieldsWrapper.concat(component.get("v.accountStandardFieldWrapper"), component.get("v.accountCustomFieldWrapper"));
		}

		//component.get("v.accountStandardFieldWrapper"), component.get("v.accountCustomFieldWrapper"),
		allFieldsWrapper = allFieldsWrapper.concat(component.get("v.contactStandardFieldWrapper"), component.get("v.contactCustomFieldWrapper"),
													component.get("v.leadStandardFieldWrapper"), component.get("v.leadCustomFieldWrapper"));
		
		var allSettingWrapper = [];
		allSettingWrapper = allSettingWrapper.concat(component.get("v.accountSettingWrapper"), component.get("v.contactSettingWrapper"),
				component.get("v.leadSettingWrapper"));


		var allRecordTypeWrapper = [];
		console.log('Hi recordtype account---', component.get("v.accountRecordTypeWrapper"));
		console.log('Hi recordtype account---', component.get("v.contactRecordTypeWrapper"));
		console.log('Hi recordtype account---', component.get("v.leadRecordTypeWrapper"));
		
		if(component.get("v.isPersonAccountAllowed")) {
			allRecordTypeWrapper = allRecordTypeWrapper.concat(component.get("v.personAccountRecordTypeWrapper"));
		}else {
			allRecordTypeWrapper = allRecordTypeWrapper.concat(component.get("v.accountRecordTypeWrapper"));
		}
      
		console.log('Person Account Wrapper issue===== ', component.get("v.personAccountRecordTypeWrapper"));
		allFieldsWrapper.concat(component.get("v.accountRecordTypeWrapper"));
		allRecordTypeWrapper = allRecordTypeWrapper.concat(component.get("v.contactRecordTypeWrapper"),
				component.get("v.leadRecordTypeWrapper"));    

		var dArray = [];
		var filteredLeadOwnerObject = [];
		if(component.get("v.listOfLeadOwners")) {
			for(var index=0; index < component.get("v.listOfLeadOwners").length; index++) {         
				var eachElement = component.get("v.listOfLeadOwners")[index];
				delete eachElement["Owner"];
				console.log(eachElement);
				filteredLeadOwnerObject.push(eachElement);
			}
		}
		//For reflecting checkbox value from Default Value
		for(var i=0; i < allFieldsWrapper.length; i++) {
			if(allFieldsWrapper[i].sCF.devastegic1__FieldType__c == "checkbox") {
				allFieldsWrapper[i].sCF.devastegic1__Default_Value__c = allFieldsWrapper[i].isCheckedDefault ? '1' : '0';
			}

			if(! allFieldsWrapper[i].sCF.devastegic1__IsProtected__c) {
				//allFieldsWrapper[i].sCF.Default_Value__c allFieldsWrapper[i].sCF.Include__c && allFieldsWrapper[i].sCF.Set_from_Scan__c == '--None--'  && !allFieldsWrapper[i].sCF.Prompt_for_Value__c
				var checkDefaultValueEmptyNew = allFieldsWrapper[i].sCF.devastegic1__FieldType__c == 'checkbox' ? (typeof allFieldsWrapper[i].sCF.devastegic1__Default_Value__c == 'boolean' ? !allFieldsWrapper[i].sCF.devastegic1__Default_Value__c : allFieldsWrapper[i].sCF.devastegic1__Default_Value__c == 'false') : 
					((allFieldsWrapper[i].sCF.devastegic1__FieldType__c == 'picklist' || allFieldsWrapper[i].sCF.devastegic1__FieldType__c == 'multipicklist') ? 
							(allFieldsWrapper[i].sCF.devastegic1__Default_Value__c == '--None--') : (allFieldsWrapper[i].sCF.devastegic1__Default_Value__c ? false : true) );

				var conditionToRemoveMapping = !allFieldsWrapper[i].sCF.devastegic1__Include__c && (checkDefaultValueEmptyNew && !allFieldsWrapper[i].sCF.devastegic1__Prompt_for_Value__c);

				if(allFieldsWrapper[i].sCF.devastegic1__Label__c == 'Email Opt Out') {
					//console.log('--- FieldType__c---', allFieldsWrapper[i].sCF.FieldType__c, '---Default_Value__c--', allFieldsWrapper[i].sCF.Default_Value__c, '--Name--', allFieldsWrapper[i].sCF.Label__c);
					//console.log(typeof allFieldsWrapper[i].sCF.Default_Value__c);
					//console.log('---'+ allFieldsWrapper[i].sCF.Default_Value__c.trim() +'---' +allFieldsWrapper[i].sCF.Default_Value__c+'---');
					console.log('---checkDefaultValueEmptyNew---', checkDefaultValueEmptyNew);
					console.log(typeof allFieldsWrapper[i].sCF.devastegic1__Default_Value__c == 'boolean' ); //? allFieldsWrapper[i].sCF.Default_Value__c : allFieldsWrapper[i].sCF.Default_Value__c == 'false'
				}
				if(conditionToRemoveMapping) {
					allFieldsWrapper[i].sCF.devastegic1__Set_from_Scan__c = '--None--';
				} 

			}
		}

		dArray.push({"oDW" : allFieldsWrapper, "sW"  : allSettingWrapper, "rTW" : allRecordTypeWrapper,
			"sA" : component.get("v.listOfAccount"), "sC" : component.get("v.listOfCampaign"),
			"sLO" : filteredLeadOwnerObject, "gSW" : component.get("v.listOfGeneralSettings")});  
		console.log(dArray); 
		console.log('Save Data Base Action Test');
		console.log(action);
		action.setParams({
			'jsonData' : JSON.stringify(dArray),
			'actionType' : component.get("v.isSelectedTab"),
			'recordId' : component.get("v.rId"),
			'isSaveAsDraft' : component.get("v.isSaveAsDraft"),
			'isPublishedOnce' : component.get("v.isPublishedOnceId"),
			"profileName" : component.get("v.profileName"), 
			"childDraftId" : component.get("v.childDraftId")
		});
		action.setCallback(this, function(response) {
			var state = response.getState();
			if(component.isValid() && state === "SUCCESS") {
				var result = response.getReturnValue();
				//helper.notifySuccess(result.message, helper);
				if(result.isSuccess == true) {  
					//check if this is [Save as Draft -------> Publish]
					var isPublishedFromDraftMode = component.get("v.isPublishedOnceId") && component.get("v.childDraftId") && !component.get("v.isSaveAsDraft");
					console.log('--component.get("v.isPublishedOnceId")--', component.get("v.isPublishedOnceId"), '--component.get("v.childDraftId")--', component.get("v.childDraftId"), '--!component.get("v.isSaveAsDraft")--', !component.get("v.isSaveAsDraft"));  
					console.log('-------isPublishedFromDraftMode--------', isPublishedFromDraftMode);
					if(isPublishedFromDraftMode) {
						//In next transaction - do needful to make child/draft profile as parent/published profile
						//And if that is successful do what is implemented for other successful save operation
						console.log('This is Save as draft-----> publish');
						helper.saveChildProfileAsPublished(component, event, helper);
					}else { 
						helper.processSaveSuccessCallback(component, event, helper, result);
						/*
						//go with current save implementation
						component.set("v.isEditCompOpen", false);
						//Until Iframe do not  load show the spinner
						component.set("v.iframeLoadingSpinner", true);
						if(component.get("v.isLightning")) {
							helper.notifySuccess(result.message, helper);
							if(!component.get("v.isSaveAsDraft") && component.get("v.childDraftId") && component.get("v.profileName").toLowerCase() === 'Default'.toLowerCase() ) {
								helper.notifySuccess('For Default profile to publish from draft version, we need to load the record types again. Please do not close the tab until process completes.', helper);
								helper.fireAutoLoadRecordTypeEvent(component, event, helper, component.get("v.isSaveAsDraft"), component.get("v.childDraftId"), component.get("v.profileName"));
							}
						}else {
							component.set("v.textMessage", result.message);
							component.set("v.isToastMessageForVf", true);
							component.set("v.isSuccessType", true);
							component.set("v.isInfoType", false);
							component.set("v.isErrorType", false);
						}	
						window.scrollTo(0, 0);
						console.log('state is ' + state);
						component.set("v.spinner", false);		
						*/			
					} 				
				}else {
					if(component.get("v.isLightning")) {
						helper.notifyError(result.message, helper);
					} else {
						component.set("v.textMessage", result.message);
						component.set("v.isToastMessageForVf", true);
						component.set("v.isErrorType", true);
						component.set("v.isInfoType", false);
						component.set("v.isSuccessType", false);
						
						//Calling Auto Close Toast Message method
						helper.autoRemoveToastMessage(component, event, helper);
					}
					window.scrollTo(0, 0);
					console.log('state is ' + state);
					component.set("v.spinner", false);
				}
			}else if (state === "ERROR") {
				var errors = response.getError();
				var finalMessageToShow = "Unknown error";
				if (errors) {
					if (errors[0] && errors[0].message) {
						finalMessageToShow = errors[0].message;
					}
				} else {
					//finalMessageToShow = "Unknown error";
				}
				
				if(component.get("v.isLightning")) {
					helper.notifyError(finalMessageToShow, helper);
				} else {
					component.set("v.textMessage", finalMessageToShow);
					component.set("v.isToastMessageForVf", true);
					component.set("v.isErrorType", true);
					component.set("v.isInfoType", false);
					component.set("v.isSuccessType", false);
					
					//Calling Auto Close Toast Message method
					helper.autoRemoveToastMessage(component, event, helper);
				}
				window.scrollTo(0, 0);
				console.log('state is ' + state);
				component.set("v.spinner", false);
			}
			/*
			window.scrollTo(0, 0);
			console.log('state is ' + state);
			component.set("v.spinner", false); */
		});
		$A.enqueueAction(action);

	},
	filteredCampaign : function(component, event, helper) {
		var camp = component.get("v.listOfCampaign");
		
		var defaultArrConditionally = [];
		for(var i=0; i<camp.length; i++) {
			if(!component.get("v.selCampaignFilterDefault") || component.get("v.selCampaignFilterDefault") == 'All') {  
				if(camp[i]) {
					defaultArrConditionally.push(camp[i]);   
				}
			}
			else if(component.get("v.selCampaignFilterDefault") == 'Selected') {
				/* Mapping was changed as correct values were not reflecting in JSON
				if(camp[i].Enabled__c) {
					defaultArrConditionally.push(camp[i]);
				} 
				 */
				if(camp[i].devastegic1__Auto_set__c) {
					defaultArrConditionally.push(camp[i]);
				}
			} 
			else if(component.get("v.selCampaignFilterDefault") == 'Unselected') {
				if(!camp[i].devastegic1__Auto_set__c) {
					defaultArrConditionally.push(camp[i]);
				} 
			}
		}
		console.log('Default filtered campaigns------  ', defaultArrConditionally);

		var visibleArrConditionally = [];
		for(var i=0; i<camp.length; i++) {
			if(!component.get("v.selCampaignFilterVisible") || component.get("v.selCampaignFilterVisible") == 'All') {
				if(camp[i]) {
					visibleArrConditionally.push(camp[i]);   
				}
			}
			else if(component.get("v.selCampaignFilterVisible") == 'Selected') {
				if(camp[i].devastegic1__Enabled__c) {
					visibleArrConditionally.push(camp[i]);
				} 
			} 
			else if(component.get("v.selCampaignFilterVisible") == 'Unselected') {
				if(!camp[i].devastegic1__Enabled__c) {
					visibleArrConditionally.push(camp[i]);
				} 
			}
		}
		console.log('Visible on mobile filtered campaigns------  ', visibleArrConditionally);

		var filteredCampArr = [];
		for(var i=0; i<defaultArrConditionally.length; i++) {
			for(var j=0; j<visibleArrConditionally.length; j++) {
				console.log('--- ID test --- ', defaultArrConditionally[i].Id, ' ---- Id test--- ', defaultArrConditionally[i].Id );
				/*
           if(defaultArrConditionally[i].Id == visibleArrConditionally[j].Id) {
                filteredCampArr.push(defaultArrConditionally[i]);
           }
				 */


				if(defaultArrConditionally[i].Id && visibleArrConditionally[j].Id) {
					// If Ids are present we can compare uniqueness using them
					if(defaultArrConditionally[i].Id == visibleArrConditionally[j].Id) {
						filteredCampArr.push(defaultArrConditionally[i]);
					}
				}else {
					console.log('----Control is in Empty values of Id ---- Cmapigns---- ');
					//If Ids are not present - parent Campaign is the source of creation so compare it with parent Id
					var defaultArrKey = defaultArrConditionally[i].devastegic1__ParentCampaign__c ;	//+ '' + typeArrConditionally[i].OwnerType__c;
					var visibleArrKey = visibleArrConditionally[j].devastegic1__ParentCampaign__c;	// + '' + visibleLeadArrConditionally[j].OwnerType__c;
					if(defaultArrKey == visibleArrKey) {
						filteredCampArr.push(defaultArrConditionally[i]);
					}
				}
			}
		}

		component.set("v.maxPage", Math.floor((filteredCampArr.length + 9)/10));
		var maxPage = component.get("v.maxPage");
		component.set("v.pageNumber",1);
		component.set("v.currentFilteredCampList",filteredCampArr);

		//For sorting -
		//After filtering the data is being sorted in ascending order
		//1. Check if sorting item is in ASC then no issue
		//2. If the icon is in DESC then make sure to sort item in descending order and align the items
		
		//if(! component.get("v.sortAscCamp")) {
		component.get("v.sortAscCamp", false);
		helper.sortByCampName(component, "Name");
		helper.sortByCampName(component, "Name");
		//}
		

		helper.renderPage(component, 'v.currentFilteredCampList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList'); 
	},
	filteredLeadOwner : function(component, event, helper) {
		var leadOwner = component.get("v.listOfLeadOwners");
		console.log('---- leadOwner--- Filter ---- ', leadOwner, ' ==== component.get("v.selLeadOwnerFilterType")==== ', component.get("v.selLeadOwnerFilterType"));   
		var typeArrConditionally = [];
		for(var i=0; i<leadOwner.length; i++) {
			if(!component.get("v.selLeadOwnerFilterType") || component.get("v.selLeadOwnerFilterType") == 'All') {
				if(leadOwner[i]) {
					typeArrConditionally.push(leadOwner[i]);   
				}
			}else if(component.get("v.selLeadOwnerFilterType") == 'User') {

				if(leadOwner[i].devastegic1__OwnerType__c == 'user') {
					typeArrConditionally.push(leadOwner[i]);
				} 
			}else if(component.get("v.selLeadOwnerFilterType") == 'Queue') {
				if(leadOwner[i].devastegic1__OwnerType__c == 'queue') {
					typeArrConditionally.push(leadOwner[i]);
				} 
			}
		}

		var visibleLeadArrConditionally = [];
		for(var i=0; i<leadOwner.length; i++) {
			if(!component.get("v.selLeadOwnerFilterVisible") || component.get("v.selLeadOwnerFilterVisible") == 'All') {
				if(leadOwner[i]) {
					visibleLeadArrConditionally.push(leadOwner[i]);   
				}
			} else if(component.get("v.selLeadOwnerFilterVisible") == 'Selected') {
				if(leadOwner[i].devastegic1__Enabled__c) {
					visibleLeadArrConditionally.push(leadOwner[i]);
				} 
			} else if(component.get("v.selLeadOwnerFilterVisible") == 'Unselected') {
				if(!leadOwner[i].devastegic1__Enabled__c) {
					visibleLeadArrConditionally.push(leadOwner[i]);
				}   
			}
		}

		var filteredLeadOwnerArr = [];
		for(var i=0; i<typeArrConditionally.length; i++) {
			for(var j=0; j<visibleLeadArrConditionally.length; j++) {
				if(typeArrConditionally[i].Id && visibleLeadArrConditionally[j].Id) {
					// If Ids are present we can compare uniqueness using them
					if(typeArrConditionally[i].Id == visibleLeadArrConditionally[j].Id) {
						filteredLeadOwnerArr.push(typeArrConditionally[i]);
					}
				}else {
					//If Ids are not present - email and  Name+Type - can be considered unique
					var typeArrKey = typeArrConditionally[i].Name+ '' + typeArrConditionally[i].devastegic1__OwnerType__c;
					var visibleArrKey = visibleLeadArrConditionally[j].Name + '' + visibleLeadArrConditionally[j].devastegic1__OwnerType__c;
					if(typeArrKey == visibleArrKey) {
						filteredLeadOwnerArr.push(typeArrConditionally[i]);
					}
				}
			}
		}

		component.set("v.maxPage", Math.floor((filteredLeadOwnerArr.length + 9)/10));
		var maxPage = component.get("v.maxPage");
		component.set("v.pageNumber",1);
		component.set("v.currentFilteredLeadOwnerList",filteredLeadOwnerArr);

		//For sorting -
		//After filtering the data is being sorted in ascending order
		//1. Check if he sorting item is in ASC then no issue
		//2. If the icon is in DESC then make sure to sort item in descending order and align the items
		component.set("v.sortAscLeadOwner", false);
		if(! component.get("v.sortAscLeadOwner")) {
			helper.sortByLeadOwnersName(component, "Name");
		}    

		helper.renderPage(component, 'v.currentFilteredLeadOwnerList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList'); 
	},
	notifySuccess : function(message, helper){
		helper.showEventToast(message, 'success', 'dismissible'); //'dismissible'
	},
	notifyError : function(message, helper){
		helper.showEventToast(message, 'error', 'dismissible');
	},
	notifyInfo : function(message, helper) {
		helper.showEventToast(message, 'info', 'dismissible');
	},
	showEventToast : function(message, type, mode) {
		var toastEvent = $A.get("e.force:showToast");
		toastEvent.setParams({
			mode: mode != '' ? mode : 'sticky',
					message: message,
					type: type != '' ? type : 'success'
		});
		toastEvent.fire();
	}, 
	updateFieldRowsForValidation : function(component, event, helper, attributeToCheck) {
		var allFieldsWrapper = component.get(attributeToCheck);	
		var tabNameToValidations = component.get("v.tabValidationHighlight");	
		//console.log('---updateFieldRowsForValidation1 ', tabNameToValidations);

		//var tabParentObjectName;
		var tabFieldType;
		var isAllGood = true;
		for(var i=0; i < allFieldsWrapper.length; i++) {
			//New Condition
			if(! allFieldsWrapper[i].sCF.devastegic1__IsProtected__c) {
				var isIncluded = allFieldsWrapper[i].sCF.devastegic1__Include__c && allFieldsWrapper[i].sCF.devastegic1__Set_from_Scan__c == '--None--'  && !allFieldsWrapper[i].sCF.devastegic1__Prompt_for_Value__c;
				var checkDefaultValueEmpty = allFieldsWrapper[i].sCF.devastegic1__FieldType__c == 'checkbox' ? (allFieldsWrapper[i].sCF.devastegic1__Default_Value__c == 'false') : 
					((allFieldsWrapper[i].sCF.devastegic1__FieldType__c == 'picklist' || allFieldsWrapper[i].sCF.devastegic1__FieldType__c == 'multipicklist') ? 
							(allFieldsWrapper[i].sCF.devastegic1__Default_Value__c == '--None--') : (allFieldsWrapper[i].sCF.devastegic1__Default_Value__c ? false : true) );
				//($A.util.isUndefinedOrNull(allFieldsWrapper[i].sCF.Default_Value__c) ? true : false);
				//console.log('Now the correct value---- ', allFieldsWrapper[i].sCF.Name, '  -- ', checkDefaultValueEmpty , '----default value---', allFieldsWrapper[i].sCF.Default_Value__c);
				if(isIncluded && checkDefaultValueEmpty) {
					allFieldsWrapper[i].isRequiredIncluded = true;
					console.log('tabNameToValidations---', tabNameToValidations, ' tabFieldType ', tabFieldType);
					isAllGood = false;
				}else {
					allFieldsWrapper[i].isRequiredIncluded = false;

				}
				var fieldTypeVar = allFieldsWrapper[i].sCF.devastegic1__IsCustom__c ? 'Custom' : 'Standard';  
				tabFieldType = allFieldsWrapper[i].sCF.devastegic1__SObjectType__c == 'PersonAccount' ? ('Account' + fieldTypeVar + 'Fields') : (allFieldsWrapper[i].sCF.devastegic1__SObjectType__c + fieldTypeVar + 'Fields');  
			}
		}

		if(isAllGood) {
			console.log('All good----', tabFieldType)
			tabNameToValidations[tabFieldType] = false;
		}else {
			tabNameToValidations[tabFieldType] = true;
		}
		component.set("v.tabValidationHighlight", tabNameToValidations); 
		component.set(attributeToCheck, allFieldsWrapper);
	},
    scrollingOnDomRenderHelper: function(component, event, helper){
    		console.log('On select----- scrollingOnDomRenderHelper  %%%%%%%%===');
	      	if(document.getElementById("stdOrCustomBlockId") != null) {
	            document.getElementById("stdOrCustomBlockId").scrollTop = 0;
	            
	        } else if(document.getElementById("objSettingBlockId") != null) {
	            document.getElementById("objSettingBlockId").scrollTop = 0;
	            
	        }else if(document.getElementById("objRecordTypeBlockId") != null) {
	            document.getElementById("objRecordTypeBlockId").scrollTop = 0;
	            
	        }else if(document.getElementById("accountBlockId") != null) {
	            document.getElementById("accountBlockId").scrollTop = 0;
	            
	        }else if(document.getElementById("campaignBlockId") != null) {
	            document.getElementById("campaignBlockId").scrollTop = 0;
	            
	        }else if(document.getElementById("leadOwnerBlockId") != null) {
	            document.getElementById("leadOwnerBlockId").scrollTop = 0;
	            
	        }else if(document.getElementById("genSettingBlockId") != null) {
	            document.getElementById("genSettingBlockId").scrollTop = 0; 
	        }
	        
	        component.set("v.spinner", false);   
    },	
    
    
    fireAutoLoadRecordTypeEvent : function(component, event, helper, isDraftCase, childProfileId, profileName) {
    	var loadRecordTypeEvent = $A.get("e.c:LoadRecordTypeAppEvent");
    	if(!isDraftCase && childProfileId && profileName.toLowerCase() === 'Default'.toLowerCase() ) {
    		loadRecordTypeEvent.fire();
    	}
    },
    
    fetchAccountRecordTypesForDropDown : function(component, event, helper) {
    
    	console.log('New Helper Method');
    	var actionVar = component.get("c.fetchSObjectsRecordType");
		actionVar.setParams({
			"sObjectType" : 'Account'
		});
		actionVar.setCallback(this, function(response) {
		
			var state = response.getState();
			
			if(component.isValid() && state === "SUCCESS") {
			
				var result = response.getReturnValue();												
				var listAccountRecordTypes = [];
							    			    	
		    	for(var res in result) {
					
					console.log(res);
					console.log(result[res]);
					listAccountRecordTypes.push({"label": result[res].Name, "value": result[res].Id});
				}
		    	
		    	listAccountRecordTypes.push({"label": 'All', "value": 'All'});
		    	
		    	if(listAccountRecordTypes != null && listAccountRecordTypes.length > 0)
		    		component.set("v.optionsRecordType", listAccountRecordTypes);					
				
			}else if (state === "ERROR") {
				console.log('Next transaction ERROR======');
				var errors = response.getError();
				var issueMessage = "Unknown error";
				if (errors) {
					if (errors[0] && errors[0].message) {
						issueMessage = errors[0].message;
					}
				}
				if(component.get("v.isLightning")) {
					helper.notifyError(issueMessage, helper);
				} else {
					component.set("v.textMessage", issueMessage);
					component.set("v.isToastMessageForVf", true);
					component.set("v.isErrorType", true);
					component.set("v.isInfoType", false);
					component.set("v.isSuccessType", false);
					
					//Calling Auto Close Toast Message method
					helper.autoRemoveToastMessage(component, event, helper);
				}
				window.scrollTo(0, 0);
				console.log('state is ' + state);
				component.set("v.spinner", false);
			}
		});
		
		$A.enqueueAction(actionVar);
    },
    
    //Method created to Auto Close Toast Message in Classic Mode
    autoRemoveToastMessage : function(component, event, helper) {
    
    	setTimeout(function() {
			
			var closeIconElem = document.getElementById("close-custom-toastMsg");
			
			if(closeIconElem != undefined && closeIconElem != null)
				closeIconElem.click();
			
		}, 6000);
    }
})