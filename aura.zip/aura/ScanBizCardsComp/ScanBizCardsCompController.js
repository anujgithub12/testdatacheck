({
    doInit: function(component, event, helper) {
    	component.set("v.openPopUp", false); 
    	if(! component.get("v.rId")) {
    		component.set("v.isAddInit", true);
    	}
    	var tabNameToValidations = {'AccountStandardFields' : false, 'Account' : false, 'AccountCustomFields': false, 
					'ContactStandardFields' : false, 'Contact' : false, 'ContactCustomFields': false,
					'LeadStandardFields' : false, 'Lead' : false, 'LeadCustomFields': false
					};
    	component.set("v.tabValidationHighlight", tabNameToValidations);	
        helper.restoreToDefault(component, event, helper);
    }, 
    restoreToDefault : function(component, event, helper) {
    	component.set("v.isAddInit", false);
        component.set("v.isRestoreToDefault", true);
        
         component.set("v.listOfAllTabs", []);
        
		 helper.restoreToDefault(component, event, helper);
    },
    sortByAccName: function(component, event, helper) {
      helper.sortByAccName(component, "Name");
    },
    sortByCampName: function(component, event, helper) {
        helper.sortByCampName(component, "Name");
    },
    sortByLeadOwnersName: function(component, event, helper) {
        helper.sortByLeadOwnersName(component, "Name");
    },
    sortByRecTypeName: function(component, event, helper) {
        helper.sortByRecTypeName(component, "recordTypeName");
    },
    selectedItem : function(component, event, helper) {
	    component.set("v.spinner", true);
	    console.log('---Tab Selected---- ', event.getParam('name'));
	    window.setTimeout( $A.getCallback(function() {
	        if (component.isValid()) {
	        console.log('Hi 1 onBeforceSelect Event:');
	        var sItem = event.getParam('name');
	        component.set("v.selectedTreeItem", event.getParam('name'));
	       
	        if(sItem.includes('Account') && !sItem.includes('Accounts')) {
	        	component.set("v.isObjType", "Account");
	        }
	        if(sItem.includes('Contact'))
	            component.set("v.isObjType", "Contact");
	        if(sItem.includes('Lead') && !sItem.includes('Owners')){
	            component.set("v.isObjType", "Lead"); 
	        }
	        if(sItem.includes('Accounts')){
	            component.set("v.isObjType", "Accounts");
	        }
	        if(sItem.includes('Campaigns')){
	            component.set("v.isObjType", "Campaigns");
	        }
	        if(sItem.includes('Owners')){
	            component.set("v.isObjType", "Lead Owners");
	        }
	        if(sItem.includes('General')) {
	            component.set("v.isObjType", "General");
	        }
	        if(sItem == "Account Account Settings" || sItem == "Contact Contact Settings" || sItem == "Lead Lead Settings") {
	        	component.set("v.isSelectedTab", sItem.split(' ')[1] + ' '+sItem.split(' ')[2]);
	        }  else if(sItem == "Org Data Assignment Accounts" || sItem == "Org Data Assignment Campaigns") {
	        	component.set("v.isSelectedTab", sItem.split(' ')[3]);
	        }  else if(sItem == "Org Data Assignment Lead Owners") {
	        	component.set("v.isSelectedTab", sItem.split(' ')[3] +' '+sItem.split(' ')[4]);
	        }  else if(sItem == "General Settings General Settings") {
	        	component.set("v.isSelectedTab", sItem.split(' ')[2] +' '+sItem.split(' ')[3]);
	        } else {
	            component.set("v.isSelectedTab", sItem);
	        } 
	        	
	        if(sItem.includes('Standard') || sItem.includes('Custom')) {
	            window.scrollTo(0,0);
	            component.set("v.isStandardOrCustom", true);
	            component.set("v.isSetting", false);
	            component.set("v.isRecordType", false);
	            
	        	if(sItem.includes('Standard') && sItem.includes('Account')) {
	        		var personAccountAllowed = component.get("v.accountSettingWrapper").length == 4 && component.get("v.accountSettingWrapper")[2]["isValue"];
	        		console.log(component.get("v.accountSettingWrapper")[3]);
	        		if(personAccountAllowed) {
	        			//set person account data
	        			component.set("v.objDataWrapper", component.get("v.personAccountStandardFieldWrapper"));
	        			console.log(component.get("v.personAccountStandardFieldWrapper"));
	        		}else {
	        			//account data
	        			component.set("v.objDataWrapper", component.get("v.accountStandardFieldWrapper"));
	        		}
	            }else if(sItem.includes('Custom') && sItem.includes('Account')) {
	            	var personAccountAllowed = component.get("v.accountSettingWrapper").length == 4 && component.get("v.accountSettingWrapper")[2]["isValue"];
	        		if(personAccountAllowed) {
	        			//set person account data
	        			component.set("v.objDataWrapper", component.get("v.personAccountCustomFieldWrapper"));
	        			console.log(component.get("v.personAccountCustomFieldWrapper"));
	        		}else {
	        			//account data
	        			component.set("v.objDataWrapper", component.get("v.accountCustomFieldWrapper"));
	        		}
	            }else if(sItem.includes('Standard') && sItem.includes('Contact')) {
	        		component.set("v.objDataWrapper", component.get("v.contactStandardFieldWrapper"));
	            }else if(sItem.includes('Custom') && sItem.includes('Contact')) {
	        		component.set("v.objDataWrapper", component.get("v.contactCustomFieldWrapper"));
	            }else if(sItem.includes('Standard') && sItem.includes('Lead')) {
	        		component.set("v.objDataWrapper", component.get("v.leadStandardFieldWrapper"));
	            }else if(sItem.includes('Custom') && sItem.includes('Lead')) {
	        		component.set("v.objDataWrapper", component.get("v.leadCustomFieldWrapper"));
	            }      
	        	//console.log(component.get("v.objDataWrapper")); 
	        }
	        
	        if(sItem.includes('Settings') && !sItem.includes('General')) {
	            window.scrollTo(0,0);
	            component.set("v.isStandardOrCustom", false);
	            component.set("v.isSetting", true);
	            component.set("v.isRecordType", false);
	            
	            if(sItem.includes('Account')) {
	                component.set("v.settingWrapper", component.get("v.accountSettingWrapper"));
	            }else if(sItem.includes('Contact')) {
	                component.set("v.settingWrapper", component.get("v.contactSettingWrapper"));
	            }else if(sItem.includes('Lead')) {
	                component.set("v.settingWrapper", component.get("v.leadSettingWrapper"));
	            }
	        }
	        
	        if(sItem.includes('Record Type')) {
	            window.scrollTo(0,0);
	            component.set("v.isStandardOrCustom", false);
	            component.set("v.isSetting", false);
	            component.set("v.isRecordType", true);
	            
	        	if(sItem.includes('Account')) {
	        		//personAccountRecordTypeWrapper
	        		if(component.get("v.isPersonAccountAllowed")) {
	        			component.set("v.rTypeWrapper", component.get("v.personAccountRecordTypeWrapper"));
	        		}else {
	        			component.set("v.rTypeWrapper", component.get("v.accountRecordTypeWrapper"));
	        		}  
	            }else if(sItem.includes('Contact')) {
	            	component.set("v.rTypeWrapper", component.get("v.contactRecordTypeWrapper"));
	            }else if(sItem.includes('Lead')) {
	            	component.set("v.rTypeWrapper", component.get("v.leadRecordTypeWrapper"));
	            }            
	            //helper.retrieveRecordTypes(component, event, helper);
	        }
	           
	        if(sItem == 'Org Data Assignment Accounts') {
	            window.scrollTo(0,0);
	            component.set("v.isStandardOrCustom", false);
	            component.set("v.isSetting", false);
	            component.set("v.isRecordType", false);
	               
	            //helper.accountList(component, event, helper);
	            
	            //For pagination
	            var noOfAccounts = 0;
	            if(component.get("v.currentFilteredList").length) {
	            	noOfAccounts = component.get("v.currentFilteredList").length;
	            }
	            
	            component.set("v.maxPage", Math.floor((noOfAccounts + 9)/10));
	            var maxPage = component.get("v.maxPage");
	            component.set("v.pageNumber",1);
	            
	            helper.renderPage(component, 'v.currentFilteredList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');            
	        }
	       
	       if(sItem == 'Org Data Assignment Campaigns') {
	            window.scrollTo(0,0);
	            component.set("v.isStandardOrCustom", false);
	            component.set("v.isSetting", false);
	            component.set("v.isRecordType", false);
	            
	            // helper.campaignList(component, event, helper);
	            //For pagination
	            var noOfCampaigns = 0;
	            if(component.get("v.currentFilteredCampList").length) {
	            	noOfCampaigns = component.get("v.currentFilteredCampList").length;
	            }
	            
	            component.set("v.maxPage", Math.floor((noOfCampaigns + 9)/10));
	            var maxPage = component.get("v.maxPage");
	            component.set("v.pageNumber", 1);
	            
	            helper.renderPage(component, 'v.currentFilteredCampList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');             
	        }
	       
	       if(sItem == 'Org Data Assignment Lead Owners') {
	            window.scrollTo(0,0);
	            component.set("v.isStandardOrCustom", false);
	            component.set("v.isSetting", false);
	            component.set("v.isRecordType", false);
	            
	            //helper.leadOwnerList(component, event, helper);
	            //For pagination
	            var noOfLeadOwners = 0;
	            if(component.get("v.currentFilteredLeadOwnerList").length) {   
	            	noOfLeadOwners = component.get("v.currentFilteredLeadOwnerList").length;
	            }
	            component.set("v.maxPage", Math.floor((noOfLeadOwners + 9)/10));
	            var maxPage = component.get("v.maxPage");
	            component.set("v.pageNumber", 1);
	            
	            //helper.renderPage(component, 'v.listOfLeadOwners', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
	            helper.renderPage(component, 'v.currentFilteredLeadOwnerList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
	        }
	        
	        if(sItem.includes('General') && sItem.includes('Settings')) {
	            window.scrollTo(0,0);
	            component.set("v.isStandardOrCustom", false);
	            component.set("v.isSetting", false);
	            component.set("v.isRecordType", false);
	        }	    
	    }
	    }), 500);
	    
	    /* On tab select - Show spinner */
	    console.log('Find and remove slds-hide---- ');
	    /*
	    var tabSelectSpinnerVar = component.find('tabChangeSpinnerId');
	    $A.util.removeClass(tabSelectSpinnerVar, 'slds-hide');
	    */
        //$A.util.addClass(tabSelectSpinnerVar, 'changeMe');
        
        //document.getElementById("htmlSpinnerId")
        //document.getElementById("htmlSpinnerId").style.display = "";
        //window.setTimeout( $A.getCallback(function() {document.getElementById("htmlSpinnerId").style.display = ""; }), 0);
	    

       
    },
    autoSearchData : function(component, event, helper) {
        var selectedTab = component.get("v.isSelectedTab");
        component.set("v.spinner", true);
        console.log('----------'+selectedTab);
        if(selectedTab == 'Accounts') {
        	helper.accountList(component, event, helper);
        }else if(selectedTab == 'Campaigns') {
        	helper.campaignList(component, event, helper);
        }else if(selectedTab == 'Lead Owners') {
        	helper.leadOwnerList(component, event, helper);
        }
    },
    autoSearchForTabs : function(component, event, helper) {
         helper.getAllTabs(component, event, helper);
    },
    refreshAccounts : function(component, event, helper) {
		 helper.refreshAccounts(component, event, helper);
    },
    renderPage: function(component, event, helper) {
       var tabselected = component.get("v.isSelectedTab");
        
        if(tabselected == 'Accounts') {
        	//helper.renderPage(component, 'v.listOfAccount', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
        	helper.renderPage(component, 'v.currentFilteredList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
 		}else if(tabselected == 'Campaigns') {
        	//helper.renderPage(component, 'v.listOfCampaign', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
        	helper.renderPage(component, 'v.currentFilteredCampList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
        	//component.set("v.currentFilteredCampList", result);
 		}else if(tabselected == 'Lead Owners') {
        	//helper.renderPage(component, 'v.listOfLeadOwners', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
        	helper.renderPage(component, 'v.currentFilteredLeadOwnerList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
 		}
    },
    renderPageOnRecordsPerPageChange: function(component, event, helper){
        helper.renderPageOnRecordsPerPageChange(component);
    },
    openModal: function(component, event, helper) {
        document.getElementsByTagName("BODY")[0].style.overflow = "hidden";
        component.set("v.isOpen", true);
    },
    closeModel: function(component, event, helper) {
        document.getElementsByTagName("BODY")[0].style.overflow = "visible";
        component.set("v.isOpen", false);
    },
    backToDefault: function(component, event, helper) {
    //Need to write some logic here
    	/*component.set("v.isOpen", false);
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef : "c:ScanBizCardsHomeScreenComp"
           
        });
        evt.fire();*/
       
        component.set("v.isEditCompOpen", false);
        document.getElementsByTagName("BODY")[0].style.overflow = "visible";
        //Until Iframe do not  load show the spinner
        //component.set("v.iframeLoadingSpinner", true);    
     },
    publishData: function(component, event, helper) {
    	//component.set("v.isSaveAsDraft", false);
    	//helper.publishData(component, event, helper);
    	component.set("v.spinner", true);
        component.set("v.isRestoreToDefault", false);
        
    	//First check validation for all of them - Set a attribute which paas the test for validations
    	//At the end if all the validation are passed(decide by the attribute declared) go ahead with Publish function 
    	//helper.updateFieldRowsForValidation(component, event, helper, "v.objDataWrapper");
    	console.log('Hi 1');
    	if(component.get("v.isPersonAccountAllowed")) {
    		helper.updateFieldRowsForValidation(component, event, helper, "v.personAccountStandardFieldWrapper");
    		helper.updateFieldRowsForValidation(component, event, helper, "v.personAccountCustomFieldWrapper");  
    	}else {
    		helper.updateFieldRowsForValidation(component, event, helper, "v.accountStandardFieldWrapper");
    		helper.updateFieldRowsForValidation(component, event, helper, "v.accountCustomFieldWrapper");
    	}
    	helper.updateFieldRowsForValidation(component, event, helper, "v.contactStandardFieldWrapper");
    	helper.updateFieldRowsForValidation(component, event, helper, "v.contactCustomFieldWrapper");
    	helper.updateFieldRowsForValidation(component, event, helper, "v.leadStandardFieldWrapper");
    	helper.updateFieldRowsForValidation(component, event, helper, "v.leadCustomFieldWrapper");
    	console.log('Tab selected --- ',  component.get("v.isSelectedTab"));
    	  
    	var selectedTabScreen =  component.get("v.isSelectedTab");
    	var tabNameToVarMap = {'Lead Standard Fields': 'v.leadStandardFieldWrapper', 'Lead Custom Fields' : 'v.leadCustomFieldWrapper',
							   'Account Standard Fields': 'v.accountStandardFieldWrapper', 'Account Custom Fields': 'v.accountCustomFieldWrapper',
							   'Contact Standard Fields': 'v.contactStandardFieldWrapper', 'Contact Custom Fields': 'v.contactCustomFieldWrapper'};
		if(tabNameToVarMap[selectedTabScreen]) {
			component.set("v.objDataWrapper", []);
			 if(component.get("v.isPersonAccountAllowed")) {
				 if(tabNameToVarMap[selectedTabScreen] == 'v.accountStandardFieldWrapper') {
					 component.set("v.objDataWrapper", component.get("v.personAccountStandardFieldWrapper"));
				 }else if(tabNameToVarMap[selectedTabScreen] == 'v.accountCustomFieldWrapper') {
					 component.set("v.objDataWrapper", component.get("v.personAccountCustomFieldWrapper"));
				 }else {
					 component.set("v.objDataWrapper", component.get(tabNameToVarMap[selectedTabScreen]));
				 }
			 }else {
				 component.set("v.objDataWrapper", component.get(tabNameToVarMap[selectedTabScreen]));
			 }
		}
		
		var highlightTabsMap = component.get("v.tabValidationHighlight");
		//console.log(highlightTabsMap);
		if(highlightTabsMap['AccountStandardFields'] || highlightTabsMap['AccountCustomFields']) {
			highlightTabsMap['Account'] = true;
		}else {
			highlightTabsMap['Account'] = false;
		}
		
		if(highlightTabsMap['ContactStandardFields'] || highlightTabsMap['ContactCustomFields']) {
			//console.log('This must be printed 12345678');
			highlightTabsMap['Contact'] = true;
		}else {
			highlightTabsMap['Contact'] = false;
		}
		
		if(highlightTabsMap['LeadStandardFields'] || highlightTabsMap['LeadCustomFields']) {
			highlightTabsMap['Lead'] = true;
		}else {
			highlightTabsMap['Lead'] = false;
		}
		component.set("v.tabValidationHighlight", highlightTabsMap);   
		
		console.log('---highlightTabsMap Account---', highlightTabsMap['Account'], ' -- standsrd field ', highlightTabsMap['AccountStandardFields'], ' custom ', highlightTabsMap['AccountCustomFields'] );
		var allSections = component.find("highlightTabAccordingId");
        
		for(var indexElement=0; indexElement < allSections.length; indexElement++) {
			//console.log('See element html ', allSections[indexElement].get("v.class")); 
			var cmpTarget = allSections[indexElement];
			var classListOnParentSection = cmpTarget.get("v.class").split(' '); //classList"
			console.log('===',  cmpTarget.get("v.class"));
			//console.log(' classListOnParentSection -- ', classListOnParentSection);
			
			var classToSearch;
			if(classListOnParentSection.indexOf('Contact') != -1) { 
				classToSearch = 'Contact'; 
			}else if(classListOnParentSection.indexOf('Account') != -1) {
				classToSearch = 'Account';
			}else if(classListOnParentSection.indexOf('Lead') != -1) {
				classToSearch = 'Lead';
			}else {
				classToSearch = 'Invalid Class';
			}
			
			console.log('---highlightTabsMap[classToSearch]---', highlightTabsMap[classToSearch]);
			if(highlightTabsMap[classToSearch]) {
				$A.util.addClass(cmpTarget, 'parentSectionValidationErrorClass');
			}else {
				$A.util.removeClass(cmpTarget, 'parentSectionValidationErrorClass');
			}
		}
		
		var allSubSections = component.find("highlightTabSubItemId");
		for(var indexElement=0; indexElement < allSubSections.length; indexElement++) {
			var cmpTarget = allSubSections[indexElement];
			var classListOnParentSection = cmpTarget.get("v.class").split(' ');
			console.log('===',  cmpTarget.get("v.class"));
			
			var classToSearch;
			if(classListOnParentSection.indexOf('ContactStandardFields') != -1) { 
				classToSearch = 'ContactStandardFields'; 
			}else if(classListOnParentSection.indexOf('AccountStandardFields') != -1) {
				classToSearch = 'AccountStandardFields';
			}else if(classListOnParentSection.indexOf('LeadStandardFields') != -1) {
				classToSearch = 'LeadStandardFields';
			}else if(classListOnParentSection.indexOf('ContactCustomFields') != -1) {
				classToSearch = 'ContactCustomFields';
			}else if(classListOnParentSection.indexOf('AccountCustomFields') != -1) {
				classToSearch = 'AccountCustomFields';
			}else if(classListOnParentSection.indexOf('LeadCustomFields') != -1) {
				classToSearch = 'LeadCustomFields';
			}else {
				classToSearch = 'Invalid Class';
			}
			
			console.log('---highlightTabsMap[classToSearch]---', highlightTabsMap[classToSearch]);
			if(highlightTabsMap[classToSearch]) {
				$A.util.addClass(cmpTarget, 'subItemValidationErrorClass');
			}else {
				$A.util.removeClass(cmpTarget, 'subItemValidationErrorClass');
			}
		}		
		
		
    	var checkIfAllValidationPassed = true;
    	for(var tabNameValidateKey in highlightTabsMap) {
    		if(highlightTabsMap[tabNameValidateKey]) {
    			checkIfAllValidationPassed = false;
    		}
    	}
    	
    	if(checkIfAllValidationPassed) {
	    	var generalSettingInfoList = component.get("v.listOfGeneralSettings");
	    	//Check for General Setting Wrapper - Duplicate Criteria
	    	for(var indexOfGeneralSetting=0; indexOfGeneralSetting < generalSettingInfoList.length; indexOfGeneralSetting++) {
	    		//console.log('optionName----- ', generalSettingInfoList[indexOfGeneralSetting]);
	    		
	    		if(generalSettingInfoList[indexOfGeneralSetting].optionName == 'Duplicate Criteria') {
	    			console.log('--- selectedPicklistValue--- ', generalSettingInfoList[indexOfGeneralSetting].selectedPicklistValue);
	    			if(generalSettingInfoList[indexOfGeneralSetting].selectedPicklistValue) {
	    				var updateDuplicateCondition = generalSettingInfoList[indexOfGeneralSetting].selectedPicklistValue.includes('--None--') &&
	    												!(generalSettingInfoList[indexOfGeneralSetting].selectedPicklistValue == '--None--' && !generalSettingInfoList[7].isValue);
	    				console.log('-----None-- test new cond====', updateDuplicateCondition);     
	    				if(updateDuplicateCondition) { //generalSettingInfoList[indexOfGeneralSetting].selectedPicklistValue.includes('--None--')
	    					console.log('Check value---- ' , generalSettingInfoList[indexOfGeneralSetting].selectedPicklistValue);
	    					//Still show error and highlight error
							for(var indexElement=0; indexElement < allSections.length; indexElement++) {
								var cmpTarget = allSections[indexElement];
								var classListOnParentSection = cmpTarget.get("v.class").split(' '); 
								console.log('===',  cmpTarget.get("v.class"));
								
								if(classListOnParentSection.indexOf('GeneralSettings') != -1) { 
									//Here we identified the General setting Tab
									$A.util.addClass(cmpTarget, 'required-text');
								}
								
							}
	    					component.set("v.validateGeneralSetting", true);
	    					component.set("v.spinner", false);
                            if(component.get("v.isLightning")) {
                                helper.notifyError('Required fields in red need your attention.', helper); 
                            } else {
                                component.set("v.textMessage", 'Required fields in red need your attention.');
                                component.set("v.isToastMessageForVf", true);
                                component.set("v.isErrorType", true);
                                component.set("v.isInfoType", false);
                                component.set("v.isSuccessType", false);
                            }
	    					window.scrollTo(0, 0);  
	    					return;
	    				}else {
	    					//Remove error and let the code go forward
	    					for(var indexElement=0; indexElement < allSections.length; indexElement++) {
								var cmpTarget = allSections[indexElement];
								var classListOnParentSection = cmpTarget.get("v.class").split(' '); 
								console.log('===',  cmpTarget.get("v.class"));
								
								if(classListOnParentSection.indexOf('GeneralSettings') != -1) { 
									//Here we identified the General setting Tab
									$A.util.removeClass(cmpTarget, 'required-text');
								}
							}
							component.set("v.validateGeneralSetting", false);
	    				}
	    			}else {
    					//Still show error and highlight error
						for(var indexElement=0; indexElement < allSections.length; indexElement++) {
							var cmpTarget = allSections[indexElement];
							var classListOnParentSection = cmpTarget.get("v.class").split(' '); 
							console.log('===',  cmpTarget.get("v.class"));
							
							if(classListOnParentSection.indexOf('GeneralSettings') != -1) { 
								//Here we identified the General setting Tab
								$A.util.addClass(cmpTarget, 'required-text');
							}
							
						}
						// Show error
						component.set("v.validateGeneralSetting", true);
						component.set("v.spinner", false);
                        if(component.get("v.isLightning")) {
                            helper.notifyError('Required fields in red need your attention.', helper); 
                        } else {
                            component.set("v.textMessage", 'Required fields in red need your attention.');
                            component.set("v.isToastMessageForVf", true);
                            component.set("v.isErrorType", true);
                            component.set("v.isInfoType", false);
                            component.set("v.isSuccessType", false);
                        }  
						window.scrollTo(0, 0);  				
    					return;
	    			}
	    		}
	    	}   
	    	  	
    		component.set("v.isSaveAsDraft", false);
    		helper.publishData(component, event, helper);
    	}else {
    		//showToast toast and hide spinner
    		component.set("v.spinner", false);
            
            if(component.get("v.isLightning")) {
                helper.showEventToast('Required fields in red need your attention.', 'error', 'dismissible'); 
            } else {
                component.set("v.textMessage", 'Required fields in red need your attention.');
                component.set("v.isToastMessageForVf", true);
                component.set("v.isErrorType", true);
                component.set("v.isInfoType", false);
                component.set("v.isSuccessType", false);
            }
            window.scrollTo(0, 0);
    	}
    },
    saveAsDraft: function(component, event, helper) {
    	component.set("v.spinner", true);
    	component.set("v.isSaveAsDraft",  true);
        component.set("v.isRestoreToDefault", false);
    	helper.publishData(component, event, helper);
    },    
     changeAccountFilter : function(component, event, helper) { 
    	component.set("v.selectedAccountFilter", event.getParam("value"));
         
        var listOfAccounts = [];
        var acc = component.get("v.listOfAccount");
       
        for(var i=0; i<acc.length; i++) {
            
            console.log('******************************************************'+component.get("v.selectedAccountFilter"))
            console.log('******************************************************'+acc[i].devastegic1__Enabled__c);
            if(component.get("v.selectedAccountFilter") == 'All') {
                if(acc[i]) {
                    listOfAccounts.push(acc[i]);   
                }
                
            }else if(component.get("v.selectedAccountFilter") == 'Selected') {
                if(acc[i].devastegic1__Enabled__c) {
                    listOfAccounts.push(acc[i]);
                } 
            } 
                else if(component.get("v.selectedAccountFilter") == 'Unselected') {
                    if(!acc[i].devastegic1__Enabled__c) {
                        listOfAccounts.push(acc[i]);
                    } 
                }
        } 
        component.set("v.maxPage", Math.floor((listOfAccounts.length + 9)/10));
        var maxPage = component.get("v.maxPage");
        component.set("v.pageNumber",1);
        component.set("v.currentFilteredList",listOfAccounts);
	    
	    //For sorting -
	    //After filtering the data is being sorted in ascending order
	    //1. Check if he sorting item is in ASC then no issue
	    //2. If the icon is in DESC then make sure to sort item in descending order and align the items
	    component.set("v.sortAscAcc", false);
	    if(! component.get("v.sortAscAcc")) {
	    	helper.sortByAccName(component, "Name");
	    	//helper.sortByAccName(component, "Name");
	    }   
	         
        helper.renderPage(component, 'v.currentFilteredList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList'); 
        
    },
    changeCampaignFilterDefault : function(component, event, helper) { 
    	component.set("v.selCampaignFilterDefault", event.getParam("value"));
        helper.filteredCampaign(component, event, helper);
    },
    changeCampaignFilterVisible : function(component, event, helper) { 
    	component.set("v.selCampaignFilterVisible", event.getParam("value"));
        helper.filteredCampaign(component, event, helper);
    },
    changeLeadOwnerFilterType : function(component, event, helper) { 
        console.log('----------'+event.getParam("value")+'--*****');
    	component.set("v.selLeadOwnerFilterType", event.getParam("value"));
        helper.filteredLeadOwner(component, event, helper);
    },
    changeLeadOwnerFilterVisible : function(component, event, helper) { 
    	component.set("v.selLeadOwnerFilterVisible", event.getParam("value"));
        helper.filteredLeadOwner(component, event, helper);
    },
    onRadioChange : function(component, event, helper) { 
        var selTab = component.get("v.isSelectedTab");
        
        var splitRtype = event.getSource().get("v.text").split('#');
        var rTypeName = splitRtype[0];
        var rTypeId = splitRtype[1];
        
        if(selTab == "Lead Record Types") {
           
            var leadWrapper = component.get("v.leadRecordTypeWrapper");
            console.log('leadWrapper value---',  leadWrapper);
            for(var i=0; i<leadWrapper.length; i++) {
                if(leadWrapper[i].recordTypeName != rTypeName &&  leadWrapper[i].rType.Id != rTypeId) {
					leadWrapper[i].isDefault = false;
                }
            }
            component.set("v.leadRecordTypeWrapper", leadWrapper);
          	component.set("v.rTypeWrapper", leadWrapper);
        } 
        else if(selTab == "Contact Record Types") {
            
            var contactWrapper = component.get("v.contactRecordTypeWrapper");
            for(var i=0; i<contactWrapper.length; i++) {
                if(contactWrapper[i].recordTypeName != rTypeName &&  contactWrapper[i].rType.Id != rTypeId) {
                    contactWrapper[i].isDefault = false;
                }
            }
            component.set("v.contactRecordTypeWrapper", contactWrapper);
            component.set("v.rTypeWrapper", contactWrapper);
        } 
        else if(selTab == "Account Record Types") {
            if(component.get("v.isPersonAccountAllowed")) {
            	var personAccountWrapper = component.get("v.personAccountRecordTypeWrapper");
	            for(var i=0; i<personAccountWrapper.length; i++) {
	                if(personAccountWrapper[i].recordTypeName != rTypeName &&  personAccountWrapper[i].rType.Id != rTypeId) {
	                    personAccountWrapper[i].isDefault = false;
	                }
	            }
	            component.set("v.personAccountRecordTypeWrapper", personAccountWrapper);
	            component.set("v.rTypeWrapper", personAccountWrapper);
            }else {
            	var accountWrapper = component.get("v.accountRecordTypeWrapper");
	            for(var i=0; i<accountWrapper.length; i++) {
	                if(accountWrapper[i].recordTypeName != rTypeName &&  accountWrapper[i].rType.Id != rTypeId) {
	                    accountWrapper[i].isDefault = false;
	                }
	            } 
	            component.set("v.accountRecordTypeWrapper", accountWrapper);
	            component.set("v.rTypeWrapper", accountWrapper);
            }
            
        }
    },
    /*tooltip : function(component, event, helper) {
       var element = $( event.target ),
            posTop = element.offset().top  - 50, 
            posLeft = element.offset().left, 
            toolTipWidth = element.outerWidth() > 90 ? element.outerWidth() : 250, 
            titleText = element.attr('data-title'); 
            if(titleText && titleText != ''){ 
            $('<div />', {class: 'autoSugest', text : titleText, css : {left: posLeft, top: posTop, maxWidth: toolTipWidth}}).appendTo('body').fadeIn(); 
            }else{ 
            return false; 
            } 
        	$(element).on('mouseout', function(){ 
                $('.autoSugest').fadeOut(function(){ 
                	$(this).remove(); 
            	});
            });
    }*/
    showAddProfile : function(component, event, helper) { 
    	var currentValue = event.getParam("value");
    	if(currentValue == 0) {
    		component.set("v.openPopUp", true);
    	}
    },
    closeAddPopup : function(component, event, helper) { 
    	component.set("v.openPopUp", false);
    },
    changeDefaultFieldValue : function(component, event, helper) {
        
        var recordTypesWrapper = component.get("v.rTypeWrapper");
        var checkboxValue = event.getSource().get("v.value");
        if(!checkboxValue) {
            recordTypesWrapper.forEach(function(item) {
                if(!item.isAVailable) {
                    item.isDefault = false;  
                }
            }); 
            component.set("v.rTypeWrapper", recordTypesWrapper);
        }
    },
    onselectAfterDOMRender : function(component, event, helper) {
    	console.log('On select----- tab===');
        if(component.get("v.isSelectedTab").includes('Standard Fields') || component.get("v.isSelectedTab").includes('Custom Fields')) {
        	//component.set("v.spinner", false);
            //window.setTimeout( $A.getCallback(function() {component.set("v.spinner", false); }), 3000); 
            /*      
            window.setTimeout( $A.getCallback(function() {
            	var tabSelectSpinnerVar = component.find('tabChangeSpinnerId');
            	$A.util.addClass(tabSelectSpinnerVar, 'slds-hide'); }
        	), 3000);
             */
            window.setTimeout( $A.getCallback(function() {
            	if (component.isValid()) {
            		helper.scrollingOnDomRenderHelper(component, event, helper);
            	}
            }), 2000); 
        } else {
            //component.set("v.spinner", false);
            /*
            var tabSelectSpinnerVar = component.find('tabChangeSpinnerId');
        	$A.util.addClass(tabSelectSpinnerVar, 'slds-hide');
             */
            window.setTimeout( $A.getCallback(function() {
            	if (component.isValid()) {
            		helper.scrollingOnDomRenderHelper(component, event, helper);
            	}
            }), 1000); 
            //helper.scrollingOnDomRenderHelper(component, event, helper);    
        }
   },
    checkKeyEvent : function(component, event, helper) { 
	    var x =  event.which || event.keyCode;
	    if(x != 8) {
	    	console.log(event);
	    	event.preventDefault(); 
	    }
	    
    /*
    	var x = event.getParams().which || event.getParams().keyCode; //event.keyCode;	//event.which || event.keyCode; //8
    	
    	//Backspace must be allowed - keypress do not fire this - So all others must be blocked
    	if(x != 8) {
    		console.log(event,  ' --- ', x);
    		//event.stopPropagation();
    		event.preventDefault(); 
    	}
*/
    },
    hideAccountBulkInfo: function(component, event, helper) { 
    	component.set("v.moreRecordsExistAccount", false);
    	component.set("v.moreRecordsAfterFilterExistAccount", false);
    	//document.getElementById("accountBulkDataInfoSectionId").classList.add("slds-hide");
    },
    hideCampaignBulkInfo: function(component, event, helper) { 
    	component.set("v.moreRecordsExistCampaign", false);
    	component.set("v.moreRecordsAfterFilterExistCampaign", false);
    	//document.getElementById("campaignBulkDataInfoSectionId").classList.add("slds-hide");
    },
    hideLeadOwnerBulkInfo: function(component, event, helper) { 
    	component.set("v.moreRecordsExistLeadOwner", false);
    	component.set("v.moreRecordsAfterFilterExistLeadOwner", false);
    	//document.getElementById("leadOwnerBulkDataInfoSectionId").classList.add("slds-hide");
    },
    checkPersonAccount : function(component, event, helper) {
        console.log(event.getSource().get("v.class"));
        if(event.getSource().get("v.class").includes('personAccountAllowedClass') && component.get("v.accountSettingWrapper").length == 4) {
            component.set("v.isPersonAccountAllowed", component.get("v.accountSettingWrapper")[2]["isValue"]);  
            
            var className = event.getSource().get("v.class");
            if(className.includes("allowPersonAccount_cell")) {
                
                var valForAllowPersonAcc = event.getSource().get("v.value");
                console.log("cb val--", valForAllowPersonAcc);
                if(valForAllowPersonAcc) {
                    if(document.getElementsByClassName("personAccountOnly_Row")[0]) {
                        document.getElementsByClassName("personAccountOnly_Row")[0].classList.remove('slds-hide');
                    }
                    
                } else {
                    if(document.getElementsByClassName("personAccountOnly_Row")[0])
                        document.getElementsByClassName("personAccountOnly_Row")[0].classList.add('slds-hide');
                }
            }
        }
    },
    fireAutoLoadRecordTypeEvent : function(component, event, helper) {
    	helper.fireAutoLoadRecordTypeEvent(component, event, helper);
    },
    
    //Code added by Chetan (May 22, 2019)
    //Method created to select all account records
    selectAllAccounts : function(component, event, helper) {
    	
    	var checkboxVal = document.getElementById("check-selectAllAccounts");
    	
    	var listAllCurrentRecords = component.get("v.currentList");
    	var listAllRecords = component.get("v.currentFilteredList");
    	var listUpdatedAllRecords = [];
    	var listUpdatedCurrentListRecords = [];
    	
    	if(checkboxVal != null && checkboxVal != undefined && checkboxVal.checked) {
    		
    		//Loop over list to modify checkbox value in all records list
	    	for(var i = 0; i < listAllRecords.length; i++) {
	    		console.log(listAllRecords[i]);
	    		listAllRecords[i].devastegic1__Enabled__c = true;
	    		listUpdatedAllRecords.push(listAllRecords[i]);
	    	}
	    	
	    	//Loop over list to modify checkbox value in current records list
	    	for(var i = 0; i < listAllCurrentRecords.length; i++) {
	    		console.log(listAllCurrentRecords[i]);
	    		listAllCurrentRecords[i].devastegic1__Enabled__c = true;
	    		listUpdatedCurrentListRecords.push(listAllCurrentRecords[i]);
	    	}	    	
	    	
	    } else if(checkboxVal != null && checkboxVal != undefined && !checkboxVal.checked) {
    	
    		//Loop over list to modify checkbox value in all records list
	    	for(var i = 0; i < listAllRecords.length; i++) {
	    		console.log(listAllRecords[i]);
	    		listAllRecords[i].devastegic1__Enabled__c = false;
	    		listUpdatedAllRecords.push(listAllRecords[i]);
	    	}
	    	
	    	//Loop over list to modify checkbox value in current records list
	    	for(var i = 0; i < listAllCurrentRecords.length; i++) {
	    		console.log(listAllCurrentRecords[i]);
	    		listAllCurrentRecords[i].devastegic1__Enabled__c = false;
	    		listUpdatedCurrentListRecords.push(listAllCurrentRecords[i]);
	    	}
    	}
    	
    	//Update Value of all records list    	
    	if(listUpdatedAllRecords != null && listUpdatedAllRecords.length > 0)
    		component.set("v.currentFilteredList", listUpdatedAllRecords);
	    	
	    //Update Value of current records list    	
    	if(listUpdatedCurrentListRecords != null && listUpdatedCurrentListRecords.length > 0)
    		component.set("v.currentList", listUpdatedCurrentListRecords);
    		
    	helper.renderPage(component, 'v.currentFilteredList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');	
    },
    
    //Method created to select all campaigns records
    selectAllCampaigns : function(component, event, helper) {
    	
    	var checkboxVal = document.getElementById("check-selectAllCampaigns");
    	var listAllCurrentRecords = component.get("v.currentList");
    	var listAllRecords = component.get("v.currentFilteredCampList");
    	var listUpdatedAllRecords = [];
    	var listUpdatedCurrentListRecords = [];    	
    	
    	if(checkboxVal != null && checkboxVal != undefined && checkboxVal.checked) {
    		
    		//Loop over list to modify checkbox value in all records list
	    	for(var i = 0; i < listAllRecords.length; i++) {
	    		console.log(listAllRecords[i]);
	    		listAllRecords[i].devastegic1__Enabled__c = true;
	    		listUpdatedAllRecords.push(listAllRecords[i]);
	    	}
	    	
	    	//Loop over list to modify checkbox value in current records list
	    	for(var i = 0; i < listAllCurrentRecords.length; i++) {
	    		console.log(listAllCurrentRecords[i]);
	    		listAllCurrentRecords[i].devastegic1__Enabled__c = true;
	    		listUpdatedCurrentListRecords.push(listAllCurrentRecords[i]);
	    	}	    	
	    } else if(checkboxVal != null && checkboxVal != undefined && !checkboxVal.checked) {
    	
    		//Loop over list to modify checkbox value in all records list
	    	for(var i = 0; i < listAllRecords.length; i++) {
	    		console.log(listAllRecords[i]);
	    		listAllRecords[i].devastegic1__Enabled__c = false;
	    		listUpdatedAllRecords.push(listAllRecords[i]);
	    	}
	    	
	    	//Loop over list to modify checkbox value in current records list
	    	for(var i = 0; i < listAllCurrentRecords.length; i++) {
	    		console.log(listAllCurrentRecords[i]);
	    		listAllCurrentRecords[i].devastegic1__Enabled__c = false;
	    		listUpdatedCurrentListRecords.push(listAllCurrentRecords[i]);
	    	}
    	}
    	
    	//Update Value of all records list    	
    	if(listUpdatedAllRecords != null && listUpdatedAllRecords.length > 0)
    		component.set("v.currentFilteredCampList", listUpdatedAllRecords);
	    
	    //Update Value of current records list    	
    	if(listUpdatedCurrentListRecords != null && listUpdatedCurrentListRecords.length > 0)
    		component.set("v.currentList", listUpdatedCurrentListRecords);
    		
    	helper.renderPage(component, 'v.currentFilteredCampList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');	
    },
    
    //Select All Default Campaign Record
    selectAllDefaultCampaigns : function(component, event, helper) {
    
    	var checkboxVal = document.getElementById("check-selectAllDefaultCampaigns");
    	var listAllCurrentRecords = component.get("v.currentList");
    	var listAllRecords = component.get("v.currentFilteredCampList");
    	var listUpdatedAllRecords = [];
    	var listUpdatedCurrentListRecords = [];
    	
    	if(checkboxVal != null && checkboxVal != undefined && checkboxVal.checked) {
    		
    		//Loop over list to modify checkbox value in all records list
	    	for(var i = 0; i < listAllRecords.length; i++) {
	    		console.log(listAllRecords[i]);
	    		listAllRecords[i].devastegic1__Auto_set__c = true;
	    		listUpdatedAllRecords.push(listAllRecords[i]);
	    	}
	    	
	    	//Loop over list to modify checkbox value in current records list
	    	for(var i = 0; i < listAllCurrentRecords.length; i++) {
	    		console.log(listAllCurrentRecords[i]);
	    		listAllCurrentRecords[i].devastegic1__Auto_set__c = true;
	    		listUpdatedCurrentListRecords.push(listAllCurrentRecords[i]);
	    	}	    	
	    } else if(checkboxVal != null && checkboxVal != undefined && !checkboxVal.checked) {
    	
	    	//Loop over list to modify checkbox value in all records list
	    	for(var i = 0; i < listAllRecords.length; i++) {
	    		console.log(listAllRecords[i]);
	    		listAllRecords[i].devastegic1__Auto_set__c = false;
	    		listUpdatedAllRecords.push(listAllRecords[i]);
	    	}
	    	
	    	//Loop over list to modify checkbox value in current records list
	    	for(var i = 0; i < listAllCurrentRecords.length; i++) {
	    		console.log(listAllCurrentRecords[i]);
	    		listAllCurrentRecords[i].devastegic1__Auto_set__c = false;
	    		listUpdatedCurrentListRecords.push(listAllCurrentRecords[i]);
	    	}
    	}
    	
    	//Update Value of all records list    	
    	if(listUpdatedAllRecords != null && listUpdatedAllRecords.length > 0)
    		component.set("v.currentFilteredCampList", listUpdatedAllRecords);
    		
    	//Update Value of current records list    	
    	if(listUpdatedCurrentListRecords != null && listUpdatedCurrentListRecords.length > 0)
    		component.set("v.currentList", listUpdatedCurrentListRecords);
    		
    	helper.renderPage(component, 'v.currentFilteredCampList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
    },
    
    //Method created to select all account records
    selectAllLeadOwners : function(component, event, helper) {
    	
    	var checkboxVal = document.getElementById("check-selectAllLeadOwners");
    	var listAllCurrentRecords = component.get("v.currentList");    		
    	var listAllRecords = component.get("v.currentFilteredLeadOwnerList");
    	var listUpdatedAllRecords = [];
    	var listUpdatedCurrentListRecords = [];
    	
    	if(checkboxVal != null && checkboxVal != undefined && checkboxVal.checked) {
    		
    		//Loop over list to modify checkbox value in all records list
	    	for(var i = 0; i < listAllRecords.length; i++) {
	    		console.log(listAllRecords[i]);
	    		listAllRecords[i].devastegic1__Enabled__c = true;
	    		listUpdatedAllRecords.push(listAllRecords[i]);
	    	}
	    	
	    	//Loop over list to modify checkbox value in current records list
	    	for(var i = 0; i < listAllCurrentRecords.length; i++) {
	    		console.log(listAllCurrentRecords[i]);
	    		listAllCurrentRecords[i].devastegic1__Enabled__c = true;
	    		listUpdatedCurrentListRecords.push(listAllCurrentRecords[i]);
	    	}	    	
	    } else if(checkboxVal != null && checkboxVal != undefined && !checkboxVal.checked) {
	    	
	    	//Loop over list to modify checkbox value in all records list
	    	for(var i = 0; i < listAllRecords.length; i++) {
	    		console.log(listAllRecords[i]);
	    		listAllRecords[i].devastegic1__Enabled__c = false;
	    		listUpdatedAllRecords.push(listAllRecords[i]);
	    	}
	    	
	    	//Loop over list to modify checkbox value in current records list
	    	for(var i = 0; i < listAllCurrentRecords.length; i++) {
	    		console.log(listAllCurrentRecords[i]);
	    		listAllCurrentRecords[i].devastegic1__Enabled__c = false;
	    		listUpdatedCurrentListRecords.push(listAllCurrentRecords[i]);
	    	}	
    	}
    	
    	//Update Value of all records list    	
    	if(listUpdatedAllRecords != null && listUpdatedAllRecords.length > 0)
    		component.set("v.currentFilteredLeadOwnerList", listUpdatedAllRecords);
    		
    	//Update Value of current records list    	
    	if(listUpdatedCurrentListRecords != null && listUpdatedCurrentListRecords.length > 0)
    		component.set("v.currentList", listUpdatedCurrentListRecords);
    		
    	helper.renderPage(component, 'v.currentFilteredLeadOwnerList', 'v.pageNumber', 'v.recordsPerPage', 'v.currentList', 'v.maxPage', 'v.pageNoList');
	    	
    },
    
    //Code Added by Chetan (May 23, 2019)
    //Method to get selected record type values from child component
    handleComponentRecordTypeChangeEvent : function(component, event, helper) {
    	
    	var selectedValues = event.getParam("values");
    	
    	component.set("v.selectedRecordType", selectedValues);
    	
    	helper.accountList(component, event, helper);
    }
})