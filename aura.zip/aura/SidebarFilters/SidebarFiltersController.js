({
	showTabel : function(component, event, helper) {
		console.log("showTabel");
		component.set("v.reportType","User");
		/*var cmpEvent = component.getEvent("ShowDataTabel");
        cmpEvent.fire();*/
	},
	createLookup : function(component, event, helper) {
		$A.createComponent(
	        "c:CustomMultiSelectLookup",
	        {
	            "label": "User Name",
	            "objectAPIName": "User_Detail__c",
	            "IconName": "standard:user"
	        },
	        function(comp, status, errorMessage){
	            if (status === "SUCCESS") {
	                var body = component.find('lookup').get('v.body');
	                body=comp;
	                component.find('lookup').set('v.body', body);
	            }
	            else if (status === "INCOMPLETE") {
	                console.log("No response from server or client is offline.")
	            }
	            else if (status === "ERROR") {
	                console.log("Error: " + errorMessage);
	            }
	        }
	    );
	},
	getBusinssData : function(component, event, helper) {
		component.set('v.reportType','Business');
	},
	getEmailData : function(component, event, helper) {
		component.set('v.reportType','Email');
	},
	
	showSendEmailReport : function(component, event, helper) {
	
		component.set('v.reportType','SendEmail');
	}
})