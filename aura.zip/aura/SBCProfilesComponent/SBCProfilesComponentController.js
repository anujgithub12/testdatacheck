({ 
	doInit: function(component, event, helper) {
        console.log('--------showAssignComponent------------'+component.get("v.showAssignComponent"));
        var optionsList = [];
        optionsList.push(10);
        optionsList.push(25);
        optionsList.push(50); 
        optionsList.push(100);
        component.set("v.recordsPerPage",10);
        component.set("v.recordsPerPageList",optionsList);
        var action = component.get("c.retrieveDetail");
        action.setCallback(this, function(result) {
            var records = result.getReturnValue();
            component.set("v.allRecords", records);
            console.log(records);
            component.set("v.maxPage", Math.floor((records.length+9)/10));
            var maxPage = component.get("v.maxPage");
            component.set("v.pageNumber",1);
            helper.sortBy(component, 'Name');
        });
        $A.enqueueAction(action);
        
        var checkPreload = component.get("c.isPreloaded");
        checkPreload.setCallback(this, function(result) {
            var state = result.getState();
            if (state === "SUCCESS") {
            	component.set("v.preloaded", result.getReturnValue());
            }else if (state === "ERROR") {
            	var errors = response.getError();
                var messageToDisplay;
                var typeOfMessage = 'error';
                if (errors) {
                    if (errors[0] && errors[0].message) {
                    	messageToDisplay = "Error message: " + errors[0].message;
                        console.log("Error message: " + 
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                    messageToDisplay = "Error message: Unknown error";
                }            
            
            	if(component.get("v.isLightning")) {
	                helper.showToast(component, event, helper, messageToDisplay, typeOfMessage);
	            } else {
	                component.set("v.textMessage", messageToDisplay);
	                component.set("v.isToastMessageForVf", true);
	                component.set("v.isErrorType", true);
	                component.set("v.isSuccessType", false);
	                component.set("v.isInfoType", false);
	            }
            }
        });
        $A.enqueueAction(checkPreload);
	},  
    sortByName: function(component, event, helper) {
        helper.sortBy(component, "Name");
    },  
    renderPage: function(component, event, helper) {
        helper.renderPage(component,'v.allRecords','v.pageNumber','v.recordsPerPage','v.currentList','v.maxPage','v.pageNoList');
	},
    renderPageOnRecordsPerPageChange: function(component, event, helper){
        helper.renderPageOnRecordsPerPageChange(component);
    }, 
    openAssignComponent : function(component, event, helper){
        console.log('-----------openAssignComponent----------');
        helper.openAssignComponentHelper(component, event, helper);
    },
    openComponentDynamically : function(component, event, helper) {
        helper.openComponentDynamically(component, event, helper);
    },
    refreshView : function(component, event, helper){
        helper.refreshViewHelper(component, event, helper);
    },
    deleteProfileNo : function(component, event, helper){
    	var cmpTarget = document.getElementById("deleteModalId"); 
    	helper.toggleClassHelper(cmpTarget, "slds-hide");
        //helper.deleteProfile(component, event, helper); //profilesToDeleteList
        component.set("v.profilesToDeleteList", []);
    },
    showAssignedDetails : function(component, event, helper){
    	var profileId = event.target.getAttribute('data-index'); 
    	console.log('====profileId=====', profileId);
    	var cmpTarget = document.getElementById(profileId); 							
    	console.log('cmp-----', cmpTarget); 
    	
    	//First close all other pop ups
    	helper.closeOtherAssignPopup(component, event, helper, profileId);
    	
    	//toggle current clicked pop up
    	helper.toggleClassHelper(cmpTarget, "slds-hide");
    },
    deleteProfileYes : function(component, event, helper){
    	var cmpTarget = document.getElementById("deleteModalId"); 
        helper.toggleClassHelper(cmpTarget, "slds-hide");
        helper.toggleSpinner(component, event);
        helper.deleteProfile(component, event, helper);
    }, 
    deleteProfileClick : function(component, event, helper){
    	var cmpTarget = document.getElementById("deleteModalId"); 
    	helper.toggleClassHelper(cmpTarget, "slds-hide");
        
        
        var profileId = event.target.getAttribute('data-index'); 
        var draftDrofileId = event.target.getAttribute('data-draft-profile-id');
        var profileList = draftDrofileId ? [profileId, draftDrofileId]: [profileId];
        
        component.set("v.profilesToDeleteList", profileList);
        component.set("v.profileNameToDelete", event.target.getAttribute('data-profile-name'));
        console.log('----profile List----', profileList);
    }
})