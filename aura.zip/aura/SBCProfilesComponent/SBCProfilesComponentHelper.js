({ 
    sortBy: function(component, field) {
        var sortAsc = component.get("v.sortAsc"),
            sortField = component.get("v.sortField"),
            records = component.get("v.allRecords");
        sortAsc = sortField != field || !sortAsc;
        records.sort(function(a,b){
            var t1 = a.profileObject[field].toLowerCase() == b.profileObject[field].toLowerCase(),
                t2 = (!a.profileObject[field] && b.profileObject[field].toLowerCase()) || (a.profileObject[field].toLowerCase() < b.profileObject[field].toLowerCase());     
            
            return t1? 0: (sortAsc?-1:1)*(t2?1:-1);
        });
        component.set("v.sortAsc", sortAsc);
        component.set("v.sortField", field);
        component.set("v.allRecords", records);
        this.renderPage(component,'v.allRecords','v.pageNumber','v.recordsPerPage','v.currentList','v.maxPage','v.pageNoList');
    }, 
	renderPage: function(component,allRecordVar,pageNumberVar,recordsPerPageVar,currentListVar,maxPageVar,pageNoListVar) {
        var records = component.get(allRecordVar),
            pageNumber = component.get(pageNumberVar),
            recordsPerPage = component.get(recordsPerPageVar),
            pageRecords = records.slice((pageNumber-1)*recordsPerPage, pageNumber*recordsPerPage);
            component.set(currentListVar, pageRecords);
        component.set(maxPageVar, Math.floor((records.length+parseInt(recordsPerPage)-1)/parseInt(recordsPerPage)));
        var maxPage = component.get(maxPageVar);
        var pageNoList = [];
        for(var i = 1; i<= maxPage ; i++){
            pageNoList.push(i);
        }
        component.set(pageNoListVar,pageNoList);
    }, 
    renderPageOnRecordsPerPageChange : function(component){
        var records = component.get("v.allRecords"),
            recordsPerPage = component.get("v.recordsPerPage"),
            pageRecords = records.slice(0,recordsPerPage);
        component.set("v.pageNumber", 1);
        component.set("v.currentList", pageRecords);
        component.set("v.maxPage", Math.floor((records.length+parseInt(recordsPerPage)-1)/parseInt(recordsPerPage)));
        var maxPage = component.get("v.maxPage");
        var pageNoList = [];
        for(var i = 1; i<= maxPage ; i++){
            pageNoList.push(i);
        }
        component.set("v.pageNoList",pageNoList);
    } ,
    openAssignComponentHelper : function(component, event, helper){
        console.log('-------openAssignComponentHelper----2------------');
        var idx = event.target.getAttribute('data-index');
        component.set("v.selectedSBCRoleId",idx);
        component.set("v.showAssignComponent",'show');
    },
    openComponentDynamically : function(component, event, helper) {
        /* $A.createComponent(
             "c:ScanBizCardsComp",
            {
               "rId": event.target.getAttribute('data-index')
            },
            function(newComponent, status){
                if (status === "SUCCESS") {
                    var body = cmp.get("v.body");
                    body.push(newComponent);
                    component.set("v.body", body);
                }
            }
        );*/ 
        var profileId = event.target.getAttribute('data-index');		//? event.target.getAttribute('data-index') : "";
        console.log("profile Id", profileId);
        component.set("v.IdFromEdit", event.target.getAttribute('data-index'));
        component.set("v.childDraftId", event.target.getAttribute('data-draft-profile-id'));	// 
        component.set("v.isPublishedOnceId", event.target.getAttribute('data-is-published-once'));
        component.set("v.profileName", event.target.getAttribute('data-profile-name'));
        component.set("v.isEditCompOpen", true);
        console.log(event.target.getAttribute('data-draft-profile-id'), '---', event.target.getAttribute('data-is-published-once'));
        
    },
    refreshViewHelper : function(component,event,helper){  
        $A.get('e.force:refreshView').fire();
    },
    
    toggleClassHelper : function(cmpTarget, className) {
		if (cmpTarget.classList) { 
		    cmpTarget.classList.toggle(className); //slds-hide
		} else {
		    // For IE9
		    var classes = cmpTarget.className.split(" ");
		    var i = classes.indexOf(className);
		
		    if (i >= 0) {
		        classes.splice(i, 1);
		    }
		    else {
		        classes.push(className);
		    }
		    cmpTarget.className = classes.join(" ");
		}      
    },
    
    closeOtherAssignPopup : function(component, event, helper, popupClickedId){
    	//var {!'assignDetailId' + record.profileObject.Id}     record.profileObject.Name
    	//var allAssignDetailsPopup = document.getElementById();
    	//var assignDetailId =
    	var currentPageRecordList = component.get("v.currentList");  
    	for(var index=0; index < currentPageRecordList.length; index++) {
    		var currentRecord = currentPageRecordList[index];
    		var popupElementId = 'assignDetailId' + currentRecord.profileObject.Id;
    		console.log('====%%%%%===== ', popupElement);
    		if(popupClickedId != popupElementId) {
    			var popupElement = document.getElementById(popupElementId);
    			//Now add "slds-hide"
    			if(popupElement.classList) {
    				popupElement.classList.add("slds-hide");
    			}else {
    				// For IE9
				    var classes = popupElement.className.split(" ");
				    var i = classes.indexOf("slds-hide");
				
				    if (i == -1) {
				    	//This ensures that "sld-hide" class is not already added and element is popped up
				        classes.push("slds-hide");
				    }
				    popupElement.className = classes.join(" ");
    			}
    		}
    	}
    },
    
    deleteProfile : function(component, event, helper){
        var action = component.get("c.deleteProfile");
        var profileList = component.get("v.profilesToDeleteList");
        console.log('----profile List----', profileList);
        action.setParams({ profileIdList :  profileList});

        // Create a callback that is executed after 
        // the server-side action returns
        action.setCallback(this, function(response) {
            var state = response.getState();
            var messageToDisplay = 'Successfully Deleted Profile!';
            var typeOfMessage = 'success';
            if (state === "SUCCESS") {
                //component.set("v.profilesToDeleteList", []);
                //console.log("From server: " + response.getReturnValue());
                var removeProfileId = component.get("v.profilesToDeleteList")[0];
                component.set("v.profilesToDeleteList", []);
                this.refreshProfilesListAfterDelete(component, event, helper, removeProfileId);
            }else if (state === "ERROR") {
            	component.set("v.profilesToDeleteList", []);
                var errors = response.getError();
                messageToDisplay = '';
                typeOfMessage = 'error';
                if (errors) {
                    if (errors[0] && errors[0].message) {
                    	messageToDisplay = "Error message: " + errors[0].message;
                        console.log("Error message: " + 
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                    messageToDisplay = "Error message: Unknown error";
                }
            }
            //component.set("v.profilesToDeleteList", []);
            helper.toggleSpinner(component, event);
           
            
            if(component.get("v.isLightning")) {
                this.showToast(component, event, helper, messageToDisplay, typeOfMessage);
            } else {
                component.set("v.textMessage", messageToDisplay);
                component.set("v.isToastMessageForVf", true);
                component.set("v.isErrorType", true);
                component.set("v.isSuccessType", false);
                component.set("v.isInfoType", false);
            }
        });

        $A.enqueueAction(action);  
    },
	showToast : function(component, event, helper, message, type) {
	    var toastEvent = $A.get("e.force:showToast");
	    toastEvent.setParams({
	        message: message,
	        type: type,
	        
	    });
	    toastEvent.fire();
	},
    toggleSpinner: function (component, event) {
        var spinner = component.find("profileCompSpinnerId");
        $A.util.toggleClass(spinner, "slds-hide");
    },
    refreshProfilesListAfterDelete : function(component, event, helper, deletedProfileId) {
    	var allProfileList = component.get("v.allRecords");
        console.log('Initial profiles---- ', allProfileList.length);
    	allProfileList = allProfileList.filter(function removeDeletedProfile(profile) {
		    								console.log('deletedProfileId---', deletedProfileId, '  profileId-----', profile.profileObject.Id);
		    								console.log(profile);
										    return profile.profileObject.Id != deletedProfileId;
									    }); 
		console.log('Refreshed profiles---- ', allProfileList.length);
		component.set("v.allRecords", allProfileList);
        component.set("v.maxPage", Math.floor((allProfileList.length+9)/10));
        var maxPage = component.get("v.maxPage");
        var redirectToPage = component.get("v.pageNumber") <= maxPage ? component.get("v.pageNumber") : maxPage;
        component.set("v.pageNumber", redirectToPage);
        helper.renderPage(component,'v.allRecords','v.pageNumber','v.recordsPerPage','v.currentList','v.maxPage','v.pageNoList');
        //helper.sortBy(component, 'Name');
    }	       
})