({
	getScanBizPackage : function(component, event){
		var action = component.get("c.getPackageLicense");
		action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            	console.log(response.getReturnValue());
                var packageValue = response.getReturnValue();                
                component.set("v.pkgLicense", packageValue);
            }else if (state === "ERROR"){
        		var errors = response.getError();
                var messageToDisplay;
                var typeOfMessage = 'error';
                if (errors) {
                    if (errors[0] && errors[0].message) {
                    	messageToDisplay = "Error message: " + errors[0].message;
                        console.log("Error message: " + 
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                    messageToDisplay = "Error message: Unknown error";
                } 
                
	            if(component.get("v.isLightning")) {
	                this.showToast(component, event, this, messageToDisplay, typeOfMessage);
	            } else {
	                component.set("v.textMessage", messageToDisplay);
	                component.set("v.isToastMessageForVf", true);
	                component.set("v.isErrorType", true);
	                component.set("v.isSuccessType", false);
	                component.set("v.isInfoType", false);
	            }                          
            }
        });
        $A.enqueueAction(action);
	},

	addActiveClass : function(component, event) {
		var tab = event.getSource().getLocalId();
		
		component.set('v.activeClassOnRoleTab', false);
        component.set('v.activeClassOnLicenseTab', false);
        component.set('v.activeClassOnReportsTab', false);
        
		if(tab == 'roleTab'){
			component.set('v.activeClassOnRoleTab', true);
		}
		else if(tab == 'licenseTab'){
			component.set('v.activeClassOnLicenseTab', true);
        }
		else if(tab == 'reportsTab'){
        	component.set('v.activeClassOnReportsTab', true);
		}
	
	},
	showToast : function(component, event, helper, message, type) {
	    var toastEvent = $A.get("e.force:showToast");
	    toastEvent.setParams({
	        message: message,
	        type: type,
	        
	    });
	    toastEvent.fire();
	},	
})