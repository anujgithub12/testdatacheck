({
	doInit : function(component, event, helper) {
	var action = component.get("c.getUserProfileAndPermissionSet");
		action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            	var isTabVisible = response.getReturnValue();                
                component.set("v.licenseAndReportTabAccess", isTabVisible);
            } });
        $A.enqueueAction(action);	
            
	helper.getScanBizPackage(component, event);
	},
    
    handleActive : function(component, event, helper){
        helper.addActiveClass(component, event);
    },
    
    handleMenuSelect : function(component, event, helper) {
    	var selectedMenuItemValue = event.getParam("value");
    	console.log(selectedMenuItemValue);
    	if(selectedMenuItemValue == "Guides"){
	    	window.open('https://d2rolrvey27r3w.cloudfront.net/wp-content/uploads/2018/08/10125238/Installation-Guide-Merged-Doc-ver02-110418.pdf');
    	}
    	else if(selectedMenuItemValue == "Tutorials"){
    		window.open('https://www.youtube.com/watch?v=ExAmoJCuZck');
    	}
    	else if(selectedMenuItemValue == "FAQ's"){
    		window.open('https://circleback.zendesk.com/hc/en-us/categories/201880883-ScanBizCards-Enterprise');
    	}
    },
    
    navigateToContactUs : function(component, event, helper) {
	    var urlEvent = $A.get("e.force:navigateToURL");
	    urlEvent.setParams({
	      "url": 'https://circleback.zendesk.com/hc/en-us/categories/201880883-ScanBizCards-Enterprise'
	    });
	    
	    urlEvent.fire();
    },
    toastMessageEventHandler : function(component, event, helper) {
    	console.log('toastMessageEventHandler--- ');
	    var toastEvent = $A.get("e.force:showToast");
	    toastEvent.setParams({
	        message: event.getParam("toastMessage"),
	        type: event.getParam("toastType")
	    });
	    toastEvent.fire();    
    },
    clickOnRole : function(component, event, helper) {
       $A.util.toggleClass(component.find("roleId"), 'slds-hide');
    },
    mouseLeaveFromRole : function(component, event, helper) {
        $A.util.addClass(component.find("roleId"), 'slds-hide');
    },
    mouseEnterOnRole : function(component, event, helper) {
        $A.util.removeClass(component.find("roleId"), 'slds-hide');
    },
     clickOnLicense : function(component, event, helper) {
       $A.util.toggleClass(component.find("licenseId"), 'slds-hide');
    },
    mouseLeaveFromLicense : function(component, event, helper) {
        $A.util.addClass(component.find("licenseId"), 'slds-hide');
    },
    mouseEnterOnLicense : function(component, event, helper) {
        $A.util.removeClass(component.find("licenseId"), 'slds-hide');
    },
     clickOnReport : function(component, event, helper) {
       $A.util.toggleClass(component.find("reportId"), 'slds-hide');
    },
    mouseLeaveFromReport : function(component, event, helper) {
        $A.util.addClass(component.find("reportId"), 'slds-hide');
    },
    mouseEnterOnReport : function(component, event, helper) {
        $A.util.removeClass(component.find("reportId"), 'slds-hide');
    },
    handleLoadRecordTypeAppEvent : function(component, event, helper) {
    	event.stopPropagation();
    }
})