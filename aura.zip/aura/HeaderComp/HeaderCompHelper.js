({
	getAllData : function(component, startDate, endDate) {
        startDate = component.get('v.startDateFilter');
        endDate = component.get('v.endDateFilter');
        var spinner = component.find("spinner");
        $A.util.toggleClass(spinner, "slds-hide");

        var action = component.get("c.retriveAnaliticData");
        action.setParams({ 
            startDate : startDate,
            endDate : endDate,
            userList : component.get("v.userList"),
            reportType: component.get('v.reportType')

        }); 
        action.setCallback(this, function(response) {
            console.log(response.getState());
            if (response.getState() === "SUCCESS") {
                console.log(response.getReturnValue());
                this.parseResponse(component, response.getReturnValue());
            }
            else { 
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } 
            }
            $A.util.toggleClass(spinner, "slds-hide");
        });
        $A.enqueueAction(action);
	},
    parseResponse : function(component, response) {
        var oldChartComp = component.find("chartComp");
        if(!$A.util.isEmpty(oldChartComp)){
            oldChartComp.destroy();
        }
        var errorComp = component.find("errorComp");
        if(!$A.util.isEmpty(errorComp)){
            errorComp.destroy();
        }
        if(!$A.util.isEmpty(response)){
            if(!$A.util.isEmpty(response.perDayScan)){
                component.set('v.scanPerDay', response.perDayScan);
            }
            if(!$A.util.isEmpty(response.totalUser)){
                component.set('v.totalUsers', response.totalUser);
            }
            console.log('response.perDayScan',response.perDayScan);
            var perDayScan = response.perDayScan;
            var scannedMap = response.monthScannMap;
            var exportMap = response.monthExportMap;
            var notLinkToEmailAccount = response.notLinkToEmailAccount;
            var selectedUserNotLinkToEmailAccount = response.selectedUserNotLinkToEmailAccount;
            var isCurrentUserLicensed = response.isCurrentUserLicensed;
            console.log('perDayScan----------------------------------'+perDayScan);
            console.log('notLinkToEmailAccount-----------------------'+notLinkToEmailAccount);
            console.log('report type---------------------------------'+component.get("v.reportType"));
            console.log('isCurrentUserLicensed-----------------------'+isCurrentUserLicensed);
            console.log('selectedUserNotLinkToEmailAccount-----------'+selectedUserNotLinkToEmailAccount);
            console.log('isCurrentUserLicensed-----------------------'+isCurrentUserLicensed);
            console.log('$A.util.isEmpty(component.get("v.userList")-'+$A.util.isEmpty(component.get("v.userList")));
            if(component.get("v.reportType") == 'Email' && isCurrentUserLicensed){
                component.set("v.errorMessage","Sorry,there are No Signature Capture Reports to show as<br> you haven't subscribed to a Signature Capture Package as yet.<br><br>For subscription contact : <a href=\"mailto:enterprise@circleback.zendesk.com\" target=\"_top\">enterprise@circleback.zendesk.com</a>");
                component.set("v.iconName","utility:turn_off_notifications");
                this.displayError(component);
            }else if(perDayScan == 0){
            	
                if (component.get("v.reportType") == 'Business') {
                    component.set("v.perDayLabel","AVERAGE SCANS PER DAY");
                    component.set("v.errorMessage","Sorry, there are No Business Cards Report to show.");
                    component.set("v.iconName","action:close");
                }else if (component.get("v.reportType") == 'Email') {
                	
                	if(notLinkToEmailAccount && $A.util.isEmpty(component.get("v.userList"))){
                		component.set("v.errorMessage","Sorry, there are No Signature Capture Reports to show.<br>Your License users have not linked any email accounts for Signature Capture.");
                		component.set("v.iconName","utility:turn_off_notifications");
                		//this.displayError(component);
                	}
                	else if(selectedUserNotLinkToEmailAccount && !$A.util.isEmpty(component.get("v.userList"))) {
                		component.set("v.errorMessage","Sorry, there are No Signature Capture Reports to show.<br> Your filtered license users have not linked any email accounts for Signature Capture.");
		                //component.set("v.iconName","utility:email");
		                component.set("v.iconName","utility:turn_off_notifications");
		                //this.displayError(component);
                	}
                	else{
                		component.set("v.perDayLabel","AVERAGE SIGNATURE CAPTURED PER DAY");
                		component.set("v.errorMessage","Sorry, there are No Signature Capture Reports to show.");
                		component.set("v.iconName","utility:turn_off_notifications");
                	}
                    
                }else if (component.get("v.reportType") == 'User') {
                    component.set("v.perDayLabel","AVERAGE PER DAY EXPORTS");
                    component.set("v.errorMessage","Sorry, there are No User Activity Reports to show.");
                    component.set("v.iconName","action:close");
                }    
                this.displayError(component);
            }/*else if(component.get("v.reportType") == 'Email' && notLinkToEmailAccount && $A.util.isEmpty(component.get("v.userList"))){
                component.set("v.errorMessage","Sorry, there are No Signature Capture Reports to show.<br>Your License users have not linked any email accounts for Signature Capture.");
                component.set("v.iconName","utility:email");
                this.displayError(component);
            }else if(component.get("v.reportType") == 'Email' && selectedUserNotLinkToEmailAccount && !$A.util.isEmpty(component.get("v.userList"))){
                component.set("v.errorMessage","Sorry, there are No Signature Capture Reports to show.<br> Your filtered license users have not linked any email accounts for Signature Capture.");
                component.set("v.iconName","utility:email");
                this.displayError(component);
            }*/else{
                this.createChart(component, response);
            }
        }
    },

    displayError : function(component){
        $A.createComponent(
            "c:ErrorMessage",
            {
                "aura:id": "errorComp",
                "message": component.get("v.errorMessage"),
                "iconName": component.get("v.iconName")
            },
            function(comp, status, errorMessage){
                if (status === "SUCCESS") {
                    var body = component.find('chartBody').get('v.body');
                    body = comp;
                    component.find('chartBody').set('v.body', body);
                }
                else if (status === "INCOMPLETE") {
                    console.log("No response from server or client is offline.")
                }
                else if (status === "ERROR") {
                    console.log("Error: " + errorMessage);
                }
            }
        );
    },
    createChart : function(component, attributeBind){
        
        var groupBy = 'Weekly';
        console.log(component.get('v.startDateFilter'));
        console.log(component.get('v.endDateFilter'));
        console.log(new Date(component.get('v.endDateFilter')));
        var timeDiff = Math.abs(component.get('v.startDateFilter') - component.get('v.endDateFilter'));
        var diffDays = Math.ceil(timeDiff/ (1000 * 3600 * 24));
        console.log("timeDiff",timeDiff);
        console.log("diffDays",diffDays);
        if (diffDays > 90) {
            groupBy = 'Monthly';
        }
        $A.createComponent(
            "c:Chart",
            {
                "aura:id": "chartComp",
                "jsondata": JSON.stringify(attributeBind),
                "groupBy": groupBy,
                "reportType":component.get("v.reportType")
            },
            function(comp, status, errorMessage){
                if (status === "SUCCESS") {
                    var body = component.find('chartBody').get('v.body');
                    body=comp;
                    component.find('chartBody').set('v.body', body);
                }
                else if (status === "INCOMPLETE") {
                    console.log("No response from server or client is offline.")
                }
                else if (status === "ERROR") {
                    console.log("Error: " + errorMessage);
                }
            }
        );
    },
    createDatePicker : function(component){
        var self = this;
          var endDate = new Date();
          var startDate = new Date();
          startDate.setDate(endDate.getDate()-90);
        $('input[name="daterange"]').daterangepicker({
                "opens": 'left',
                "maxSpan":{ 
                    "days":730},
                "startDate":startDate,
                "endDate" : endDate,
                "applyButtonClasses" : "slds-button slds-button_brand",
                "cancelButtonClasses" : "slds-button slds-button_brand",
                "autoApply" : false

        }, function(start, end, label) { 
            if(!$A.util.isEmpty(start) && !$A.util.isEmpty(end)){
               window.setTimeout($A.getCallback(function () {
            	   if (component.isValid()) {
	            	   component.set("v.startDateFilter", new Date(start.format('YYYY-MM-DD')));
	                   component.set("v.endDateFilter", new Date(end.format('YYYY-MM-DD')));
	                   self.getAllData(component, new Date(start.format('YYYY-MM-DD')), new Date(end.format('YYYY-MM-DD')));
	                   if (component.get('v.reportType') == 'User') {
	                        var tableCmp = component.find('FilterDataTabel');
	                        if (tableCmp) {
	                            tableCmp.filterTable(component.get('v.userList'),component.get('v.startDateFilter'),component.get('v.endDateFilter'));
	                        }
	                   }
            	   }
               }), 1000 );
            }
        });
    },
    handleShowTableEvent : function(component) {
        var FilterDataTabel = component.find("FilterDataTabel");
        if (FilterDataTabel) {
            FilterDataTabel.destroy();
        }
        $A.createComponent(
            "c:PaginationTable",
            {
                "aura:id": "FilterDataTabel",
                "userList" : component.get("v.userList"),
                "startDate":component.get('v.startDateFilter'),
                "endDate":component.get('v.endDateFilter')
            },
            function(comp, status, errorMessage){
                if (status === "SUCCESS") {
                console.log(comp);

                    var body = component.find('tabelBody').get('v.body');
                    body = comp;
                    component.find('tabelBody').set("v.body", body);
                }
                else if (status === "INCOMPLETE") {
                    console.log("No response from server or client is offline.")
                    // Show offline error
                }
                else if (status === "ERROR") {
                    console.log("Error: " + errorMessage);
                    // Show error message
                }
            }
        );
    },
    
})