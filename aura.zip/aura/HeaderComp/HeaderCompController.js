({
	init : function(component, event, helper) {
      var endDate = new Date();
      var startDate = new Date();
      console.log(endDate,startDate);
      startDate.setDate(endDate.getDate()-90);
        component.set('v.startDateFilter',startDate);
        component.set('v.endDateFilter',endDate);
		helper.createDatePicker(component);
		helper.getAllData(component,startDate,endDate);
	},
    
    setGroupByFilter: function(component, event, helper) {
        helper.getAllData(component, component.get("v.startDateFilter"), component.get("v.endDateFilter"));  
    },
    
    handelFilter : function(component, event, helper) {
        var userList = event.getParam("userList");
        component.set("v.userList",userList);
        var tableCmp = component.find('FilterDataTabel');
        if (tableCmp) {
            tableCmp.filterTable(userList,component.get('v.startDateFilter'),component.get('v.endDateFilter'));
        }
        helper.getAllData(component);

    },
    chartChange : function(component, event, helper) {
        console.log('chartChange-----------------------------------------------',component.get("v.reportType"));
        var FilterDataTabel = component.find("FilterDataTabel");
        var reportType = component.get("v.reportType");
        if (FilterDataTabel) 
            FilterDataTabel.destroy();

        helper.getAllData(component);
        if (reportType == 'Business') {
            component.set("v.perDayLabel","AVERAGE SCANS PER DAY");
            component.set("v.errorMessage","Sorry, there are No Business Cards Report to show.");
            component.set("v.iconName","action:close");
        }else if (reportType == 'Email') {
            component.set("v.perDayLabel","AVERAGE SIGNATURE CAPTURED PER DAY");
            component.set("v.errorMessage","Sorry, there are No Signature Capture Report to show.");
            component.set("v.iconName","utility:turn_off_notifications");
        }else if (reportType == 'User') {
            component.set("v.perDayLabel","AVERAGE PER DAY EXPORTS");
            component.set("v.errorMessage","Sorry, there are No User Activity Report to show.");
            component.set("v.iconName","action:close");

            helper.handleShowTableEvent(component);
        }
        
    }
})